"""
compare_runs.py - regression check between two CS-hybrid result files (.pkl).

Usage:
    python compare_runs.py baseline.pkl new.pkl

Reports whether the two runs are bit-identical and, if not, the first time
step that differs. Use it after merging the SLR / berm changes: with
`slr_toe` and `dynamic_toe` off (or `slr_toe: true` with `slr: 0`) the new
code must reproduce the old results exactly.
"""
import pickle
import sys

import numpy as np

SERIES = ['vdune', 'vbeach', 'vramp', 'eroded_volume', 'overwash_volume', 'qwnet', 'runup']


def compare(path_a, path_b):
    with open(path_a, 'rb') as f:
        a = pickle.load(f)
    with open(path_b, 'rb') as f:
        b = pickle.load(f)

    identical = True
    for key in SERIES:
        va, vb = np.asarray(a[key], dtype=float), np.asarray(b[key], dtype=float)
        if va.shape != vb.shape:
            print(f"{key:16s}: different length ({va.shape} vs {vb.shape})")
            identical = False
        elif not np.array_equal(va, vb):
            d = np.abs(va - vb)
            print(f"{key:16s}: differs first at step {int(np.argmax(d > 0))}, max |diff| = {d.max():.3e}")
            identical = False
        else:
            print(f"{key:16s}: identical")

    # profile pivots (the new code may add the 'berm' pivot; compare the common ones)
    n = min(len(a['dune_x']), len(b['dune_x']))
    for i in range(n):
        keys = [k for k in a['dune_x'][i] if k in b['dune_x'][i]]
        if any(a['dune_x'][i][k] != b['dune_x'][i][k] or a['dune_z'][i][k] != b['dune_z'][i][k] for k in keys):
            print(f"profile pivots  : differ first at step {i}")
            identical = False
            break
    else:
        print("profile pivots  : identical")

    print("RESULT:", "BIT-IDENTICAL" if identical else "DIFFERENT")
    return identical


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    sys.exit(0 if compare(sys.argv[1], sys.argv[2]) else 1)
