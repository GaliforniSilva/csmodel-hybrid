# CS-hybrid model: sea-level rise at the dune toe and berm option

Change log for `main.py`, `functions.py` and `mass_conservation.py`, relative to
the files uploaded on 12 November 2026. `__init__.py` is unchanged.

The exact line-by-line differences are in `changes_vs_uploaded.diff` (apply with
`patch -p1` or read it next to this file). Line numbers below refer to the NEW
files.

## 1. Summary

Two optional switches were added. Both are off by default, and with both off the
model output is bit-identical to the previous code (checked, section 6).

| Key | What it does |
| --- | --- |
| `slr_toe` | The dune toe level and the seaward flat of the hard structure (substrate points 4 and 5) rise with sea level, `slr * dt` per step. The dike does not move: substrate point 4 slides up the seaward dike face, so the face slope stays `betas_hs`. The toe slides back along the ramp face. Sea-level rise is added to the SWL forcing inside the simulation. |
| `dynamic_toe` | Berm option. `dfoot` becomes the maximum toe height above mean sea level. A new pivot `berm` marks the seaward end of a flat at that level. Erosion: the toe retreats up the beach slope to the berm point, then landward on the flat. Accretion: the toe advances on the flat, then down the beach face. The beach budget is exact, so no phantom beach volume is used. |

One bug fix that is independent of the switches is included in `functions.py`
(section 3.1). It is the only change that can alter results with both switches
off, and only in runs that previously crashed.

`morpho_update` keeps its logic. It still works on a flat plane at the current
toe level; the new code moves that plane after each call.

## 2. New configuration keys

All optional. They can go in any section of the yaml (keys are read by name);
`config_keys_slr_dynamic_toe.yaml` has a ready-to-copy block.

| Key | Default | Meaning |
| --- | --- | --- |
| `slr_toe` | `false` | Toe level and seaward flat rise with `slr` |
| `swl_includes_slr` | `false` | `false`: the model adds the rise to the SWL forcing. `true`: the SWL series already contains the trend |
| `dynamic_toe` | `false` | Berm option (maximum toe level, berm point, exact beach budget) |
| `dfoot_min` | `0.3 * dfoot` | Lowest toe height above mean sea level (numerical floor) |
| `beach_slope_max` | `dfoot / max(bl + 1, 30)` | Steepest beach face (`dfoot` / face width). Beyond it the berm point retreats, not past the toe |
| `beach_slope_min` | `0` (no limit) | Flattest beach face. Beyond it the berm point advances and the flat widens |

Requirements when either switch is on (the model stops with a clear error
otherwise):

- `base_elevation_front == dfoot`;
- a sloping seaward dike face (`ys_hs > ysprim_hs`, `s_hs > 0`);
- `slr` in m/s. The total rise over the run is written to the log at start-up as
  a unit check.

## 3. `functions.py`

### 3.1 Fix: ramp reaching a sand scarp over the dike face (lines 2018-2037, 2053)

Independent of the new switches. This is the fix that makes
`config_test16d.yaml` run.

After erosion, a vertical sand scarp can stand over the seaward dike face with
the face exposed below it. The ramp is rebuilt on the dike face. When its crest
reached the foot of the scarp, the 1 cm tolerance of the `elif` at old line 2034
kept the "ramp in front of the dike" branch active, the ramp crest kept climbing
the dike face underneath the sand (about 1.2 mm per step), and 9 steps later the
normal procedure failed in `brentq` (old line 2416).

New: a flag `ramp_at_scarp` is computed before the detached-case test. It is
true only when the ramp crest is at the scarp (within 2 cm), the toe is seaward
of the dike toe, the scarp stands over the dike face, the ramp crest is at or
above the dike face there, the scarp is higher than the ramp crest, and there is
no toe step. When true, the ramp crest x is aligned with the scarp and the
`elif` at line 2053 is skipped, so the step continues in the normal procedure.

```python
# old (line 2034)
elif (dune_x['ramp_crest'] > dune_x['seaward_crest'] + 1e-2) or (...):
# new (line 2053)
elif (not ramp_at_scarp) and ((dune_x['ramp_crest'] > dune_x['seaward_crest'] + 1e-2) or (...)):
```

Please compare this with your own later fix for the same state; you mentioned
that one of your fixes broke this test.

### 3.2 Rounding guard before the crest update (lines 2489-2496)

Inserted directly before `if qs_crest > 0:`. Pivots (`lee_crest`, `crest_temp`,
`ramp_dike_temp`, `ramp_crest`) that are within 1e-9 m of the seaward-crest
level are set exactly to it.

Reason: the branch tests of the crest update compare elevations with `<` and
`==`. Once the toe level is not a round number, `(z - dfoot) + dfoot` can differ
from `z` by one bit. The detached-crest test that follows was then taken
by mistake and the crest deposit of that step was lost (-0.68 m3/m in 14,000
steps of a synthetic test; +0.006 after the guard). With a round `dfoot` the
guard changes nothing.

### 3.3 `back_ref` condition in the lee update (lines 3024-3026)

```python
# old (line 2997)
if dune_z['lee_foot'] > dune_z['back_ref']:
# new
if dune_x['back_ref'] > dune_x['lee_foot'] or dune_z['lee_foot'] > dune_z['back_ref']:
```

Same condition as the existing one at the end of the lee update. With a rising
toe level and a dune standing in front of the dike, `back_ref` was left seaward
of the lee foot and `partial_volume` saw a notch.

### 3.4 New helper functions (lines 3489-3665, end of file)

Used only by `main.py` when a switch is on.

| Function | Purpose |
| --- | --- |
| `block_volume(x_toe, z_plane, z_bot, x3, z3, m_face)` | Bookkeeping volume of the sand below the toe level, between the dike face and the toe. Exact and signed; only differences with the same `z_bot` are used. |
| `_reanchor_pivots(...)` | Geometry of the toe-level shift. Sets substrate points 4 and 5 to the new level (point 4 on the dike face) and re-anchors the pivots resting on the plane. |
| `shift_base_plane(...)` | Calls `_reanchor_pivots` and returns the dune volume relabelled by the shift (`tau`, positive when the dune loses volume to the beach side). |
| `beach_base_level(...)` | Elevation of the beach base profile: flat at the maximum toe level up to the berm point, then berm point -> previous toe -> shoreline; not below the floor and not flatter than `beach_slope_min`. |
| `find_toe_level(...)` | Toe level for which the dune toe lies on that profile (maximum level on the flat, otherwise a 1-D root on the beach slope). |

States handled by `_reanchor_pivots` (stored per step in `results['shift_case']`):

| Case | State of the dune front | Action |
| --- | --- | --- |
| `rise` | Toe seaward of the dike toe, plane rises | Toe (and coincident pivots) move to where the dune front crosses the new level: along the ramp face, or in place at a vertical scarp or toe step |
| `drop` | Same, plane drops | Toe slides down the extension of the lowest ramp segment, or in place below a scarp |
| `dike_toe` | Toe at the dike toe (dike face exposed) | Toe follows substrate point 4 along the dike face |
| `under_face` | Toe drawn at plane level under the dike face (scarp landward of the dike toe) | Toe keeps its x and follows the level |
| `none` | Toe not on the plane, or level unchanged | Only the substrate changes |
| lee `slide` / `on_face` / `vertical` | Lee foot resting on the seaward plane (dune in front of the dike) | Lee foot follows the plane along the lee slope, or onto the dike face |

The lee side behind the dike (back base, lee foot, `dfoot_back`) is never moved.

## 4. `main.py`

### 4.1 Set-up (lines 1284-1364)

New block after the initial `dune_z`. It reads the switches, defines the state
variables and, for the berm option, inserts the `berm` pivot.

| Variable | Meaning |
| --- | --- |
| `msl` | Cumulative sea-level rise (m, model datum); also the z of the `shoreline` pivot |
| `z_plane` | Current toe level = `substrate_z[4]` = `substrate_z[5]`. With both switches off it is `p.dfoot` |
| `h_ref` | `p.dfoot`, the (maximum) toe height above mean sea level |
| `m_face`, `face_x3`, `face_z3` | Seaward dike face, taken once from the initial geometry |
| `x_berm` | Berm point (starts at the initial toe) |
| `seaward_vol` | Sand seaward of the toe down to the depth of closure (berm option state) |
| `block_cum` | Cumulative `block_volume` change, for the conservation record |

The `berm` key is inserted between `ramp_toe` and `shoreline` because
`morpho_update` interpolates over all pivot values in insertion order. The
pivot holds the visible berm crest, `max(x_berm, toe)`; the true berm position
is `results['x_berm']`.

### 4.2 Hydrodynamics and aeolian block (lines 1666-1850)

`p.dfoot` was one number used for two things. It is now split; with both
switches off both variables equal `p.dfoot`.

| Lines | Old | New |
| --- | --- | --- |
| 1666-1674 | `swl = swl_time_series[i]` | `swl = swl_time_series[i] + (0.0 if swl_includes_slr else msl)`; defines `h_beach = z_plane - msl`, `dfoot_abs = z_plane`, `al_eff`, `toe_on_flat` |
| 1718-1724 | `slope_foreshore = dune_z['ramp_toe'] / width` | `(dune_z['ramp_toe'] - dune_z['shoreline']) / width`. Berm option: slope of the beach face, berm point to shoreline |
| 1727 | `X = 2 * vbeach / p.dfoot * (1 - swl / p.dfoot)` | `h_beach` and `(swl - msl)`; berm option uses `vbeach_x` (face + half the flat block, so X includes the flat width) |
| 1732-1734 | `p.dfoot` in `rprim` and its test | `h_beach` |
| 1753-1767 | `p.dfoot` in the erosion threshold, impact height and overwash terms (11 times) | `dfoot_abs` |
| 1831-1836 | `yr = ... (1 - (r + swl) / p.dfoot) ...` | `(r + swl - msl) / h_beach`; berm option with the toe on the flat: waterline on the beach face |
| 1839-1850 | `r + swl >= p.dfoot`, `seaward_crest - p.dfoot` | `dfoot_abs` |

### 4.3 Start-of-step beach state (lines 1879-1892)

`p.al` -> `al_eff` and `p.dfoot` -> `h_beach` in the three existing lines, plus
the start-of-step toe, width, shoreline and depth-of-closure level.

### 4.4 Toe-level update (lines 1905-1933)

New block right after `morpho_update` and before the vegetation update. It adds
`slr * dt` to `msl`, chooses the new toe level (`z_plane + dz` for `slr_toe`
alone; `find_toe_level` for the berm option), calls `shift_base_plane`, and sets
`dune_z['shoreline'] = msl`. `substrate_x` and `substrate_z` are rebound to new
lists, so `results['substrate_x']` keeps the initial substrate.

### 4.5 Beach update (lines 1986-2043)

- `else` branch (lines 2028-2042): the original formulation, same statements in
  the same order, with `p.dfoot` -> `h_beach_1` and `p.al` -> `al_eff_1` (the same
  numbers when the toe height is `dfoot`).
- `if dynamic_toe` branch (lines 1996-2027): exact budget,
  `seaward_vol += q_beach + toe_relabel - dblock`, then the shoreline from
  - toe on the flat: `seaward_vol = (x_berm - toe)*(dfoot + dclos) + w_face*dclos + (w_face - bl)/al`;
  - toe on the slope: `seaward_vol = w*dclos + (w - bl)/al_eff`;
  and the berm-point retreat or advance at the slope limits.

### 4.6 Conservation record and outputs (lines 1396-1409, 1499, 2056, 2070-2072, 2121-2144)

Both calls to `calculate_compartment_volumes` pass the new `block` argument;
`fluxes` gains `qslr`, `toe_relabel` and `exact_beach`. New entries in
`results`:

| Key | Length | Content |
| --- | --- | --- |
| `dfoot` | n+1 | Toe level per step (m, model datum) |
| `msl` | n+1 | Mean sea level per step |
| `substrate_x4` | n+1 | x of substrate point 4 (rebuilds the substrate of any step together with `dfoot`) |
| `x_berm` | n+1 | Berm point |
| `block` | n+1 | Bookkeeping volume below the toe level under the dune |
| `qslr`, `toe_relabel`, `dblock` | n | Bruun flux; dune volume relabelled by the shift; change of `block` |
| `shift_case` | n | State handled by the shift |
| `vdune_ref` | n | Dune volume above the initial substrate |
| `vdune_true` | n | Dune volume above the beach base profile (berm option; `vdune` otherwise) |
| `dynamic_toe`, `slr_toe` | flag | Switches of the run |

With a moving toe level, `vdune` is the volume above the plane at the current
toe level, so it changes when the plane moves. Use `vdune_true` or `vdune_ref`
to compare runs. Plot scripts that draw the toe line or a storm threshold should
read `results['dfoot']`.

### 4.7 Plotting (lines 190, 636, 640, 666, 690, 2162)

`'berm'` added to `_profile_order`; the sea is drawn at `msl` (passed through
`bc_info['msl']`) instead of 0.0.

## 5. `mass_conservation.py`

| Lines | Change |
| --- | --- |
| 86, 115-124 | `calculate_compartment_volumes(..., block=None)`. With `block` given (berm option) the beach compartment is `block + width*dclos + vbeach`; otherwise the original formula |
| 182-188 | `calculate_timestep_conservation`: the expected changes include the Bruun sink `qslr*dt` (missing before) and `toe_relabel` |
| 287-313 | `check_mass_conservation`: `substrate_at(k)` rebuilds the substrate of step k from `dfoot` and `substrate_x4`; `beach_volume_at(k)` uses the exact per-step record for the berm option. Result files without the new keys are handled as before |
| 336-369 | Initial and final dune and beach volumes use these two helpers |
| 400-415 | Totals of the Bruun sink and of `toe_relabel`; the Bruun volume is added to `total_transport` |
| 420-425 | The phantom-correction loop is skipped for the berm option |
| 444-445 | `expected_total_change = phantom + nourishment - qslr*dt - toe_relabel` (the last term only without the berm option) |
| 464-472 | Report lines for the sea-level-rise terms |

Note: the Bruun sink was not in the expected change before, so runs with
`slr > 0` showed it as a conservation error. It is now accounted for.

## 6. Verification

Run on `config_test16d.yaml` (79,056 steps, three storms, dike exposure and
detachment) and on two synthetic geometries.

| Test | Result |
| --- | --- |
| Both switches off, compared with the uploaded code + fix 3.1 | Bit-identical (`compare_runs.py`); post-run check PASSED, total error -0.027 m3/m |
| `slr_toe: true` with `slr: 0` | Bit-identical |
| Synthetic cases, switches off, compared with the uploaded code without any fix | Bit-identical |
| `slr_toe`, 0.5 m rise | Runs to the end. Toe on the plane and point 4 on the dike face at every step. Post-run check PASSED, total error -0.048 m3/m (Bruun sink 500.0, relabelled 19.5 m3/m). Shift cases: 357 steps at the dike toe, 9 under the dike face |
| `dynamic_toe` | Runs to the end. Largest per-step beach error 9e-13 m3/m, no phantom correction. Post-run check PASSED, total error -0.028 m3/m. A flat 54 to 60 m wide is left after each storm; 13 m remain at the end |
| `dynamic_toe` + `slr_toe` (0.5 m) + slope limits 0.018 / 0.025 | Runs to the end. Largest per-step beach error 1e-12 m3/m. Post-run check PASSED, total error -0.049 m3/m. Berm point 360 -> 361.7 -> 352.2 m |
| Snapshot plotting with the `berm` pivot and rising sea level | Frames produced correctly (900 h run) |

The remaining total errors (-0.03 to -0.05 m3/m) are the dune routine's own
residual, which is the same size with the switches off.

## 7. Known limits

- No test has taken the toe far down the beach slope. In test16d the dune never
  passes the berm point; in a synthetic case the toe went 0.15 m below `dfoot`.
  The hydrodynamic limit on progradation is therefore not demonstrated.
- The defaults of `dfoot_min`, `beach_slope_min` and `beach_slope_max` are
  placeholders; the values 0.018 and 0.025 used in the tests were picked around
  the initial slope of test16d.
- With the berm option, runup slope, dissipation width and fetch use the beach
  face and the flat. Results differ from the original model after the first
  erosion event even while the toe is at `dfoot`.
- `shift_base_plane` stops with an error if the toe level comes within 5 cm of
  the dike crest, or if the plane would rise above the dune front or lee crest
  (a buried dike or dune is not handled).
- On the beach slope the `al`, `bl` relation is scaled with the toe height,
  which is approximate when `bl` is not zero.
- `bactive` is a constant, so the Bruun volume does not grow when the flat
  widens.
- The fix in 3.1 was written without your later fixes; it needs a look when you
  merge it with your current `functions.py`.
- Coupling mode (shoreline imposed from outside) is supported in the code but
  was not tested with the new switches.

## 8. How to merge

1. Replace `functions.py`, `main.py` and `mass_conservation.py`, or apply
   `changes_vs_uploaded.diff` to your current files (your `functions.py`
   differs from the uploaded one, so apply the functions part by hand: sections
   3.1 to 3.4 are four separate, small places).
2. Run your reference cases with both switches off and compare with
   `python compare_runs.py old.pkl new.pkl`. They must be bit-identical, except
   in runs that used to crash in the state of section 3.1.
3. Switch on `slr_toe` with `slr: 0`; results must again be bit-identical.
4. Then use `slr > 0` and `dynamic_toe`, and check `results['shift_case']` and
   the mass conservation report.
