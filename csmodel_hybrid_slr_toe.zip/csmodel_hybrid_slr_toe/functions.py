'''
functions.py
Authors:
    Filipe Galiforni Silva (TU Delft)
    Ad Reniers (TU Delft)
    Sierd de Vries (TU Delft)
    Floris van Rees (Deltares)
    Caroline Hallin (Lund University).

TU Delft, 2025

Description:
    This module contains helper functions used in the main.py file.

License:
    Copyright (c) 2025, Delft University of Technology.
    All rights reserved.
'''

############################################################################
# IMPORTS
############################################################################

import os
import numpy as np
from scipy.optimize import brentq
import matplotlib.pyplot as plt
from shapely.geometry import LineString
from scipy.interpolate import interp1d
import pandas as pd
import netCDF4 as nc
import yaml

############################################################################
# FUNCTIONS
############################################################################

### General helper functions
# Variables whose values are angles in degrees (interpolated on the circle)
CIRCULAR_COLUMNS = {"wave_direction", "wind_direction"}
# Variables that are categorical / step-wise (never interpolated linearly)
STEP_COLUMNS = {"month"}


def _to_utc_naive(ts):
    """Timestamp/DatetimeIndex -> UTC without timezone info (naive input is taken as UTC)."""
    if isinstance(ts, pd.DatetimeIndex):
        return ts.tz_convert("UTC").tz_localize(None) if ts.tz is not None else ts
    ts = pd.Timestamp(ts)
    return ts.tz_convert("UTC").tz_localize(None) if ts.tzinfo is not None else ts


def build_model_time(start_date, dt, end_date=None, time_length_hours=None):
    """
    Model time axis.

    Parameters
    ----------
    start_date : str or Timestamp
        Date/time of model t = 0 (UTC if no timezone is given).
    dt : float
        Time step (s).
    end_date : str or Timestamp, optional
        Last date to simulate. Takes precedence over time_length_hours.
    time_length_hours : float, optional
        Run length (h), used when end_date is not given.

    Returns
    -------
    n_steps : int
    dates : pandas.DatetimeIndex
        Date of the forcing used in each step (step k uses start + k*dt).
    """
    t0 = _to_utc_naive(start_date)
    if end_date is not None:
        t_end = _to_utc_naive(end_date)
        if t_end <= t0:
            raise ValueError(f"end_date ({t_end}) must be after start_date ({t0})")
        n_steps = int(np.floor((t_end - t0).total_seconds() / dt))
    elif time_length_hours is not None:
        n_steps = int(time_length_hours * 3600 / dt)
    else:
        raise ValueError("give end_date or time_length_hours in time_params")
    dates = t0 + pd.to_timedelta(np.arange(n_steps) * dt, unit="s")
    return n_steps, dates


def load_timeseries(
    source,
    length,
    column,
    default=None,
    sep="\t",
    time_col="datetime",
    model_dates=None,
    method=None,
    max_gap_hours=None,
):
    """
    Load a forcing time series, or create a constant one.

    Two modes:

    * model_dates given (time_params.start_date set in the yaml):
      the file is read with its timestamps and interpolated onto the model
      time axis, so the forcing is aligned in time for any dt and any start
      date inside the record. The model window must lie inside the record.
    * model_dates None (legacy): the values are returned row by row from
      the first row of the file, i.e. the file must start at model t = 0
      and have one row per dt.

    Parameters
    ----------
    source : str, float or None
        File name (tab separated, with a datetime column) or constant value.
    length : int
        Number of model time steps.
    column : str
        Column to read.
    default : float, optional
        Constant used when source is None.
    model_dates : pandas.DatetimeIndex, optional
        Date of each model step.
    method : {"linear", "circular", "nearest", "previous"}, optional
        Interpolation method. Default: "circular" for directions, "previous"
        for month, "linear" otherwise.
    max_gap_hours : float, optional
        Warn when a model step falls in a data gap longer than this.

    Returns
    -------
    np.ndarray of length `length`
    """
    if source is None:
        if default is None:
            raise ValueError(f"no source given for '{column}' and no default available")
        return np.full(length, float(default))

    if not isinstance(source, str):
        return np.full(length, float(source))

    df = pd.read_csv(source, sep=sep)
    if time_col not in df.columns or column not in df.columns:
        raise ValueError(f"{source}: expected columns '{time_col}' and '{column}', "
                         f"found {list(df.columns)}")
    idx = _to_utc_naive(pd.DatetimeIndex(pd.to_datetime(df[time_col], utc=True)))
    series = pd.Series(df[column].astype(float).values, index=idx)

    n_missing = int(series.isna().sum())
    if n_missing > 0:
        print(f"load_timeseries: {n_missing} missing value(s) in '{column}' ({source}) "
              f"are bridged by interpolation")

    # ---------------- legacy mode: row by row ----------------
    if model_dates is None:
        # gaps filled in place so that row k still corresponds to step k
        values = series.interpolate(method="time", limit_direction="both").values
        if len(values) < length:
            raise ValueError(
                f"{source} has {len(values)} records but the run needs {length} steps. "
                f"Set time_params.start_date to align the forcing by date instead.")
        return values[:length]

    # ---------------- date-aligned mode ----------------
    series = series.dropna().sort_index()
    series = series[~series.index.duplicated(keep="first")]
    if method is None:
        method = ("circular" if column in CIRCULAR_COLUMNS
                  else "previous" if column in STEP_COLUMNS else "linear")

    t_data = series.index.values.astype("datetime64[s]").astype(np.int64).astype(float)
    t_model = model_dates.values.astype("datetime64[s]").astype(np.int64).astype(float)
    if t_model[0] < t_data[0] or t_model[-1] > t_data[-1]:
        raise ValueError(
            f"{source} covers {series.index[0]} to {series.index[-1]}, but the model "
            f"runs from {model_dates[0]} to {model_dates[-1]}. Adjust start_date/end_date.")

    v = series.values
    if method == "linear":
        out = np.interp(t_model, t_data, v)
    elif method == "circular":
        rad = np.radians(v)
        s = np.interp(t_model, t_data, np.sin(rad))
        c = np.interp(t_model, t_data, np.cos(rad))
        out = np.degrees(np.arctan2(s, c)) % 360.0
    elif method in ("previous", "nearest"):
        if method == "previous":
            j = np.searchsorted(t_data, t_model, side="right") - 1
        else:
            j = np.clip(np.searchsorted(t_data, t_model), 1, len(t_data) - 1)
            j = np.where(t_model - t_data[j - 1] <= t_data[j] - t_model, j - 1, j)
        out = v[np.clip(j, 0, len(v) - 1)]
    else:
        raise ValueError(f"unknown interpolation method '{method}'")

    if max_gap_hours is not None:
        gaps = np.diff(t_data) > max_gap_hours * 3600
        if gaps.any():
            k = np.searchsorted(t_data, t_model, side="right") - 1
            k = np.clip(k, 0, len(gaps) - 1)
            n_in_gap = int(gaps[k].sum())
            if n_in_gap:
                print(f"load_timeseries: {n_in_gap} model step(s) of '{column}' fall in "
                      f"data gaps longer than {max_gap_hours} h")
    return out


def resolve_path(source, base_dirs):
    """Return source unchanged if it is not a file name; otherwise the first existing path."""
    if not isinstance(source, str):
        return source
    if os.path.isabs(source) or os.path.isfile(source):
        return source
    for d in base_dirs:
        if d and os.path.isfile(os.path.join(d, source)):
            return os.path.join(d, source)
    raise FileNotFoundError(f"forcing file '{source}' not found (looked in: cwd, "
                            f"{', '.join(d for d in base_dirs if d)})")


def trapezoid_positive(y, x):
    """
    Integrate using trapezoid, counting only positive values.
    Negative values are clipped to zero.
    """
    y_clip = np.maximum(y, 0)
    # Use trapezoid (numpy 2.x) or trapz (numpy 1.x) for compatibility
    try:
        return np.trapezoid(y_clip, x)
    except AttributeError:
        return np.trapz(y_clip, x)

def load_config(path="config.yaml"):
    """
    Load a YAML configuration file.

    Parameters
    ----------
    path : str, optional
        Path to the YAML file. Default is ``config.yaml``.

    Returns
    -------
    dict
        Parsed YAML content.
    """
    with open(path, "r") as f:
        return yaml.safe_load(f)

### Functions for volume calculations
def ramp_volume(sramp_potential, sramp, ysprim, ys, betas, dfoot, substrate_x, substrate_z):
    '''
    Calculate volume of the ramp part of the dune.
    '''
    # toe position consistent with slope
    yspotential = ys + ((sramp_potential-sramp) / betas)

    # ramp line
    dune_x_line = np.array([ysprim, yspotential])
    dune_z_line = np.array([sramp_potential + dfoot, dfoot])
    
    n_per_segment = 100  # how many points per segment
    x_dense = np.concatenate([np.linspace(dune_x_line[i], dune_x_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_line)-1)] + [[dune_x_line[-1]]])
    z_dense = np.concatenate([np.linspace(dune_z_line[i], dune_z_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_line)-1)] + [[dune_z_line[-1]]])

    # substrate under ramp
    z_sub_line = np.interp(x_dense, substrate_x, substrate_z)

    # trapezoidal integration
    return trapezoid_positive(z_dense - z_sub_line, x_dense)

def lee_volume(ylprim_potential, dune_x, dune_z, betal, substrate_x, substrate_z):
    '''
    Calculate volume of the lee part of the dune.
    '''
    # toe position consistent with slope
    #ylpotential = ylprim_potential - ((s_new_c) / betal) 
    ylpotential = ylprim_potential - ((dune_z['lee_crest'] -dune_z['lee_foot']) / betal) 

    # lee line
    #dune_x_line = np.array([ylpotential, ylprim_potential, ylprim_new_c]) #to calculate, keep the initial ylprim always otherwise u will have the same lee always!
    dune_x_line = np.array([ylpotential, ylprim_potential, dune_x['lee_crest']]) #to calculate, keep the initial ylprim always otherwise u will have the same lee always!
    dune_z_line = np.array([dune_z['lee_foot'], dune_z['lee_crest'], dune_z['lee_crest']]) # new dune height

    n_per_segment = 100  # how many points per segment
    x_dense = np.concatenate([np.linspace(dune_x_line[i], dune_x_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_line)-1)] + [[dune_x_line[-1]]])
    z_dense = np.concatenate([np.linspace(dune_z_line[i], dune_z_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_line)-1)] + [[dune_z_line[-1]]])
   
    # substrate under lee side
    z_sub_line = np.interp(x_dense, substrate_x, substrate_z)

    # trapezoidal integration
    return trapezoid_positive(z_dense - z_sub_line, x_dense)

def total_volume(dune_x, dune_z, substrate_x, substrate_z):
    '''
    Compute the total dune volume between dune and substrate.
    Interpolates the dune curve so integration is more accurate.
    '''
    # Remove any None values from dune_x and dune_z (and keep them in sync)
    dune_x, dune_z = zip(*[(x, z) for x, z in zip(dune_x, dune_z) if x is not None and z is not None])
    dune_x = list(dune_x)
    dune_z = list(dune_z)

    n_per_segment = 100  # how many points per segment
    x_dense = np.concatenate([np.linspace(dune_x[i], dune_x[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x)-1)] + [[dune_x[-1]]])
    z_dense = np.concatenate([np.linspace(dune_z[i], dune_z[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z)-1)] + [[dune_z[-1]]])

    # interpolate substrate under dune
    z_sub = np.interp(x_dense, substrate_x, substrate_z)

    # trapezoidal integration
    return trapezoid_positive(z_dense - z_sub, x_dense)

# def partial_volume(dune_x, dune_z, substrate_x, substrate_z,
#                    x_min=None, x_max=None):
#     """
#     Integrate dune volume above substrate between optional x-limits.

#     Parameters
#     ----------
#     dune_x : dict
#         Dune profile x-coordinates keyed by pivot name.
#     dune_z : dict
#         Dune profile elevations keyed by pivot name.
#     substrate_x : array-like
#         Substrate x-coordinates.
#     substrate_z : array-like
#         Substrate elevations.
#     x_min : float or None, optional
#         Left integration limit. Uses profile minimum when ``None``.
#     x_max : float or None, optional
#         Right integration limit. Uses profile maximum when ``None``.

#     Returns
#     -------
#     float
#         Integrated positive sediment volume (m³/m).
#     """

#     # Remove None values
#     dune_x = {k: v for k, v in dune_x.items() if v is not None}
#     dune_z = {k: v for k, v in dune_z.items() if v is not None}

#     # --- Convert dicts to ordered arrays ---
#     order = [
#         'back_ref', 'lee_foot', 'lee_crest', 'crest_temp',
#         'seaward_crest', 'ramp_dike_temp', 'ramp_crest',
#         'ramp_toe_temp', 'ramp_toe', 'shoreline'
#     ]

#     x = np.array([dune_x[k] for k in order if k in dune_x])
#     z = np.array([dune_z[k] for k in order if k in dune_z])

#     # Sort by x to ensure monotone integration.  During certain deposition
#     # states (detach_tag==2) seaward_crest can be placed seaward of
#     # ramp_dike_temp/ramp_crest, producing a non-monotone ordering that
#     # causes np.trapz to subtract area rather than add it.  Sorting makes
#     # partial_volume always return the physically correct sediment volume
#     # without altering any of the morphodynamic update logic.
#     #
#     # Before sorting, snap specific profile-point pairs whose canonical order
#     # can accumulate a tiny numerical violation over many timesteps.  Snapping
#     # them to coincide lets the stable sort keep their canonical ordering,
#     # preventing large discontinuous volume jumps.  Pairs that can legitimately
#     # be far out of canonical order (e.g. seaward_crest vs ramp_crest in the
#     # detached case) are left to the sort.
    
#     _present = {k: i for i, k in enumerate(k for k in order if k in dune_x)}
#     if 'crest_temp' in _present and 'seaward_crest' in _present:
#         ict, isc = _present['crest_temp'], _present['seaward_crest']
#         if x[ict] > x[isc]:
#             x[ict] = x[isc]   # crest_temp must not be seaward of seaward_crest
#     if 'seaward_crest' in _present and 'ramp_dike_temp' in _present:
#         isc, irdt = _present['seaward_crest'], _present['ramp_dike_temp']
#         if x[isc] > x[irdt]:
#             x[isc] = x[irdt]  # seaward_crest must not be seaward of ramp_dike_temp
#     if 'ramp_dike_temp' in _present and 'ramp_crest' in _present:
#         irdt, irc = _present['ramp_dike_temp'], _present['ramp_crest']
#         if x[irc] < x[irdt]:
#             x[irc] = x[irdt]  # ramp_crest must not be landward of ramp_dike_temp

#     sort_idx = np.argsort(x, kind='stable')
#     x = x[sort_idx]
#     z = z[sort_idx]
    
    
#     # Densify dune curve
#     n_per_segment = 100

#     x_dense = np.concatenate([
#         np.linspace(x[i], x[i + 1], n_per_segment, endpoint=False)
#         for i in range(len(x) - 1)
#     ] + [[x[-1]]])

#     z_dense = np.concatenate([
#         np.linspace(z[i], z[i + 1], n_per_segment, endpoint=False)
#         for i in range(len(z) - 1)
#     ] + [[z[-1]]])

#     # Interpolate substrate
#     z_sub = np.interp(x_dense, substrate_x, substrate_z)

#     # Restrict to x limits
#     if x_min is not None or x_max is not None:
#         x_min = x_dense[0] if x_min is None else max(x_min, x_dense[0])
#         x_max = x_dense[-1] if x_max is None else min(x_max, x_dense[-1])

#         z_min = np.interp(x_min, x_dense, z_dense)
#         z_max = np.interp(x_max, x_dense, z_dense)
#         z_sub_min = np.interp(x_min, x_dense, z_sub)
#         z_sub_max = np.interp(x_max, x_dense, z_sub)

#         mask = (x_dense >= x_min) & (x_dense <= x_max)
#         x_clip = x_dense[mask]
#         z_clip = z_dense[mask]
#         z_sub_clip = z_sub[mask]

#         if len(x_clip) == 0 or x_clip[0] > x_min:
#             x_clip = np.insert(x_clip, 0, x_min)
#             z_clip = np.insert(z_clip, 0, z_min)
#             z_sub_clip = np.insert(z_sub_clip, 0, z_sub_min)

#         if x_clip[-1] < x_max:
#             x_clip = np.append(x_clip, x_max)
#             z_clip = np.append(z_clip, z_max)
#             z_sub_clip = np.append(z_sub_clip, z_sub_max)
#     else:
#         x_clip, z_clip, z_sub_clip = x_dense, z_dense, z_sub

#     return trapezoid_positive(z_clip - z_sub_clip, x_clip)
def partial_volume(dune_x, dune_z, substrate_x, substrate_z,
                   x_min=None, x_max=None):
    """
    Integrate dune volume above substrate between optional x-limits.
 
    Parameters
    ----------
    dune_x : dict
        Dune profile x-coordinates keyed by pivot name.
    dune_z : dict
        Dune profile elevations keyed by pivot name.
    substrate_x : array-like
        Substrate x-coordinates.
    substrate_z : array-like
        Substrate elevations.
    x_min : float or None, optional
        Left integration limit. Uses profile minimum when ``None``.
    x_max : float or None, optional
        Right integration limit. Uses profile maximum when ``None``.
 
    Returns
    -------
    float
        Integrated positive sediment volume (m³/m).
    """
 
    # Remove None values
    dune_x = {k: v for k, v in dune_x.items() if v is not None}
    dune_z = {k: v for k, v in dune_z.items() if v is not None}
 
    # --- Convert dicts to ordered arrays ---
    order = [
        'back_ref', 'lee_foot', 'lee_crest', 'crest_temp',
        'seaward_crest', 'ramp_dike_temp', 'ramp_crest',
        'ramp_toe_temp', 'ramp_toe', 'shoreline'
    ]
 
    x = np.array([dune_x[k] for k in order if k in dune_x])
    z = np.array([dune_z[k] for k in order if k in dune_z])
 
    # Sort by x to ensure monotone integration.  During certain deposition
    # states (detach_tag==2) seaward_crest can be placed seaward of
    # ramp_dike_temp/ramp_crest, producing a non-monotone ordering that
    # causes np.trapz to subtract area rather than add it.  Sorting makes
    # partial_volume always return the physically correct sediment volume
    # without altering any of the morphodynamic update logic.
    #
    # Before sorting, snap specific profile-point pairs whose canonical order
    # can accumulate a tiny numerical violation over many timesteps.  Snapping
    # them to coincide lets the stable sort keep their canonical ordering,
    # preventing large discontinuous volume jumps.  Pairs that can legitimately
    # be far out of canonical order (e.g. seaward_crest vs ramp_crest in the
    # detached case) are left to the sort.
    
    _present = {k: i for i, k in enumerate(k for k in order if k in dune_x)}
    if 'crest_temp' in _present and 'seaward_crest' in _present:
        ict, isc = _present['crest_temp'], _present['seaward_crest']
        if x[ict] > x[isc]:
            x[ict] = x[isc]   # crest_temp must not be seaward of seaward_crest
    if 'seaward_crest' in _present and 'ramp_dike_temp' in _present:
        isc, irdt = _present['seaward_crest'], _present['ramp_dike_temp']
        if x[isc] > x[irdt]:
            x[isc] = x[irdt]  # seaward_crest must not be seaward of ramp_dike_temp
    if 'ramp_dike_temp' in _present and 'ramp_crest' in _present:
        irdt, irc = _present['ramp_dike_temp'], _present['ramp_crest']
        if x[irc] < x[irdt]:
            x[irc] = x[irdt]  # ramp_crest must not be landward of ramp_dike_temp
 
    sort_idx = np.argsort(x, kind='stable')
    x = x[sort_idx]
    z = z[sort_idx]
    
    
    # Exact integral of max(profile - substrate, 0) for piecewise-linear curves.
    # Integrates segment by segment, splitting at every substrate breakpoint and
    # at the exact zero crossings, so the result has no quadrature error and is
    # consistent between any two profile states.
    lo = x[0] if x_min is None else max(x_min, x[0])
    hi = x[-1] if x_max is None else min(x_max, x[-1])
    sx_arr = np.asarray(substrate_x, dtype=float)
    sz_arr = np.asarray(substrate_z, dtype=float)
    V = 0.0
    for i in range(len(x) - 1):
        a, b = max(x[i], lo), min(x[i + 1], hi)
        if b <= a or x[i + 1] <= x[i]:
            continue
        inner = sx_arr[(sx_arr > a) & (sx_arr < b)]
        nodes = np.concatenate(([a], inner, [b]))
        zp = z[i] + (z[i + 1] - z[i]) * (nodes - x[i]) / (x[i + 1] - x[i])
        h = zp - np.interp(nodes, sx_arr, sz_arr)
        for j in range(len(nodes) - 1):
            w = nodes[j + 1] - nodes[j]
            ha, hb = h[j], h[j + 1]
            if ha >= 0 and hb >= 0:
                V += 0.5 * (ha + hb) * w
            elif ha > 0 > hb:
                V += 0.5 * ha * w * ha / (ha - hb)
            elif hb > 0 > ha:
                V += 0.5 * hb * w * hb / (hb - ha)
    return V
 

### Vegetation-related functions
def vegNield(dt,sold,snew, ylnew, ylold, ysnew, ysold, srampnew, srampold, betas, betal, rhov_df_spec1, rhov_dt_spec1, rhov_db_spec1, rhov_df_spec2, rhov_dt_spec2, rhov_db_spec2):
    '''
    Vegetation growth function adapted from Nield and Baas, 2008 and DUBEVEG model (Keijsers et. al., 2016), for two species
    '''

    # Define vertex values for both species.
    sp1_peak = 0.2  # Growth peak for species 1.
    sp2_peak = 0.05  # Growth peak for species 2.

    # Convert time step to years
    dtYear = dt/(3600*24*365)  # Convert time step to years.

    # species 1 - pioneer vegetation (e.g. Ammophila arenaria)
    
    # Sedimentation.
    x1_spec1 = -0.6*dtYear
    x2_spec1 = 0.2*dtYear
    x3_spec1 = 0.6*dtYear
    x4_spec1 = 2.0*dtYear
    x5_spec1 = 2.2*dtYear
    
    # Growth.
    y1_spec1 = -0.5*dtYear
    y2_spec1 = 0.0*dtYear
    y3_spec1 = sp1_peak*dtYear 
    y4_spec1 = 0.0*dtYear
    y5_spec1 = -0.5*dtYear

    # species 2 - mature vegetation (e.g. Elymus farctus or Buckthrorn)
    x1_spec2 = -1.4*dtYear
    x2_spec2 = -0.65*dtYear
    x3_spec2 = 0.0*dtYear
    x4_spec2 = 0.2*dtYear
    x5_spec2 = 2.8*dtYear

    y1_spec2 = -0.5*dtYear
    y2_spec2 = 0.0*dtYear
    y3_spec2 = sp2_peak*dtYear
    y4_spec2 = 0.0*dtYear
    y5_spec2 = -0.5*dtYear

    # Calculate the sedimentation map.
    dh_df = 0.0
    if (abs(srampnew-srampold)>0.0):
        dh_df = srampnew-srampold
    elif (abs(ysnew-ysold)>0.0):  # Movement of the dune toe.
        dh_df=(ysnew-ysold)*betas
            
    dh_dt = (snew-sold)
    dh_db = -(ylnew-ylold)*betal

    # Calculate slopes between vertices.
    s12_spec1=(y2_spec1-y1_spec1)/(x2_spec1-x1_spec1)
    s23_spec1=(y3_spec1-y2_spec1)/(x3_spec1-x2_spec1)
    s34_spec1=(y4_spec1-y3_spec1)/(x4_spec1-x3_spec1)
    s45_spec1=(y5_spec1-y4_spec1)/(x5_spec1-x4_spec1)

    s12_spec2=(y2_spec2-y1_spec2)/(x2_spec2-x1_spec2)
    s23_spec2=(y3_spec2-y2_spec2)/(x3_spec2-x2_spec2)
    s34_spec2=(y4_spec2-y3_spec2)/(x4_spec2-x3_spec2)
    s45_spec2=(y5_spec2-y4_spec2)/(x5_spec2-x4_spec2)

    # Calculate the new vegetation cover at the dune front for species 1.
    if (dh_df<x1_spec1):
        rhov_dfnew_spec1 = 0.0001
    elif (dh_df>=x1_spec1 and dh_df<x2_spec1):
        rhov_dfnew_spec1 = rhov_df_spec1 + ((dh_df-x1_spec1)*s12_spec1 + y1_spec1)
    elif (dh_df>=x2_spec1 and dh_df<x3_spec1):
        rhov_dfnew_spec1 = rhov_df_spec1 + ((dh_df-x2_spec1)*s23_spec1 + y2_spec1)
    elif (dh_df>=x3_spec1 and dh_df<x4_spec1):
        rhov_dfnew_spec1 = rhov_df_spec1 + ((dh_df-x3_spec1)*s34_spec1 + y3_spec1)
    elif (dh_df>=x4_spec1 and dh_df<x5_spec1):
        rhov_dfnew_spec1 = rhov_df_spec1 + ((dh_df-x4_spec1)*s45_spec1 + y4_spec1)
    elif (dh_df>=x5_spec1):
        rhov_dfnew_spec1 = rhov_df_spec1 + y5_spec1

    # Calculate the new vegetation cover at the dune top for species 1.
    if (dh_dt<x1_spec1):
        rhov_dtnew_spec1 = 0.0
    elif (dh_dt>=x1_spec1 and dh_dt<x2_spec1):
        rhov_dtnew_spec1 = rhov_dt_spec1 + ((dh_dt-x1_spec1)*s12_spec1 + y1_spec1)
    elif (dh_dt>=x2_spec1 and dh_dt<x3_spec1):
        rhov_dtnew_spec1 = rhov_dt_spec1 + ((dh_dt-x2_spec1)*s23_spec1 + y2_spec1)
    elif (dh_dt>=x3_spec1 and dh_dt<x4_spec1):
        rhov_dtnew_spec1 = rhov_dt_spec1 + ((dh_dt-x3_spec1)*s34_spec1 + y3_spec1)
    elif (dh_dt>=x4_spec1 and dh_dt<x5_spec1):
        rhov_dtnew_spec1 = rhov_dt_spec1 + ((dh_dt-x4_spec1)*s45_spec1 + y4_spec1)
    elif (dh_dt>=x5_spec1):
        rhov_dtnew_spec1 = rhov_dt_spec1 + y5_spec1

    # Calculate the new vegetation cover at the dune back for species 1.
    if (dh_db<x1_spec1):
        rhov_dbnew_spec1 = 0.0
    elif (dh_db>=x1_spec1 and dh_db<x2_spec1):
        rhov_dbnew_spec1 = rhov_db_spec1 + ((dh_db-x1_spec1)*s12_spec1 + y1_spec1)
    elif (dh_db>=x2_spec1 and dh_db<x3_spec1):
        rhov_dbnew_spec1 = rhov_db_spec1 + ((dh_db-x2_spec1)*s23_spec1 + y2_spec1)
    elif (dh_db>=x3_spec1 and dh_db<x4_spec1):
        rhov_dbnew_spec1 = rhov_db_spec1 + ((dh_db-x3_spec1)*s34_spec1 + y3_spec1)
    elif (dh_db>=x4_spec1 and dh_db<x5_spec1):
        rhov_dbnew_spec1 = rhov_db_spec1 + ((dh_db-x4_spec1)*s45_spec1 + y4_spec1)
    elif (dh_db>=x5_spec1):
        rhov_dbnew_spec1 = rhov_db_spec1 + y5_spec1

    # Calculate the dune-front vegetation cover for species 2 only when
    # species 1 or species 2 is already established.

    if rhov_dfnew_spec1 > 0.5 or rhov_df_spec2 > 0.0:
        if (dh_df<x1_spec2):
            rhov_dfnew_spec2 = 0.0
        elif (dh_df>=x1_spec2 and dh_df<x2_spec2):
            rhov_dfnew_spec2 = rhov_df_spec2 + ((dh_df-x1_spec2)*s12_spec2 + y1_spec2)
        elif (dh_df>=x2_spec2 and dh_df<x3_spec2):
            rhov_dfnew_spec2 = rhov_df_spec2 + ((dh_df-x2_spec2)*s23_spec2 + y2_spec2)
        elif (dh_df>=x3_spec2 and dh_df<x4_spec2):
            rhov_dfnew_spec2 = rhov_df_spec2 + ((dh_df-x3_spec2)*s34_spec2 + y3_spec2)
        elif (dh_df>=x4_spec2 and dh_df<x5_spec2):
            rhov_dfnew_spec2 = rhov_df_spec2 + ((dh_df-x4_spec2)*s45_spec2 + y4_spec2)
        elif (dh_df>=x5_spec2):
            rhov_dfnew_spec2 = rhov_df_spec2 + y5_spec2
    else:
        rhov_dfnew_spec2 = 0.0

    # calculate the new vegetation height for dune top for species 2
    if rhov_dtnew_spec1 > 0.5 or rhov_dt_spec2 > 0.0:
        if (dh_dt<x1_spec2):
            rhov_dtnew_spec2 = 0.0
        elif (dh_dt>=x1_spec2 and dh_dt<x2_spec2):
            rhov_dtnew_spec2 = rhov_dt_spec2 + ((dh_dt-x1_spec2)*s12_spec2 + y1_spec2)
        elif (dh_dt>=x2_spec2 and dh_dt<x3_spec2):
            rhov_dtnew_spec2 = rhov_dt_spec2 + ((dh_dt-x2_spec2)*s23_spec2 + y2_spec2)
        elif (dh_dt>=x3_spec2 and dh_dt<x4_spec2):
            rhov_dtnew_spec2 = rhov_dt_spec2 + ((dh_dt-x3_spec2)*s34_spec2 + y3_spec2)
        elif (dh_dt>=x4_spec2 and dh_dt<x5_spec2):
            rhov_dtnew_spec2 = rhov_dt_spec2 + ((dh_dt-x4_spec2)*s45_spec2 + y4_spec2)
        elif (dh_dt>=x5_spec2):
            rhov_dtnew_spec2 = rhov_dt_spec2 + y5_spec2
    else:
        rhov_dtnew_spec2 = 0.0

    # calculate the new vegetation height for dune back for species 2

    if rhov_dbnew_spec1 > 0.5 or rhov_db_spec2 > 0.0:
        if (dh_db<x1_spec2):
            rhov_dbnew_spec2 = 0.0
        elif (dh_db>=x1_spec2 and dh_db<x2_spec2):
            rhov_dbnew_spec2 = rhov_db_spec2 + ((dh_db-x1_spec2)*s12_spec2 + y1_spec2)
        elif (dh_db>=x2_spec2 and dh_db<x3_spec2):
            rhov_dbnew_spec2 = rhov_db_spec2 + ((dh_db-x2_spec2)*s23_spec2 + y2_spec2)
        elif (dh_db>=x3_spec2 and dh_db<x4_spec2):
            rhov_dbnew_spec2 = rhov_db_spec2 + ((dh_db-x3_spec2)*s34_spec2 + y3_spec2)
        elif (dh_db>=x4_spec2 and dh_db<x5_spec2):
            rhov_dbnew_spec2 = rhov_db_spec2 + ((dh_db-x4_spec2)*s45_spec2 + y4_spec2)
        elif (dh_db>=x5_spec2):
            rhov_dbnew_spec2 = rhov_db_spec2 + y5_spec2
    else:   
        rhov_dbnew_spec2 = 0.0

    # cap the vegetation height to a minimum value
    if (rhov_dfnew_spec1 < 0):
        rhov_dfnew_spec1 = 0.0
    if (rhov_dtnew_spec1 < 0):
        rhov_dtnew_spec1 = 0.0
    if (rhov_dbnew_spec1 < 0):
        rhov_dbnew_spec1 = 0.0

    if (rhov_dfnew_spec2 < 0):
        rhov_dfnew_spec2 = 0.0
    if (rhov_dtnew_spec2 < 0):
        rhov_dtnew_spec2 = 0.0
    if (rhov_dbnew_spec2 < 0):
        rhov_dbnew_spec2 = 0.0

    if (rhov_dfnew_spec1 > 1):
        rhov_dfnew_spec1 = 1.0
    if (rhov_dtnew_spec1 > 1):
        rhov_dtnew_spec1 = 1.0
    if (rhov_dbnew_spec1 > 1):
        rhov_dbnew_spec1 = 1.0

    if (rhov_dfnew_spec2 > 1):
        rhov_dfnew_spec2 = 1.0
    if (rhov_dtnew_spec2 > 1):
        rhov_dtnew_spec2 = 1.0
    if (rhov_dbnew_spec2 > 1):
        rhov_dbnew_spec2 = 1.0

    # calculate the balance between the two species
    if (rhov_dfnew_spec1 + rhov_dfnew_spec2 > 1.0): # if the sum of the two species is greater than 1.0, then the difference is taken from the pioneer species
        rhov_dfnew_spec1 = 1.0 - rhov_dfnew_spec2

    if (rhov_dtnew_spec1 + rhov_dtnew_spec2 > 1.0): # if the sum of the two species is greater than 1.0, then the difference is taken from the pioneer species
        rhov_dtnew_spec1 = 1.0 - rhov_dtnew_spec2

    if (rhov_dbnew_spec1 + rhov_dbnew_spec2 > 1.0): # if the sum of the two species is greater than 1.0, then the difference is taken from the pioneer species
        rhov_dbnew_spec1 = 1.0 - rhov_dbnew_spec2

    return rhov_dfnew_spec1, rhov_dtnew_spec1, rhov_dbnew_spec1, rhov_dfnew_spec2, rhov_dtnew_spec2, rhov_dbnew_spec2

def seasonal_factor(month):
    """Returns seasonal growth multiplier (0–1) for pioneer and mature vegetation."""
    # Example: growth in spring/summer, zero in winter
    month_factors = [0.05, 0.05, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.05]
    month_factors = [0.05, 0.05, 0.7, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.7, 0.7, 0.05]
    month_factors = [
    0.05,  # Jan
    0.05,  # Feb
    0.75,  # Mar
    1.0,  # Apr
    1.0,  # May
    1.0,  # Jun
    1.0,  # Jul
    1.0,  # Aug
    1.0,  # Sep
    1.0,  # Oct
    0.75,  # Nov
    0.05,  # Dec
]

    return month_factors[month-1]

def vegNield_seasonal(dt, sold, snew, ylnew, ylold, ysnew, ysold,
                      srampnew, srampold, betas, betal,
                      rhov_df_spec1, rhov_dt_spec1, rhov_db_spec1,
                      rhov_df_spec2, rhov_dt_spec2, rhov_db_spec2,
                      month=None, winter_decay_month=0.05, winter_decay_year=0.0,
                      winter_months=(11, 12, 1, 2, 3), winter_decay_type='relative'):
    
    '''
    Vegetation growth function adapted from Nield and Baas, 2008 and DUBEVEG model (Keijsers et. al., 2016), for two species
    with seasonal growth modulation.

    If the vegetation update interval dt (vegdt) is one year, the annual Nield and Baas (2008) curves are used for
    species 1 instead of the monthly Ammophila curves, and the monthly growth multiplier is not applied (both species).
    The winter decay is kept: winter_decay_year is applied once at every yearly update, independent of the month.

    Winter decay (set in the yaml, vegetation section):
        winter_decay_month : reduction applied at each update in a winter month
        winter_decay_year  : reduction applied at each yearly update (vegdt of one year)
        winter_months      : months counted as winter
        winter_decay_type  : 'relative' -> cover *= (1 - decay)   (fraction of what is there)
                             'absolute' -> cover -= decay         (fixed amount of cover)
    '''
    
    # # define vertices values for both species
    # sp1_peak = 0.2  # pioneer species peak growth
    sp2_peak = 0.05 # mature species peak growth

    dtYear = dt/(3600*24*365)  # timestep in years

    # yearly vegetation update (vegdt of one year, 365 to 366 days): annual curves, no monthly multiplier
    annual = abs(dt - 3600*24*365) <= 3600*24*2
    # dtMonth = dt/(3600*24*30.437)  # timestep in years

    
    # --- species 1: Ammophila ---
    # x1_spec1, x2_spec1, x3_spec1, x4_spec1, x5_spec1 = -0.6*dtYear, 0.2*dtYear, 0.6*dtYear, 2.0*dtYear, 2.2*dtYear
    # y1_spec1, y2_spec1, y3_spec1, y4_spec1, y5_spec1 = -0.5*dtYear, 0.0*dtYear, sp1_peak*dtYear, 0.0*dtYear, -0.5*dtYear
    
    # # --- species 2: Elymus/Buckthorn ---
    x1_spec2, x2_spec2, x3_spec2, x4_spec2, x5_spec2 = -1.4*dtYear, -0.65*dtYear, 0.0*dtYear, 0.2*dtYear, 2.8*dtYear
    y1_spec2, y2_spec2, y3_spec2, y4_spec2, y5_spec2 = -0.5*dtYear, 0.0*dtYear, sp2_peak*dtYear, 0.0*dtYear, -0.5*dtYear

    if annual:
        # Ammophila (species 1): annual curves from Nield and Baas (2008), as in vegNield
        sp1_peak = 0.2
        x1_spec1, x2_spec1, x3_spec1, x4_spec1, x5_spec1 = -0.6*dtYear, 0.2*dtYear, 0.6*dtYear, 2.0*dtYear, 2.2*dtYear
        y1_spec1, y2_spec1, y3_spec1, y4_spec1, y5_spec1 = -0.5*dtYear, 0.0*dtYear, sp1_peak*dtYear, 0.0*dtYear, -0.5*dtYear
    else:
        # test with montlhy curves for ammophila
        # Ammophila (species 1)
        x1_spec1, y1_spec1 = -0.25, -0.30
        x2_spec1, y2_spec1 =  0, -0.01
        x3_spec1, y3_spec1 =  0.07,  0.12
        x4_spec1, y4_spec1 =  0.15,  0.02
        x5_spec1, y5_spec1 =  0.30, -0.10   
    
    # --- Sedimentation/erosion ---
    dh_df = 0.0
    if abs(srampnew-srampold) > 0.0:
        dh_df = srampnew-srampold
    elif abs(ysnew-ysold) > 0.0:
        dh_df = (ysnew-ysold)*betas

    dh_dt = snew - sold
    dh_db = -(ylnew-ylold)*betal

    # --- Slopes ---
    s12_spec1 = (y2_spec1-y1_spec1)/(x2_spec1-x1_spec1)
    s23_spec1 = (y3_spec1-y2_spec1)/(x3_spec1-x2_spec1)
    s34_spec1 = (y4_spec1-y3_spec1)/(x4_spec1-x3_spec1)
    s45_spec1 = (y5_spec1-y4_spec1)/(x5_spec1-x4_spec1)

    s12_spec2 = (y2_spec2-y1_spec2)/(x2_spec2-x1_spec2)
    s23_spec2 = (y3_spec2-y2_spec2)/(x3_spec2-x2_spec2)
    s34_spec2 = (y4_spec2-y3_spec2)/(x4_spec2-x3_spec2)
    s45_spec2 = (y5_spec2-y4_spec2)/(x5_spec2-x4_spec2)

    # --- Helper to compute growth increment with seasonal modulation ---
    def compute_increment(dh, x_vals, y_vals, s_vals, rhov_old):
        if dh < x_vals[0]:
            #increment = 0.0
            increment = -rhov_old
        elif dh >= x_vals[0] and dh < x_vals[1]:
            increment = (dh-x_vals[0])*s_vals[0] + y_vals[0]
        elif dh >= x_vals[1] and dh < x_vals[2]:
            increment = (dh-x_vals[1])*s_vals[1] + y_vals[1]
        elif dh >= x_vals[2] and dh < x_vals[3]:
            increment = (dh-x_vals[2])*s_vals[2] + y_vals[2]
        elif dh >= x_vals[3] and dh < x_vals[4]:
            increment = (dh-x_vals[3])*s_vals[3] + y_vals[3]
        else:
            increment = y_vals[4]

        # Apply seasonal factor only to positive increments (monthly updates only; a yearly curve already spans the seasons)
        if increment > 0 and month is not None and not annual:
            increment *= seasonal_factor(month)

        return max(rhov_old + increment, 0.0)  # ensure >= 0

    # --- Compute new vegetation ---
    rhov_dfnew_spec1 = compute_increment(dh_df, [x1_spec1, x2_spec1, x3_spec1, x4_spec1, x5_spec1],
                                         [y1_spec1, y2_spec1, y3_spec1, y4_spec1, y5_spec1],
                                         [s12_spec1, s23_spec1, s34_spec1, s45_spec1],
                                         rhov_df_spec1)
    rhov_dtnew_spec1 = compute_increment(dh_dt, [x1_spec1, x2_spec1, x3_spec1, x4_spec1, x5_spec1],
                                         [y1_spec1, y2_spec1, y3_spec1, y4_spec1, y5_spec1],
                                         [s12_spec1, s23_spec1, s34_spec1, s45_spec1],
                                         rhov_dt_spec1)
    rhov_dbnew_spec1 = compute_increment(dh_db, [x1_spec1, x2_spec1, x3_spec1, x4_spec1, x5_spec1],
                                         [y1_spec1, y2_spec1, y3_spec1, y4_spec1, y5_spec1],
                                         [s12_spec1, s23_spec1, s34_spec1, s45_spec1],
                                         rhov_db_spec1)

    # Species 2 only grows if species 1 is present
    if rhov_dfnew_spec1 > 0.5 or rhov_df_spec2 > 0.0:
        rhov_dfnew_spec2 = compute_increment(dh_df, [x1_spec2, x2_spec2, x3_spec2, x4_spec2, x5_spec2],
                                             [y1_spec2, y2_spec2, y3_spec2, y4_spec2, y5_spec2],
                                             [s12_spec2, s23_spec2, s34_spec2, s45_spec2],
                                             rhov_df_spec2)
    else:
        rhov_dfnew_spec2 = 0.0

    if rhov_dtnew_spec1 > 0.5 or rhov_dt_spec2 > 0.0:
        rhov_dtnew_spec2 = compute_increment(dh_dt, [x1_spec2, x2_spec2, x3_spec2, x4_spec2, x5_spec2],
                                             [y1_spec2, y2_spec2, y3_spec2, y4_spec2, y5_spec2],
                                             [s12_spec2, s23_spec2, s34_spec2, s45_spec2],
                                             rhov_dt_spec2)
    else:
        rhov_dtnew_spec2 = 0.0

    if rhov_dbnew_spec1 > 0.5 or rhov_db_spec2 > 0.0:
        rhov_dbnew_spec2 = compute_increment(dh_db, [x1_spec2, x2_spec2, x3_spec2, x4_spec2, x5_spec2],
                                             [y1_spec2, y2_spec2, y3_spec2, y4_spec2, y5_spec2],
                                             [s12_spec2, s23_spec2, s34_spec2, s45_spec2],
                                             rhov_db_spec2)
    else:
        rhov_dbnew_spec2 = 0.0

    # reduction of vegetation coverage due to frosting and reduction in winter
    
    # winter_months = [11, 12, 1, 2, 3]
    # winter_decay_month = 0.01  # reduction measuerd of 10-20% per winter, so about 
    # winter_decay_year = 0.00   # yearly update: applied once per update, whatever the month (every year holds one winter).
    #                            # Note: 5 winter months x 0.05 = 0.25 would exceed the annual growth peak (0.2)
    # if annual:
    #     winter_decay = winter_decay_year
    # elif month is not None and month in winter_months:
    #     winter_decay = winter_decay_month
    # else:
    #     winter_decay = None

    # if winter_decay is not None:
    #     rhov_dfnew_spec1 = max(0, rhov_dfnew_spec1 - winter_decay)
    #     rhov_dtnew_spec1 = max(0, rhov_dtnew_spec1 - winter_decay)
    #     rhov_dbnew_spec1 = max(0, rhov_dbnew_spec1 - winter_decay)
    #     rhov_dfnew_spec2 = max(0, rhov_dfnew_spec2 - winter_decay)
    #     rhov_dtnew_spec2 = max(0, rhov_dtnew_spec2 - winter_decay)
    #     rhov_dbnew_spec2 = max(0, rhov_dbnew_spec2 - winter_decay)
            
    # reduction of vegetation coverage in winter (frost); values from the yaml
    if annual:
        winter_decay = winter_decay_year
    elif month is not None and month in winter_months:
        winter_decay = winter_decay_month
    else:
        winter_decay = None

    if winter_decay:
        if winter_decay_type == 'relative':
            keep = 1.0 - winter_decay
            rhov_dfnew_spec1 *= keep
            rhov_dtnew_spec1 *= keep
            rhov_dbnew_spec1 *= keep
            rhov_dfnew_spec2 *= keep
            rhov_dtnew_spec2 *= keep
            rhov_dbnew_spec2 *= keep
        elif winter_decay_type == 'absolute':
            rhov_dfnew_spec1 = max(0, rhov_dfnew_spec1 - winter_decay)
            rhov_dtnew_spec1 = max(0, rhov_dtnew_spec1 - winter_decay)
            rhov_dbnew_spec1 = max(0, rhov_dbnew_spec1 - winter_decay)
            rhov_dfnew_spec2 = max(0, rhov_dfnew_spec2 - winter_decay)
            rhov_dtnew_spec2 = max(0, rhov_dtnew_spec2 - winter_decay)
            rhov_dbnew_spec2 = max(0, rhov_dbnew_spec2 - winter_decay)
        else:
            raise ValueError(f"winter_decay_type must be 'relative' or 'absolute', not {winter_decay_type!r}")

    # Cap values between 0 and 1, and adjust species balance as before
    rhov_dfnew_spec1 = min(max(rhov_dfnew_spec1, 0.0), 1.0)
    rhov_dtnew_spec1 = min(max(rhov_dtnew_spec1, 0.0), 1.0)
    rhov_dbnew_spec1 = min(max(rhov_dbnew_spec1, 0.0), 1.0)
    rhov_dfnew_spec2 = min(max(rhov_dfnew_spec2, 0.0), 1.0)
    rhov_dtnew_spec2 = min(max(rhov_dtnew_spec2, 0.0), 1.0)
    rhov_dbnew_spec2 = min(max(rhov_dbnew_spec2, 0.0), 1.0)

    # Balance species
    if (rhov_dfnew_spec1 + rhov_dfnew_spec2 > 1.0):
        rhov_dfnew_spec1 = 1.0 - rhov_dfnew_spec2
    if (rhov_dtnew_spec1 + rhov_dtnew_spec2 > 1.0):
        rhov_dtnew_spec1 = 1.0 - rhov_dtnew_spec2
    if (rhov_dbnew_spec1 + rhov_dbnew_spec2 > 1.0):
        rhov_dbnew_spec1 = 1.0 - rhov_dbnew_spec2

    return rhov_dfnew_spec1, rhov_dtnew_spec1, rhov_dbnew_spec1, rhov_dfnew_spec2, rhov_dtnew_spec2, rhov_dbnew_spec2

 
    
def veg(ys, ysnew, yl, ylnew, sramp, srampnew, betas, betal, s, snew, dt,rhov_df,rhov_dt,rhov_db):
    """
    Vegetation growth function adapted from Duran and Moore (2014) 
    """

    HVmax = 1.0
    HVmin = 0.01 # treshold value
    tveg = 3*24*3600  # duran and moore [2013]
    tveg = 365*24*3600  # needs to be adjusted according to Bonte et al [2021]
    gamv = 0.05  # Duran and Moore[2013] default at 1.0 - plant sensitivity to erosion/accretion
    # start with ramp
    HV = max((rhov_df)**0.5*HVmax,HVmin) # vegetation height
    # change in bed level
    dh = 0.0
    if (abs(ysnew-ys)>0.0):
        dh=(ysnew-ys)*np.sin(betas)
    elif (abs(srampnew-sramp)>0.0):
        dh = 0.5*(srampnew-sramp)
        
#    rhov_dfnew=dt*(1-rhov_df)/tveg-gamv/HV*abs(dh)
    rhov_dfnew=rhov_df+dt*(1-rhov_df)/tveg-gamv*abs(dh)/HVmax
# Bonte
#    rhov_dfnew=rhov_df*1.005-0.005*rhov_df**2
    
    # update
    rhov_df = max(rhov_dfnew,0.0001)
    
    # follow up for the top of the dune
    HV = max((rhov_dt)**0.5*HVmax,HVmin) # vegetation height
    # change in bed level
    dh = (snew-s)
        
    rhov_dtnew=rhov_dt+dt*(1-rhov_dt)/tveg-gamv/HVmax*abs(dh)
    # update
    rhov_dt = max(rhov_dtnew,0.0001)
    
    # and the back of the dune
    HV = max((rhov_db)**0.5*HVmax,HVmin) # vegetation height
    # change in bed level
    dh=(ylnew-yl)*np.sin(betal)
    rhov_dbnew=rhov_db+dt*(1-rhov_db)/tveg-gamv/HVmax*abs(dh)
    # update
    rhov_db = max(rhov_dbnew,0.0001)
    
    return rhov_df, rhov_dt, rhov_db


### Morphodynamic functions
def sedbud2_1_nosmax(vramp, ys, ysprim, betas, s, yl, ylprim, betal, wtransp):
    # Dune evolution for positive sediment budget in case of triangular shape

    ylprim = ysprim #triangular shape, so landward and seaward crest are the same
    #snew = np.sqrt(((ys - yl) * s + 2 * wtransp) / (1 / betas + 1 / betal))
    snew = np.sqrt(s**2 + 2 * wtransp / (1 / betal + 1 / betas))
    ylprimnew = ylprim  # Dune increases in height but does not change in position
    ysprimnew = ysprim
    ylnew = ylprimnew - snew / betal
    ysnew = ysprimnew + snew / betas
    srampnew = snew
    vrampnew = 0.5 * (ysnew - ysprimnew)**2 * betas

    return snew, ylprimnew, ysprimnew, ylnew, ysnew, vrampnew, srampnew

def sedbud2_2_nosmax(vramp, ys, ysprim, betas, s, yl, ylprim, betal, wtransp):
    # dune evolution for positive sediment budget in case of trapezoidal shape
    vtrimax = 0.5 * (ysprim - ylprim) ** 2 / (1 / betal + 1 / betas)  # max volume to reach triangular shape
    vmax = vtrimax

    if wtransp <= vmax: #volume not enough to reach triangular shape
        snew = s + 2 * vtrimax / (ysprim - ylprim) - np.sqrt(2 * (vtrimax - wtransp) / (1 / betal + 1 / betas))
        srampnew = snew # do update here because you added the scarping part earlier
        #srampnew = sramp #do not update now because we are calculating in blocks
        ylnew = yl
        ylprimnew = ylprim + (snew - s) / betal
        ysprimnew = ysprim - (snew - s) / betas
        ysnew = ys
        vrampnew = 0.5 * (ysnew - ysprimnew) ** 2 * betas  #### do not recalculate vramp anymore
        #vrampnew = vramp  #keep the volume the same as we are calculating in blocks now

    else: #volume enough to reach triangular shape, transfer landward and seaward sediment
        wrest = wtransp - vmax

        #fill the triangular shape
        snew = s + 2 * vtrimax / (ysprim - ylprim)
        ylprimnew = ylprim + (snew - s) / betal
        ysprimnew = ysprim - (snew - s) / betas

        # expand the dune laterally using the remaining sediment
        #ysnew = ysprimnew + snew / betas
        #ylnew = ylprimnew - snew / betal
        #srampnew = snew
        #vrampnew = 0.5 * (ysnew - ysprimnew)**2 * betas

        # lee side
        ylnew = yl - wrest/snew 
        ylprimnew = ylnew + snew/betal

        # ramp side
        vrampnew = vramp + wrest/2 # get the new ramp volume

        # check the max volume for the ramp
        vrampmax = snew ** 2 / (2 * betas)

        if vrampnew < vrampmax: # check if the volume in the front of dune is below the maximum
            srampnew = (2 * betas * vrampnew)**0.5 # get the new ramp height --> should always be below s
            #ysnew = srampnew / betas + ysprim
            ysnew = ys #does not change because the ramp is only filling upwards
            ysprimnew = ysprim
            #vrampnew = 0.5 * (ysnew - ysprimnew) ** 2 * betas
        else: # if the ramp volume is larger than the maximum, move the ramp as a whole seaward, keeping the same angle
            extrasand = min(wrest/2, vrampnew - vrampmax) #get the excess of sand needed and redistribute it
            srampnew = snew # ramp is full, so it is equal to the crest height
            ysnew = (2 * extrasand / s) + ys # get the new seaward position of the ramp
            ysprimnew = ysnew - srampnew / betas # get the new crest position of the ramp 
            vrampnew = vrampmax # set the ramp volume to the maximum, because the extrasand becomes part of the core

    return snew, ylprimnew, ysprimnew, ylnew, ysnew, vrampnew, srampnew

def sedbud1_nosmax(vramp, ys, ysprim, betas, s, yl, ylprim, betal, wtransp):
    # dune evolution for stable sediment budget
    # print(f'in sebud1, wtransp', {wtransp})
    if ysprim > ylprim:  # TRAPEZOIDAL SHAPE, DISTRIBUTE SEDIMENT 50./50 ON CREST AND SEAWARD SLOPE
        # CHECK AMOUNT OF SEDIMENT REQUIRED TO ATTAIN TRIANGULAR SHAPE
        vtrimax = 0.5 * (ysprim - ylprim) ** 2 / (1 / betal + 1 / betas)

        if wtransp / 2 <= vtrimax:
            snew = s + (ysprim - ylprim) / (1 / betal + 1 / betas) - np.sqrt((ysprim - ylprim) ** 2 / (1 / betal + 1 / betas) ** 2 - wtransp / (1 / betas + 1 / betal))
            ylprimnew = ylprim + (snew - s) / betal
            ysprimnew = ysprim - (snew - s) / betas + 0.5 * wtransp / snew # just increase seaward
            ysnew = ysprimnew + snew / betas
            srampnew = snew
            ylnew = yl
            vrampnew = 0.5 * (ysnew - ysprimnew) ** 2 * betas

        elif wtransp / 2 > vtrimax:
            snew = s + 2 * vtrimax / (ysprim - ylprim) #get the maximum possible
            ylprimnew = ylprim + (snew - s) / betal #find the new position of the landward crest
            ysprimnew = ylprimnew # as triangular, seaward is the same as landward
            #ysnew = ysprimnew + snew / betas # added by filipe
            #ylnew = ylprimnew - snew / betal # added by filipe
            #srampnew = snew # added by filipe
            wrest = wtransp - vtrimax
            wtransp = wrest # amount of sediment left to distribute
            s = snew
            ysprimnew = ysprim  + 0.5 * wtransp / snew #added by filipe
            ylprimnew = ylprim  - 0.5 * wtransp / snew #added by filipe
            ysnew = ys + 0.5 * wtransp / snew #added by filipe so as to redistribute the leftovers on both sides
            ylnew = yl - 0.5 * wtransp / snew #added by filipe
            #ylprimnew = ylprim + (s / betal) # added by Filipe - recalculate after expanding the dune laterally
            #ysprimnew = ysprim - (s / betas)  # added by Filipe - recalculate after expanding the dune laterally
            ylprim = ylprimnew
            ysprim = ysprimnew
            vrampnew = 0.5 * (ysnew - ysprimnew) ** 2 * betas
            srampnew = (ysnew - ysprimnew) * betas  # added by Filipe
        # GOTO 1111

    elif ysprim <= ylprim + 0.001: # TRIANGULAR SHAPE
        snew = np.sqrt(((ys - yl) * s + 2 * wtransp) / (1 / betas + 1 / betal))
        ylprimnew = ylprim
        ysprimnew = ysprim
        ysnew = ysprimnew + snew / betas
        ylnew = ylprimnew - snew / betal
        srampnew = snew
        vrampnew = 0.5 * (ysnew - ysprimnew) ** 2 * betas

    return snew, ylprimnew, ysprimnew, ylnew, ysnew, vrampnew, srampnew

def sedbud0(ys, ysprim, betas, s, yl, ylprim, betal, wtransp):
    # dune evolution for negative sediment budget

    if ysprim > ylprim:
        vtrimax = 0.5 * (ysprim - ylprim) ** 2 * betal
        if wtransp / 2 <= vtrimax:
            ylprimnew = ysprim - np.sqrt((ysprim - ylprim) ** 2 - wtransp / betal)
            snew = s + (ylprimnew - ylprim) * betal
            ylprim = ylprimnew
            ylprimnew = ylprim - 0.5 * wtransp / snew
            ysprimnew = ysprim
            ysnew = ys
            ylnew = yl - 0.5 * wtransp / snew

        elif wtransp / 2 > vtrimax:
            snew = s + 2 * vtrimax / (ysprim - ylprim)
            ylprimnew = ylprim + (snew - s) / betal
            ysprimnew = ysprim
            wrest = wtransp - vtrimax
            wtransp = wrest
            s = snew
            snew = np.sqrt(betal * (s * (ysprim - yl) + 2 * wtransp))
            ysnew = ys
            ylnew = ylprimnew - snew / betal
    elif ysprim <= ylprim:
        snew = np.sqrt(betal * (s * (ysprim - yl) + 2 * wtransp))
        ysnew = ys
        ylprimnew = ylprim
        ysprimnew = ysprim
        ylnew = ylprimnew - snew / betal

    return snew, ylprimnew, ysprimnew, ylnew, ysnew

def duneeros(vramp, ysprim, betas, betal, s, erod, yl, ylprim, dfoot):
    # Calculate new ramp volume
    deltavramp = erod
    vrampnew = vramp + deltavramp

    if vrampnew > 0:
        srampnew = (2 * betas * vrampnew) ** 0.5
        ysnew = srampnew / betas + ysprim
        ysprimnew = ysprim
        ylprimnew = ylprim
        ylnew = yl
        snew = s

    elif vrampnew < 0:
        ysprimnew = ysprim + vrampnew / s

        if ysprimnew < ylprim:
            wtransprest = (ysprimnew - ylprim) * s
            ylprimnew = ((1 / betal) * ((ylprim - yl) * s + 2 * wtransprest)) ** 0.5 + yl
            snew = (ylprimnew - yl) * betal
            ysprimnew = ylprimnew
        else:
            ylprimnew = ylprim
            snew = s

        ysnew = ysprimnew
        ylnew = yl
        vrampnew = 0.0
        srampnew = 0.0

    else:  # vrampnew == 0
        ysnew = ysprim
        ysprimnew = ysprim
        ylprimnew = ylprim
        ylnew = yl
        srampnew = 0.0
        snew = s

    return vrampnew, ysnew, ysprimnew, snew, ylnew, ylprimnew, srampnew

### Transport functions
def wind_veg_reduction(u_in, L_block,
                   rhov1, Cd1=0.03,
                   rhov2=0.0, Cd2=0.01):
    """
    Wind speed reduction due to vegetation (can include two species).

    Parameters
    ----------
    u_in : float
        Incoming wind speed (m/s).
    L_block : float
        Length of the block (m).
    rhov1 : float
        Vegetation density (0–1) for species 1 (dune builder).
    Cd1 : float, optional
        Drag coefficient for species 1 (default=0.03).
    rhov2 : float, optional
        Vegetation density (0–1) for species 2 (stabilizer).
        Default = 0 (absent).
    Cd2 : float, optional
        Drag coefficient for species 2 (default=0.01).

    Returns
    -------
    u_out : float
        Outgoing wind speed after vegetation (m/s).
    """
    k = 0.5 * (Cd1 * rhov1 + Cd2 * rhov2)
    u_out = u_in * np.exp(-k * L_block)
    return u_out

def deposition_dune(dune_x, dune_z, substrate_x, substrate_z, qwnet, dt, tetaw, wspeed, rhos, rhoa, d50, kappa, z, vegcount, awind, rhov_df, rhov_dt, rhov_db, 
        rhov_df2, rhov_dt2, rhov_db2,
        alpha_ramp=2.2, beta_ramp=0.6, alpha_crest=1.5, beta_crest=0.2,
        alpha_lee=1.2, beta_lee=0.8, Cd1=None, Cd2=None):
    """
    Calculate sediment deposition on dune in three blocks (ramp, crest, lee) based on wind shear velocity distribution.

    Shear stress perturbation per block (convolution term + local slope term):
        tau/tau0 = alpha * (I + beta * slope) + 1
    alpha_* scales the amplitude of the bed-slope influence and beta_* is the
    relative weight of the local slope term; both can be set in the yaml
    (section wind_shear). Defaults are the values used so far.

    Cd1, Cd2: drag coefficients of species 1 and 2 in the wind reduction by
    vegetation (wind_veg_reduction), set in the yaml (section vegetation).
    None keeps the values used so far: Cd1 = 0.12 and Cd2 = 0.01 with two
    species (vegcount = 1), Cd1 = 0.03 with one species (vegcount = 0).
    """

    dx_ramp = abs(dune_x['ramp_toe']-dune_x['ramp_crest']) # find the distance between the dunetoe and the dune crest
    dx_crest = abs(dune_x['ramp_crest']-dune_x['lee_crest']) #find the x distance between the front and back of the crest
    dx_lee = abs(dune_x['lee_foot']-dune_x['lee_crest']) # find the distance between the back of the crest and the dune lee foot
    
    # function to check where the dune is sitting
    def dike_surface_z(x, substrate_x, substrate_z):
        x_crest_start = substrate_x[2]
        x_crest_end   = substrate_x[3]
        x_toe         = substrate_x[4]
    
        z_crest = substrate_z[2]
        z_toe   = substrate_z[4]
    
        if x <= x_crest_start:
            # landward side (if relevant)
            return z_toe
    
        elif x_crest_start < x <= x_crest_end:
            # crest plateau
            return z_crest
    
        elif x_crest_end < x < x_toe:
            # seaward slope (linear face)
            return z_crest + (z_toe - z_crest) * (x - x_crest_end) / (x_toe - x_crest_end)
    
        else:
            # foreland
            return z_toe

    # check if everything should be deposited in the ramp or not
    z_dike = dike_surface_z(dune_x['seaward_crest'], substrate_x, substrate_z)
    
    if dx_ramp == 0 or dune_x['ramp_toe'] <= substrate_x[4] or (dune_x['seaward_crest'] <= substrate_x[3] and dune_z['seaward_crest'] <= substrate_z[3] and dune_z['ramp_dike_temp']==substrate_z[2]) or ((abs(dune_z['seaward_crest'] - z_dike) <= 0.005 or dune_z['seaward_crest'] < z_dike - 0.005) and dune_z['ramp_crest'] < dune_z['ramp_dike_temp']) or (dune_x['seaward_crest'] <= substrate_x[4] and dune_z['seaward_crest'] < substrate_z[3] and dune_x['seaward_crest'] > substrate_x[3]): # condition where no ramp exists anymore because of erosion, so not need to calculate everything as everything will end up on the ramp
        qs_ramp = qwnet * dt
        qs_crest = 0.0
        qs_lee = 0.0    
    else:
        
         # positions of each block center
        x_ramp  = (dune_x['ramp_toe'] + dune_x['ramp_crest']) / 2
        x_crest = (dune_x['ramp_crest'] + dune_x['lee_crest']) / 2
        x_lee   = (dune_x['lee_crest'] + dune_x['lee_foot']) / 2
        
         # compute slopes
        slope_ramp = dune_z['ramp_crest']/dx_ramp if dx_ramp != 0 else 0
        slope_crest = 0 # slope of the crest is zero as it is flat
        slope_lee = dune_z['seaward_crest']/dx_lee if dx_lee != 0 else 0
        
        
        # # block edges (note: keep these as signed positions along x)
        x_ramp_minus, x_ramp_plus   = dune_x['ramp_crest'], dune_x['ramp_toe']
        x_crest_minus, x_crest_plus = dune_x['lee_crest'], dune_x['ramp_crest']
        x_lee_minus, x_lee_plus     = dune_x['lee_foot'], dune_x['lee_crest']
         
        
         # ## exact per-block integrals (exclude self-block)
        I_ramp  = (slope_crest/np.pi) * np.log((x_ramp - x_crest_minus)/(x_ramp - x_crest_plus)) \
                 + (slope_lee  /np.pi) * np.log((x_ramp - x_lee_minus  )/(x_ramp - x_lee_plus   ))
         
        I_crest = (slope_ramp /np.pi) * np.log((x_crest - x_ramp_minus)/(x_crest - x_ramp_plus)) \
                 + (slope_lee  /np.pi) * np.log((x_crest - x_lee_minus )/(x_crest - x_lee_plus ))
         
        I_lee   = (slope_ramp /np.pi) * np.log((x_lee - x_ramp_minus)/(x_lee - x_ramp_plus)) \
                 + (slope_crest/np.pi) * np.log((x_lee - x_crest_minus)/(x_lee - x_crest_plus))
             
         # coefficients α (scaling factor controls amplitude of bed slope gradient influence) and β (relative wheigth of local slope term) for each block
        # values come from the function arguments (yaml section wind_shear);
        # defaults: ramp 2.2/0.6 (tested before: 3/0.8, 2/0.8), crest 1.5/0.2, lee 1.2/0.8
        
         # calculate tau over tau0 including convolution term + local slope term + 1 (background shear)
        tau_ramp  = max(alpha_ramp * (I_ramp + beta_ramp * slope_ramp) + 1, 0.1)
        tau_crest = max(alpha_crest * (I_crest + beta_crest * slope_crest) + 1, 0.1)
        tau_lee   = max(alpha_lee * (I_lee + beta_lee * -slope_lee) + 1, 0.1)
                 
         # calculate the wind velocity distribution along the profile
        u10x_ramp = wspeed* np.cos(tetaw) * np.sqrt(tau_ramp)
        u10x_crest = wspeed * np.cos(tetaw) * np.sqrt(tau_crest)
        u10x_lee = wspeed * np.cos(tetaw) * np.sqrt(tau_lee)
        
        u10y = wspeed * np.sin(tetaw)
        
         # calculate critical velocities for sediment transport
        wcrit = awind * np.sqrt((rhos -rhoa)/rhoa * 9.81 * d50)
        tu10 = wcrit/ kappa * np.log(z / (d50/30))
        
         # allocate the bare velocities
        umag_ramp_bare = np.sqrt(u10x_ramp**2 + u10y**2)
        umag_crest_bare = np.sqrt(u10x_crest**2 + u10y**2)
        umag_lee_bare = np.sqrt(u10x_lee**2 + u10y**2)
        
         # Apply sequentially to x- and y-components
        if vegcount == 0:
            cd1 = 0.03 if Cd1 is None else Cd1
            u10x_ramp  = wind_veg_reduction(u10x_ramp, dx_ramp, rhov_df, Cd1=cd1)
            u10x_crest = wind_veg_reduction(u10x_crest, dx_crest, rhov_dt, Cd1=cd1)
            u10x_lee   = wind_veg_reduction(u10x_lee, dx_lee, rhov_db, Cd1=cd1)
        
            u10y_ramp  = wind_veg_reduction(u10y, dx_ramp, rhov_df, Cd1=cd1)
            u10y_crest = wind_veg_reduction(u10y, dx_crest, rhov_dt, Cd1=cd1)
            u10y_lee   = wind_veg_reduction(u10y, dx_lee, rhov_db, Cd1=cd1)
        
        elif vegcount == 1:
            cd1 = 0.12 if Cd1 is None else Cd1
            cd2 = 0.01 if Cd2 is None else Cd2
            u10x_ramp  = wind_veg_reduction(u10x_ramp, dx_ramp, rhov_df, Cd1=cd1, rhov2=rhov_df2, Cd2=cd2)
            u10x_crest = wind_veg_reduction(u10x_crest, dx_crest, rhov_dt, Cd1=cd1, rhov2=rhov_dt2, Cd2=cd2)
            u10x_lee   = wind_veg_reduction(u10x_lee, dx_lee, rhov_db, Cd1=cd1, rhov2=rhov_db2, Cd2=cd2)
        
            u10y_ramp  = wind_veg_reduction(u10y, dx_ramp, rhov_df, Cd1=cd1, rhov2=rhov_df2, Cd2=cd2)
            u10y_crest = wind_veg_reduction(u10y, dx_crest, rhov_dt, Cd1=cd1, rhov2=rhov_dt2, Cd2=cd2)
            u10y_lee   = wind_veg_reduction(u10y, dx_lee, rhov_db, Cd1=cd1, rhov2=rhov_db2, Cd2=cd2)
        
        
         # Compute umag after reduction
        umag_ramp = np.sqrt(u10x_ramp**2 + u10y_ramp**2)
        umag_crest = np.sqrt(u10x_crest**2 + u10y_crest**2)
        umag_lee = np.sqrt(u10x_lee**2 + u10y_lee**2)
        umag_beach = wspeed * np.cos(tetaw) # calculation as in the subar routine
        

        # calculate sediment concentration potential
        cu_ramp = 1.5e-4 * (np.maximum(umag_ramp-tu10,0)**3) / np.maximum(umag_ramp, 1e-6)
        cu_crest = 1.5e-4 * (np.maximum(umag_crest-tu10,0)**3) / np.maximum(umag_crest, 1e-6)
        cu_lee = 1.5e-4 * (np.maximum(umag_lee-tu10,0)**3) / np.maximum(umag_lee, 1e-6)        
         
        cu_ramp_bare = 1.5e-4 * (np.maximum(umag_ramp_bare-tu10,0)**3) / np.maximum(umag_ramp_bare, 1e-6)
        cu_crest_bare = 1.5e-4 * (np.maximum(umag_crest_bare-tu10,0)**3) / np.maximum(umag_crest_bare, 1e-6)
        cu_lee_bare = 1.5e-4 * (np.maximum(umag_lee_bare-tu10,0)**3) / np.maximum(umag_lee_bare, 1e-6)
             
         # find the percentage of reduction due to vegetation
        F_c_ramp = 1 - min(cu_ramp / max(cu_ramp_bare, 1e-12), 1.0)
        F_c_crest = 1 -  min(cu_crest / max(cu_crest_bare, 1e-12), 1.0)
        F_c_lee = 1 - min(cu_lee / max(cu_lee_bare, 1e-12), 1.0)
         
        #find gradients
        Fg_ramp  = max(0, tu10 - umag_ramp) / max(tu10, 1e-12)
        Fg_crest = max(0, umag_ramp - umag_crest) / max(umag_ramp, 1e-12)
        Fg_lee   = max(0, umag_crest - umag_lee) / max(umag_crest, 1e-12)

        #Fg_ramp  = max(0, cu_beach - cu_ramp) / max(cu_beach, 1e-12)
        #Fg_crest = max(0, cu_ramp - cu_crest) / max(cu_ramp, 1e-12)
        #Fg_lee   = max(0, cu_crest - cu_lee) / max(cu_crest, 1e-12)
        
        Fg_sum = Fg_ramp + Fg_crest + Fg_lee
        
        #combined prob
        Fstar_ramp  = 1 - (1 - F_c_ramp)  * (1 - (Fg_ramp/max(Fg_sum, 1e-12)))
        Fstar_crest = 1 - (1 - F_c_crest) * (1 - (Fg_crest/max(Fg_sum, 1e-12)))
        Fstar_lee   = 1 - (1 - F_c_lee)   * (1 - (Fg_lee/max(Fg_sum, 1e-12)))

        qs_total = qwnet * dt

        qs_ramp  = qs_total * Fstar_ramp
        rem      = qs_total - qs_ramp
        
        qs_crest = rem * Fstar_crest
        qs_lee   = qs_total - qs_ramp - qs_crest

         # apply gradient based, so to ensure deposition accross when bare
        # G_ramp  = max(0, tu10 - umag_ramp)
        # G_crest = max(0, umag_ramp  - umag_crest)
        # G_lee   = max(0, umag_crest - umag_lee)
         
        # G_sum = G_ramp + G_crest + G_lee
         
        # qs_total = qwnet * dt
         
        #  # ramp 
        # if F_c_ramp > 1e-6:  # vegetation present → use it
        #     qs_ramp = qs_total * F_c_ramp
        # else:                # no veg → fallback to gradient
        #     qs_ramp = qs_total * (G_ramp / max(G_sum, 1e-12))
         
        # # --- crest ---
        # rem_after_ramp = qs_total - qs_ramp
        # if F_c_crest > 1e-6:
        #     qs_crest = rem_after_ramp * F_c_crest
        # else:
        #     qs_crest = rem_after_ramp * (G_crest / max(G_crest + G_lee, 1e-12))
         
        # # --- lee (whatever remains) ---
        # qs_lee = qs_total - (qs_ramp + qs_crest)
        
         
        if (dune_z['ramp_crest'] < dune_z['seaward_crest']) or (dune_z['ramp_crest'] > dune_z['ramp_toe_temp'] and dune_z['ramp_toe_temp'] > dune_z['ramp_toe']): #case with scarp, enforce all depo in front             
            qs_ramp = qwnet * dt
            qs_crest = 0.0
            qs_lee = 0.0

    return qs_ramp, qs_crest, qs_lee

def morpho_update(dune_x, dune_z, substrate_x, substrate_z, qs_ramp, qs_crest, qs_lee, qs, ql, r, swl, vnourd, dt,
                   betas, betas_hs, betal, betal_hs, vramp, deltavall, lee_transfer=0.0):
    """
    Update dune and substrate morphology based on sediment deposition and erosion.
    """
    
    #Add volume trackers to make sure we keep conserving mass
    vdune_beforeloop = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])

    erod = (qs + ql) * dt
    erod_ramp = qs * dt
    erod_overwash = ql * dt
    erod_crest_beach = 0.0  # sheltered dune: crest sand above the dike crest returned seaward
    
    # get dune and dike parameters that to enter the calculations
    s_hs = substrate_z[3]-substrate_z[4]  # dike height above substrate seafloor
    ylprim_hs = substrate_x[2]  # landward dike crest position
    ysprim_hs = substrate_x[3]  # seaward dike crest position
    ys_hs = substrate_x[4]  # dike seaward toe position
    dfoot = dune_z['ramp_toe']  # height of dune foot above substrate seafloor
    ys = dune_x['ramp_toe'] # dune seaward toe position
    yl = dune_x['lee_foot']  # dune landward toe position
    s = dune_z['seaward_crest']-dfoot  # dune height above
    sramp = dune_z['ramp_crest']-dfoot  # dune ramp height above
    ylprim = dune_x['lee_crest']  # dune landward crest position
    ysprim = dune_x['seaward_crest']  # dune seaward crest position
    
    #reload differently if detached
    if dune_x['ramp_crest'] > dune_x['seaward_crest'] and dune_x['seaward_crest'] <= substrate_x[2] and dune_z['seaward_crest'] <= substrate_z[2] and dune_z['seaward_crest']<dune_z['ramp_dike_temp']:
        ysprim = dune_x['ramp_crest']
        s = dune_z['ramp_crest'] - dfoot

    # case 1: dune erosion
    # case 1: dune erosion
    if erod > 0:
        qs_lee_overwash = 0.0 # overwash sand for a lee seaward of the dike, deposited with the lee accretion routine below
        
        srampnew = dune_z['ramp_crest']-dfoot #allocate it if it does not change for vramp calc

        #check if there is dune to be eroded:
        if r + swl <= (s_hs+dfoot): # if water level between dike foot and dike crest
            z_seg = substrate_z[3:5]
            x_seg = substrate_x[3:5]
            # sort by z
            order = np.argsort(z_seg)
            z_sorted = np.array(z_seg)[order]
            x_sorted = np.array(x_seg)[order]
            runup_reach_dike_x = np.interp(r + swl, z_sorted, x_sorted)

            z_seg = [dune_z['ramp_toe'], dune_z['ramp_toe_temp'], dune_z['ramp_crest']]
            x_seg = [dune_x['ramp_toe'], dune_x['ramp_toe_temp'], dune_x['ramp_crest']]
            # sort by z
            order = np.argsort(z_seg)
            z_sorted = np.array(z_seg)[order]
            x_sorted = np.array(x_seg)[order]
            runup_reach_dune_x = np.interp(r + swl, z_sorted, x_sorted)
            
            if runup_reach_dike_x >= runup_reach_dune_x: #dike exposed
                erod_ramp = 0
            
            if erod_ramp > 0: #if there is potential erosion on the dune ramp
                # calculate maximum erosion volume on the ramp based on the dike limit
                #volume_max_ero = partial_volume(dune_x, dune_z, substrate_x, substrate_z, runup_reach_dike_x, dune_x['ramp_toe'])
                # calculate maximum erosion volume on the ramp based on the dike limit
                if dune_x['seaward_crest'] <= substrate_x[3] and dune_z['seaward_crest'] - dfoot > s_hs: #scarp over the dike, hence the lee portion is limited for erosion                 
                    volume_max_ero = partial_volume(dune_x, dune_z, substrate_x, np.asarray(substrate_z, dtype=float) - np.asarray(substrate_z, dtype=float) + substrate_z[2], dune_x['lee_foot'], dune_x['ramp_toe']) #lee dune is sheltered, so only calculate the volume above the substrate as available               
                elif dune_x['seaward_crest'] > substrate_x[3] and dune_x['seaward_crest'] < substrate_x[4] and (r+swl) < substrate_z[3]:
                    volume_max_ero = partial_volume(dune_x, dune_z, substrate_x, np.asarray(substrate_z, dtype=float) - np.asarray(substrate_z, dtype=float) + substrate_z[2], runup_reach_dike_x-0.0001, dune_x['ramp_toe']) #small portion of the face still available to erode           
                else: #whole dune is game
                    volume_max_ero = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe']) #whole dune is game
                    
                if erod_ramp >= volume_max_ero:
                    erod_ramp = volume_max_ero #pad it to the max erosion volume on the ramp
                                   
                def f_ramp_erosion(x):
                    volume_potential = partial_volume(dune_x, dune_z, substrate_x, substrate_z, x, dune_x['ramp_toe'])
                    return volume_potential - erod_ramp
                             
                #find new locations that satisfy the erosion volume
                try: #try this because in case the dune is completely eroded, the function in non-monotonic anymore
                    ysprim_new = brentq(f_ramp_erosion, dune_x['lee_foot'], dune_x['ramp_toe']) #brettq to find the new dune crest position after erosion
                except:
                    ysprim_new = brentq(f_ramp_erosion, runup_reach_dike_x, dune_x['ramp_toe']) #brettq to find the new dune crest position after erosion
                
                #if ysprim_new <= runup_reach_dike_x: 
                srampnew = max(np.interp(ysprim_new, list(dune_x.values()), list(dune_z.values())), np.interp(ysprim_new, substrate_x, substrate_z))
                #else:
                #    srampnew = dune_z['ramp_toe'] #no change as the dike is exposed
                
                #checker if the dune is completely eroded
#                if ysprim_new<dune_x['lee_foot']:
#                    srampnew = dune_z['lee_foot']
#                    ysprim_new = dune_x['lee_foot']
                    
        else: #dike submerged thus overtopping as well
            
            #if ysprim_hs >= dune_x['ramp_crest'] and dune_z['seaward_crest'] - dfoot <= s_hs:
            #    erod_ramp = 0

            if dune_x['ramp_crest'] <= ylprim_hs and dune_z['seaward_crest'] - dfoot > s_hs:
                # Dune behind the dike but still higher than the dike crest. The dike
                # shelters only the sand below its crest: the part above it is still
                # attacked, and is lowered towards the dike crest level. That sand is
                # returned seaward over the dike (to the beach), not to the lee.
                # The lee keeps receiving only the regular overwash ql.
                flat_dike_crest = np.full(len(substrate_z), float(substrate_z[2]))
                v_above_dike = partial_volume(dune_x, dune_z, substrate_x, flat_dike_crest,
                                              dune_x['lee_foot'], dune_x['ramp_toe'])
                erod_crest_beach = min(erod_ramp, v_above_dike)
                erod_ramp = 0
            elif dune_x['ramp_crest'] <= ylprim_hs and dune_z['seaward_crest'] - dfoot <= s_hs: #dune sheltered by the dike
                if erod_overwash > 0:
                    erod_overwash = erod_overwash + lee_transfer * erod_ramp # detaches case with hard structure blocking, increase the transport capacity by half of the potential that would go to the ramp instead.
                erod_ramp = 0 #reduce ramp erosion to 0 and allow only overwash volume
            
            if erod_ramp > 0: #if there is potential erosion on the dune ramp
            
            # calculate maximum erosion volume on the ramp based on the dike limit
                if dune_x['seaward_crest'] <= substrate_x[3] and dune_z['seaward_crest'] - dfoot > s_hs: #scarp over the dike, hence the lee portion is limited for erosion                 
                    volume_max_ero = partial_volume(dune_x, dune_z, substrate_x, np.asarray(substrate_z, dtype=float) - np.asarray(substrate_z, dtype=float) + substrate_z[2], dune_x['lee_foot'], dune_x['ramp_toe']) #lee dune is sheltered, so only calculate the volume above the substrate as available               
                else: #whole dune is game
                    volume_max_ero = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe']) #whole dune is game
                
                if erod_ramp >= volume_max_ero:
                    erod_ramp = volume_max_ero #pad it to the max erosion volume on the ramp

                def f_ramp_erosion(x):
                    volume_potential = partial_volume(dune_x, dune_z, substrate_x, substrate_z, x, dune_x['ramp_toe'])
                    return volume_potential - erod_ramp
                
                #find new locations that satisfy the erosion volume
                ysprim_new = brentq(f_ramp_erosion, dune_x['lee_foot'], dune_x['ramp_toe']) #brettq to find the new dune crest position after erosion
                #if ysprim_new <= ys_hs:
                srampnew = max(np.interp(ysprim_new, list(dune_x.values()), list(dune_z.values())), np.interp(ysprim_new, substrate_x, substrate_z))
                #else:
                #    srampnew = dune_z['ramp_toe'] #no change as the dike is exposed

                #checker if the dune is completely eroded
#                if ysprim_new<dune_x['lee_foot']:
#                    srampnew = dune_z['lee_foot']
#                    ysprim_new = dune_x['lee_foot']
                    
        deltavramp = erod_ramp
        deltavall=deltavall+deltavramp
        

        if erod_ramp > 0:
        # update dune profile after erosion
            ramp_not_filled = (dune_z['ramp_crest'] < dune_z['seaward_crest'] - 1e-9 and dune_x['ramp_crest'] == dune_x['seaward_crest']
                               and dune_x['ramp_crest'] > ys_hs and dune_z['ramp_toe_temp'] <= dune_z['ramp_toe'] + 1e-9)
            if ysprim_new > dune_x['ramp_crest'] and ramp_not_filled: # ramp still being rebuilt in front of the scarp (no dike contact)
                # erode it back along the same shapes it is rebuilt with: a lower ramp against the scarp with its toe on the
                # betas line from the crest. Cutting a scarp into it (next branch) would leave ramp_toe_temp between the
                # ramp_crest and ramp_toe elevations, a state the ramp recovery cannot handle.
                s_max_e = dune_z['seaward_crest'] - dfoot
                x_foot_max_e = dune_x['seaward_crest'] + s_max_e / betas
                def _ramp_vol(sp):
                    return ramp_volume(sp, sp, dune_x['seaward_crest'], x_foot_max_e - (s_max_e - sp) / betas, betas, dfoot, substrate_x, substrate_z)
                v_target_e = _ramp_vol(dune_z['ramp_crest'] - dfoot) - erod_ramp
                sramp_e = brentq(lambda sp: _ramp_vol(sp) - v_target_e, 0.0, dune_z['ramp_crest'] - dfoot)
                ys_e = x_foot_max_e - (s_max_e - sramp_e) / betas
                dune_z['ramp_crest'] = sramp_e + dfoot
                if dune_x['ramp_dike_temp'] == dune_x['ramp_crest']:
                    dune_z['ramp_dike_temp'] = sramp_e + dfoot
                dune_x['ramp_toe'] = ys_e
                dune_x['ramp_toe_temp'] = ys_e
                dune_z['ramp_toe_temp'] = dune_z['ramp_toe']
            elif ysprim_new > dune_x['ramp_crest']: #and ysprim_new > ys_hs: #still old ramp to erode further, so it becomes the toe. The case for outside the dike is to enforce proper enter only without interaction. 
                dune_x['ramp_toe'] = ysprim_new
                dune_x['ramp_toe_temp'] = ysprim_new
                dune_z['ramp_toe_temp'] = srampnew
            elif ysprim_new <= dune_x['ramp_crest'] and ysprim_new > dune_x['lee_crest'] and ysprim_new > ys_hs: #erosion beyond the ramp but not beyond the dike
                dune_x['ramp_toe'] = ysprim_new
                dune_x['ramp_toe_temp'] = ysprim_new
                dune_z['ramp_toe_temp'] = dune_z['ramp_toe'] # scarp: the (empty) ramp sits at the scarp foot, as in the dike branch below
                dune_x['ramp_crest'] = ysprim_new
                dune_z['ramp_crest'] = dune_z['ramp_toe'] # was srampnew (scarp top): the ramp recovery then had no ramp height left to solve for
                dune_x['ramp_dike_temp'] = ysprim_new
                dune_z['ramp_dike_temp'] = srampnew
                dune_x['seaward_crest'] = ysprim_new
                dune_x['crest_temp'] = ysprim_new
            elif ysprim_new <= dune_x['ramp_crest'] and ysprim_new > dune_x['lee_crest'] and ysprim_new <= ys_hs: #erosion beyond the ramp and within the dike
                dune_x['ramp_toe'] = ys_hs
                if ysprim_new > ysprim_hs:
                    dune_x['ramp_toe_temp'] = ysprim_new
                    dune_x['ramp_crest'] = ysprim_new
                    dune_z['ramp_crest'] = np.interp(ysprim_new, substrate_x, substrate_z) # srampnew
                else:
                    dune_x['ramp_toe_temp'] = ysprim_hs
                    dune_x['ramp_crest'] = ysprim_new
                    dune_z['ramp_crest'] = np.interp(ysprim_new, substrate_x, substrate_z)
                dune_z['ramp_toe_temp'] = np.interp(ysprim_new, substrate_x, substrate_z)
                dune_x['ramp_dike_temp'] = ysprim_new
                dune_z['ramp_dike_temp'] = srampnew
                dune_x['seaward_crest'] = ysprim_new
                dune_x['crest_temp'] = ysprim_new
                if ysprim_new < ylprim_hs:
                    dune_x['ramp_toe'] = ys_hs
                    dune_z['ramp_toe'] = np.interp(ys_hs, substrate_x, substrate_z)
                    dune_x['ramp_toe_temp'] = ysprim_hs
                    dune_z['ramp_toe_temp'] = np.interp(ysprim_hs, substrate_x, substrate_z)
                    dune_x['ramp_crest'] = ylprim_hs
                    dune_z['ramp_crest'] = np.interp(ylprim_hs, substrate_x, substrate_z)
                    dune_x['ramp_dike_temp'] = ysprim_new
                    dune_z['ramp_dike_temp'] = np.interp(ysprim_new, substrate_x, substrate_z)

            elif ysprim_new <= dune_x['lee_crest'] and ysprim_new <= ys_hs: #erosion beyond the dune
                dune_x['ramp_toe'] = ysprim_new
                dune_z['ramp_toe'] = srampnew
                dune_x['ramp_toe_temp'] = ysprim_new
                dune_z['ramp_toe_temp'] = srampnew
                dune_x['ramp_crest'] = ysprim_new
                dune_z['ramp_crest'] = srampnew
                dune_x['ramp_crest_temp'] = ysprim_new
                dune_z['ramp_crest_temp'] = srampnew
                dune_x['ramp_dike_temp'] = ysprim_new
                dune_z['ramp_dike_temp'] = srampnew
                dune_x['lee_crest'] = ysprim_new
                dune_z['lee_crest'] = srampnew
                dune_x['crest_temp'] = ysprim_new
                dune_z['crest_temp'] = srampnew
                dune_x['seaward_crest'] = ysprim_new
                dune_z['seaward_crest'] = srampnew
                
            elif ysprim_new <= dune_x['lee_foot'] and ysprim_new<=dune_x['lee_foot'] and srampnew==dune_z['lee_foot']: #condition for no dune anymore
                
                #adjustments for very narrow beach width
                if dune_x['shoreline']-ysprim_new < 20: #critical beach width
                    ysprim_new = ysprim_new - (20-(dune_x['shoreline']-ysprim_new))
                    if ysprim_new < substrate_x[4]:
                        ysprim_new = substrate_x[4]
                        
                    if ysprim_new < dune_x['lee_foot']: #if the whole dune is eroded
                        dune_x['lee_foot'] = ysprim_new
                        
                if srampnew < dfoot:
                    srampnew = dfoot
            
                dune_x['ramp_toe'] = ysprim_new
                dune_z['ramp_toe'] = srampnew
                dune_x['ramp_toe_temp'] = ysprim_new
                dune_z['ramp_toe_temp'] = srampnew
                dune_x['ramp_crest'] = ysprim_new
                dune_z['ramp_crest'] = srampnew
                dune_x['ramp_crest_temp'] = ysprim_new
                dune_z['ramp_crest_temp'] = srampnew
                dune_x['ramp_dike_temp'] = ysprim_new
                dune_z['ramp_dike_temp'] = srampnew
                dune_x['lee_crest'] = ysprim_new
                dune_z['lee_crest'] = srampnew
                dune_x['crest_temp'] = ysprim_new
                dune_z['crest_temp'] = srampnew
                dune_x['seaward_crest'] = ysprim_new
                dune_z['seaward_crest'] = srampnew
                
        if srampnew < 0:
            print('debug')
            
            
        deltavramp_ero = deltavramp
        vramp = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['ramp_crest'], dune_x['ramp_toe'])
        
        vdune_test_before_overwash = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])
        
        # make overwash 0 if there is only dune on the back of the dike and the height is smaller than half the dike height
        if dune_x['seaward_crest'] < substrate_x[2] and dune_z['seaward_crest'] < substrate_z[1] + (substrate_z[2]-substrate_z[1])/4:
            erod_overwash = 0
            
            
        # crest lowering removes overwash (to lee) + crest_beach (to beach) together
        erod_overwash = erod_overwash + erod_crest_beach
        crest_to_beach = 0.0
        if erod_overwash > 0: # if some of this erosion is due to overwash, move this volume to the lee portion --> No change in total dune volume, only reorganization within the dune
            # check available crest volume to be transported to the lee side
            if dune_x['seaward_crest'] <= ylprim_hs:
                # Dune is behind the dike: seaward face is constrained by the dike back.
                # Use a volume-exact formulation: find delta such that the actual volume
                # removed from the profile (partial_volume) equals erod_overwash.
                # The seaward crest x-position is held fixed; ramp_dike_temp tracks the
                # crest height down the dike back face; only the lee side recedes.
                # def f_crest_erosion(s_potential):
                #     s_new = dune_z['seaward_crest'] - s_potential
                #     dx_temp = dict(dune_x)
                #     dz_temp = dict(dune_z)
                #     # seaward crest x stays fixed; only height decreases
                #     dz_temp['seaward_crest'] = s_new
                #     dz_temp['crest_temp'] = s_new
                #     # lee crest recedes by delta/betal
                #     dx_temp['lee_crest'] = dune_x['lee_crest'] - s_potential / betal
                #     dz_temp['lee_crest'] = s_new
                #     # ramp_dike_temp moves down the dike back face with the crest height
                #     dz_temp['ramp_dike_temp'] = s_new
                #     dx_temp['ramp_dike_temp'] = np.interp(s_new, substrate_z[1:3], substrate_x[1:3])
                #     # ramp_crest follows seaward_crest height if they were equal
                #     if dune_z['ramp_crest'] == dune_z['seaward_crest']:
                #         dz_temp['ramp_crest'] = s_new
                #     v_new = partial_volume(dx_temp, dz_temp, substrate_x, substrate_z,
                #                           dx_temp['lee_foot'], dx_temp['ramp_toe'])
                #     return vdune_test_before_overwash - v_new - erod_overwash
                def f_crest_erosion(s_potential):
                    s_new = dune_z['seaward_crest'] - s_potential
                    dx_temp = dict(dune_x)
                    dz_temp = dict(dune_z)
                    # seaward crest x stays fixed while the crest is above the dike back
                    # face; once it is lowered below it, the crest slides down the face
                    # (otherwise the crest would cut into the dike)
                    dz_temp['seaward_crest'] = s_new
                    dz_temp['crest_temp'] = s_new
                    x_face = np.interp(s_new, substrate_z[1:3], substrate_x[1:3])
                    dx_temp['seaward_crest'] = min(dune_x['seaward_crest'], x_face)
                    dx_temp['crest_temp'] = dx_temp['seaward_crest']
                    # lee crest recedes by delta/betal
                    dx_temp['lee_crest'] = dune_x['lee_crest'] - s_potential / betal
                    dz_temp['lee_crest'] = s_new
                    # ramp_dike_temp moves down the dike back face with the crest height
                    dz_temp['ramp_dike_temp'] = s_new
                    dx_temp['ramp_dike_temp'] = np.interp(s_new, substrate_z[1:3], substrate_x[1:3])
                    # ramp_crest follows seaward_crest height if they were equal
                    if dune_z['ramp_crest'] == dune_z['seaward_crest']:
                        dz_temp['ramp_crest'] = s_new
                    v_new = partial_volume(dx_temp, dz_temp, substrate_x, substrate_z,
                                          dx_temp['lee_foot'], dx_temp['ramp_toe'])
                    return vdune_test_before_overwash - v_new - erod_overwash
            else:
                def f_crest_erosion(s_potential):
                    # Volume of the triangular cap removed when lowering the crest by s_potential
                    crest_width = dune_x['seaward_crest'] - dune_x['lee_crest']
                    V_cap = crest_width * s_potential + s_potential**2 / 2 * (1 / betas + 1 / betal)
                    return V_cap - erod_overwash
            
            q_to_lee = 0.
                            
            #s_new_ero = dune_z['seaward_crest'] - brentq(f_crest_erosion, 0, dune_z['seaward_crest'] - dfoot)
            
            # check if there is enough dune height based on the available sediment
            if dune_z['seaward_crest'] > substrate_z[2]:
                available_crest_height = dune_z['seaward_crest'] - dfoot

                if available_crest_height > 0 and f_crest_erosion(available_crest_height) > 0:
                    s_new_ero = dune_z['seaward_crest'] - brentq(f_crest_erosion, 0, available_crest_height)
                else:
                    # Overwash demand exceeds available crest volume; erode crest to dike crest level
                    s_new_ero = s_hs + dfoot
            else:
                s_new_ero = dune_z['seaward_crest'] - brentq(f_crest_erosion, 0, dune_z['seaward_crest'] )
                
                if s_new_ero < dfoot: #checker so we limit the erosion until the base level. 
                    s_new_ero = dfoot
                
            #check if there is a dike and, if so, limit the erosion until the top of the dike
            if s_hs <= dune_z['seaward_crest'] - dfoot and ((ysprim_hs < dune_x['seaward_crest'] and ysprim_hs > dune_x['lee_crest']) or (ylprim_hs < dune_x['seaward_crest'] and ylprim_hs > dune_x['lee_crest'])) and s_new_ero - dfoot <= s_hs:
                if dune_z['seaward_crest'] - dfoot == s_hs:
                    q_to_lee = 0
                else:
                    #q_to_lee = f_crest_erosion(s_hs+dfoot-s_new_ero) + erod_overwash
                    q_to_lee = f_crest_erosion(dune_z['seaward_crest'] - (s_hs + dfoot)) + erod_overwash
                erod_overwash = q_to_lee
                s_new_ero = s_hs + dfoot #on these condition you cannot erode the dike
                ysprim_new_c = dune_x['seaward_crest'] - (dune_z['seaward_crest'] - s_new_ero) / betas
                ylprim_new_c = dune_x['lee_crest'] - (dune_z['seaward_crest'] - s_new_ero) / betal

                if dune_x['seaward_crest'] == dune_x['ramp_dike_temp'] and dune_x['seaward_crest'] >= ylprim_hs:
                    dune_x['ramp_dike_temp'] = ysprim_new_c
                    dune_z['ramp_dike_temp'] = s_new_ero
                    
                dune_x['seaward_crest'] = ysprim_new_c
                dune_x['lee_crest'] = ylprim_new_c
                dune_z['seaward_crest'] = s_new_ero
                dune_z['lee_crest'] = s_new_ero
                dune_z['crest_temp'] = s_new_ero
                dune_x['crest_temp'] = ysprim_new_c
                
                
                
            else:
                ysprim_new_c = dune_x['seaward_crest'] - (dune_z['seaward_crest']- s_new_ero) / betas
                ylprim_new_c = dune_x['lee_crest'] - (dune_z['seaward_crest'] - s_new_ero) / betal

                # When the dune is behind the dike the seaward crest x-position is
                # constrained by the dike back face, so it must not move seaward.
                if dune_x['seaward_crest'] <= ylprim_hs:
                    #ysprim_new_c = dune_x['seaward_crest']
                    x_face = np.interp(s_new_ero, substrate_z[1:3], substrate_x[1:3])
                    ysprim_new_c = min(dune_x['seaward_crest'], x_face)
                    
                # When the dune is behind the dike the seaward crest x-position is constrained by the dike back face, so it must not move seaward.
                #if dune_x['seaward_crest'] <= ylprim_hs:
                #        ysprim_new_c = dune_x['seaward_crest']
                if dune_z['ramp_crest'] == dune_z['seaward_crest']: #check if filled ramp or not
                    dune_z['ramp_crest'] = s_new_ero
                    dune_x['ramp_crest'] = ysprim_new_c
                    
                if dune_x['seaward_crest'] == dune_x['ramp_dike_temp'] and dune_x['seaward_crest'] >= ylprim_hs:
                    dune_x['ramp_dike_temp'] = ysprim_new_c
                    dune_z['ramp_dike_temp'] = s_new_ero

                if dune_x['seaward_crest'] < ylprim_hs: # if the dune crest is behind the dike crest, keep ramp_dike_temp consistent with the new crest height
                    dune_z['ramp_dike_temp'] = s_new_ero
                    dune_x['ramp_dike_temp'] = np.interp(s_new_ero, substrate_z[1:3], substrate_x[1:3])
                    #dune_x['ramp_dike_temp'] = ysprim_new_c

                dune_x['seaward_crest'] = ysprim_new_c
                dune_x['lee_crest'] = ylprim_new_c
                dune_z['seaward_crest'] = s_new_ero
                dune_z['lee_crest'] = s_new_ero
                dune_z['crest_temp'] = s_new_ero
                dune_x['crest_temp'] = ysprim_new_c

            # Use the actual volume removed by the crest update (as measured by
            # partial_volume) rather than the analytical approximation.  This
            # ensures the dune volume is exactly conserved: the same amount that
            # was removed from the crest is deposited on the lee.
            v_after_crest = partial_volume(dune_x, dune_z, substrate_x, substrate_z,
                                           dune_x['lee_foot'], dune_x['ramp_toe'])
            removed_crest = max(0.0, vdune_test_before_overwash - v_after_crest)
            crest_to_beach = min(erod_crest_beach, removed_crest)  # leaves the dune
            q_to_lee = removed_crest - crest_to_beach               # stays in the dune
            v_target_lee = vdune_test_before_overwash - crest_to_beach

            if q_to_lee > 0:
                
                ################## update lee ##################

                # Target total dune volume after the lee update equals exactly
                # v_after_crest + q_to_lee  (= vdune_test_before_overwash).
                # We solve for ylprim_potential using partial_volume so that the
                # convergence criterion matches the final measurement exactly.
                substrate_line = LineString(zip(substrate_x, substrate_z))
                s_new_ero_lee = dune_z['seaward_crest']  # crest height already updated above
                lee_foot_z_cur = dune_z['lee_foot']
                
                # If there is no interaction with the dike for the erosion, just move this amount to the accretion block
                if dune_x['lee_foot'] > substrate_x[3]:
                    qs_lee_overwash = qs_lee_overwash + q_to_lee
                    
                else:
    
                    def f_lee_overwash(ylprim_potential):
                        # Compute the candidate lee-foot position via slope + substrate
                        yl_flat_cand = ylprim_potential - (s_new_ero_lee - lee_foot_z_cur) / betal
                        lee_line_cand = LineString([(ylprim_potential, s_new_ero_lee),
                                                   (yl_flat_cand, lee_foot_z_cur)])
                        inter_cand = substrate_line.intersection(lee_line_cand)
                        if not inter_cand.is_empty:
                            if inter_cand.geom_type == "Point":
                                yl_cand, zl_cand = inter_cand.x, inter_cand.y
                            else:
                                pts = [p for p in inter_cand.geoms if p.geom_type == "Point"]
                                yl_cand, zl_cand = max(pts, key=lambda p: p.x).x, max(pts, key=lambda p: p.x).y
                        else:
                            yl_cand, zl_cand = yl_flat_cand, lee_foot_z_cur
    
                        # Evaluate partial_volume with candidate lee geometry
                        dx_trial = dict(dune_x)
                        dz_trial = dict(dune_z)
                        dx_trial['lee_foot']  = yl_cand
                        dz_trial['lee_foot']  = zl_cand
                        dx_trial['lee_crest'] = ylprim_potential
                        dz_trial['lee_crest'] = s_new_ero_lee
                        return (partial_volume(dx_trial, dz_trial, substrate_x, substrate_z,
                                              dx_trial['lee_foot'], dx_trial['ramp_toe'])
                                - v_target_lee)
    
                    # solve for ylprim_potential that gives the target volume
                    ub_lee = dune_x['lee_foot'] + (s_new_ero_lee - lee_foot_z_cur) / betal
                    
                    lb_lee = max(dune_x['lee_crest'] - 100, dune_x['back_ref'] + (s_new_ero_lee - lee_foot_z_cur) / betal) # do not let the trial lee foot pass back_ref (it would create a notch in the profile)
                    ylprim_new_l = brentq(f_lee_overwash, lb_lee, ub_lee)
                    #ylprim_new_l = brentq(f_lee_overwash, dune_x['lee_crest'] - 100, dune_x['lee_crest'])
                    yl_flat = ylprim_new_l - (s_new_ero_lee - lee_foot_z_cur) / betal
    
                    # use shapely to find intersection between new lee line and potential hard structure
                    # lee line: from lee crest (ylprim, s_new) to theoretical flat toe (yl_flat, dfoot)
                    lee_line = LineString([(ylprim_new_l, s_new_ero_lee), (yl_flat, lee_foot_z_cur)])
    
                    # find intersection(s)
                    intersection = substrate_line.intersection(lee_line)
    
                    if not intersection.is_empty:
                        if intersection.geom_type == "Point":
                            yl_new_l, z_int_l = intersection.x, intersection.y
                        else:  # multiple intersections, take the shallowest one (max x)
                            points = [pt for pt in intersection.geoms if pt.geom_type == "Point"]
                            yl_new_l, z_int_l = max(points, key=lambda p: p.x).x, max(points, key=lambda p: p.x).y
                    else:
                        # no intersection with hard substrate → use flat geometry
                        yl_new_l = yl_flat
                        z_int_l = lee_foot_z_cur
    
                    dune_x['lee_foot']  = yl_new_l
                    dune_z['lee_foot']  = z_int_l
                    dune_x['lee_crest'] = ylprim_new_l
                    dune_z['lee_crest'] = s_new_ero_lee

        if erod_crest_beach > 0:
            erod_overwash = max(0.0, erod_overwash - crest_to_beach)  # report lee part only
            deltavramp_ero = deltavramp_ero + crest_to_beach          # added to the beach in main
        # the accretion block does not run in an erosion step, so the overwash sand meant for it (qs_lee_overwash) was
        # dropped. Deposit it now on the lee with that same block (a call without erosion, ramp or crest deposition)
        if qs_lee_overwash > 0:
            dune_x, dune_z = morpho_update(dune_x, dune_z, substrate_x, substrate_z, 0.0, 0.0, qs_lee_overwash, 0.0, 0.0, r, swl, 0.0, dt,
                                           betas, betas_hs, betal, betal_hs, vramp, deltavall, lee_transfer=lee_transfer)[:2]
        vdune_test_after_overwash = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])
        
        #print('Delta Volume Overwash = ', vdune_test_after_overwash - vdune_test_before_overwash)
    # case 2: dune accretion
    
        vdune_afterero = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])

        if dune_z['seaward_crest']<0:
            print('debug')

    else:
        ######### DOUBLE CHECK THIS BLOCK
        #adjustments for very narrow beach width
        if dune_x['shoreline']-dune_x['ramp_toe'] < 20 and dune_z['seaward_crest'] == dune_z['ramp_toe']: #critical beach width
            ysprim_new = dune_x['ramp_toe'] - (20-(dune_x['shoreline']-dune_x['ramp_toe']))
            
            if ysprim_new < substrate_x[4]:
                ysprim_new = substrate_x[4]
                
            if ysprim_new < dune_x['lee_foot']:
                dune_x['lee_foot'] = ysprim_new
                
            dune_x['ramp_toe'] = ysprim_new
            dune_x['ramp_toe_temp'] = ysprim_new
            dune_x['ramp_crest'] = ysprim_new
            dune_x['ramp_crest_temp'] = ysprim_new
            dune_x['ramp_dike_temp'] = ysprim_new
            dune_x['lee_crest'] = ysprim_new
            dune_x['crest_temp'] = ysprim_new
            dune_x['seaward_crest'] = ysprim_new
                
                
        ##########################
        
        deltavramp_ero = 0.0
        deltavramp = 0.0
            
        # Initialize the idx for volume calculations
        ramp_idx = ['ramp_crest', 'ramp_toe']
        crest_idx = ['lee_crest', 'crest_temp', 'seaward_crest']
        lee_idx = ['lee_foot', 'lee_crest']

        # chech dune nourishment
        if vnourd > 0:
            qs_ramp = qs_ramp + vnourd
            
        # change in the ramp
        if qs_ramp > 0:
            deltavramp = qs_ramp # how much sand is deposited on the ramp
            
            # current, max, new
            vramp      = ramp_volume(dune_z['ramp_crest']-dfoot, dune_z['ramp_crest']-dfoot, dune_x['ramp_crest'], dune_x['ramp_toe'], betas, dfoot, substrate_x, substrate_z)
            #vramp      = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['ramp_crest'], dune_x['ramp_toe'])
            if (dune_x['seaward_crest'] <= substrate_x[2] and dune_z['seaward_crest'] <= substrate_z[2]) or dune_z['seaward_crest'] < dune_z['ramp_crest']: #case with detached lee side
                if dune_z['ramp_crest']>substrate_z[2] and dune_z['ramp_crest']>dune_z['seaward_crest']: #detached case with flat surface
                    x_foot_max = dune_x['ramp_crest'] + ((dune_z['ramp_crest']-dfoot)/betas)
                    vrampmax   = ramp_volume(dune_z['ramp_crest']-dfoot, dune_z['ramp_crest']-dfoot, dune_x['ramp_crest'], x_foot_max, betas, dfoot, substrate_x, substrate_z)
                else:
                    x_foot_max = substrate_x[3] + (s_hs)/betas
                    vrampmax   = ((((s_hs)**2)/(2*betas)))-((((s_hs)**2)/(2*betas_hs)))
            else:
                x_foot_max = dune_x['seaward_crest'] + ((dune_z['seaward_crest']-dfoot)/betas)
                vrampmax   = ramp_volume(dune_z['seaward_crest']-dfoot, dune_z['seaward_crest']-dfoot, dune_x['seaward_crest'], x_foot_max, betas, dfoot, substrate_x, substrate_z)
             
            vrampnew   = vramp + deltavramp
            
            # use different pivot point for detached case:
            if (dune_x['seaward_crest'] <= substrate_x[2] and dune_z['seaward_crest'] <= substrate_z[2] and dune_z['seaward_crest']<dune_z['ramp_dike_temp']) or dune_z['seaward_crest'] < dune_z['ramp_crest']:
                ys_temp = dune_x['ramp_crest'] + ((dune_z['ramp_crest']-dfoot) /betas)
            else:
                ys_temp = dune_x['seaward_crest'] + ((dune_z['seaward_crest']-dfoot) /betas)
            
            # FIX (ramp reaching a sand scarp that stands over the seaward dike face):
            # after erosion a vertical sand scarp can stand over the dike face (seaward_crest between
            # ysprim_hs and ys_hs) with the dike face exposed below it. The ramp is then rebuilt on the
            # dike face ("ramp in front of the dike" branch below). Once the ramp crest reaches the foot of
            # the scarp, the ramp has to keep growing against the sand scarp (normal procedure further
            # below), not continue up the dike face underneath the sand. Without this check the 1 cm
            # tolerance of the next elif keeps the dike branch active for a few more steps and the normal
            # procedure then fails in brentq ("f(a) and f(b) must have different signs"), e.g. test16d.
            # The flag is True only in that state; every other state follows the original branches.
            ramp_at_scarp = (abs(dune_x['seaward_crest'] - dune_x['ramp_crest']) <= 2e-2
                             and dune_x['ramp_toe'] > ys_hs + 1e-6
                             and substrate_x[3] < dune_x['seaward_crest'] < ys_hs
                             and dune_z['ramp_crest'] >= np.interp(dune_x['seaward_crest'], substrate_x, substrate_z) - 1e-6
                             and dune_z['seaward_crest'] > dune_z['ramp_crest'] + 1e-9
                             and dune_z['ramp_toe_temp'] <= dune_z['ramp_toe'] + 1e-9)
            if ramp_at_scarp:
                # the ramp crest sits at the scarp: align it exactly with the scarp position
                dune_x['ramp_crest'] = dune_x['seaward_crest']
                dune_x['ramp_dike_temp'] = dune_x['seaward_crest']
            # start with the detached case because of the order of the pivot points
            if (dune_x['ramp_crest'] > dune_x['seaward_crest'] and dune_z['seaward_crest']<dune_z['ramp_dike_temp'] and dune_z['ramp_crest'] == dune_z['ramp_dike_temp'] and dune_z['seaward_crest'] < dune_z['ramp_crest']):# or (dune_z['seaward_crest'] < dune_z['ramp_crest'] and dune_x['ramp_crest'] > dune_x['seaward_crest']):
                
                    sramp_new_r = dune_z['ramp_crest']-dfoot  # ramp full
                    vextra = vrampnew - vrampmax # extra volume that needs to be accomodated by moving the dune toe and ysprim
                    
                    ys_new_r = (vextra / (dune_z['ramp_crest']-dfoot)) + (ys + ((sramp_new_r - sramp) / betas)) # get the new seaward position of the ramp
                    ysprim_new_r = dune_x['ramp_crest'] + (vextra / (dune_z['ramp_crest']-dfoot))  # get the new crest position of the ramp 
                

                    dune_x['ramp_crest'] = ysprim_new_r
                    dune_x['ramp_toe'] = ys_new_r
                    dune_x['ramp_toe_temp'] = ys_new_r
                    dune_z['ramp_toe_temp'] = dfoot    
            
            # check if ramp is in front of the dike or not:
            elif (not ramp_at_scarp) and ((dune_x['ramp_crest'] > dune_x['seaward_crest'] + 1e-2) or (abs(dune_x['seaward_crest'] - dune_x['ramp_crest']) <= 1e-2 and dune_x['seaward_crest'] < ys_hs)):  # FIX: 1 cm tolerance, an eroded scarp leaves ramp_crest a few mm seaward of seaward_crest  # if there is a ramp building in front of a exposed dike (hence to connections) or a flat surface connecting somewhere in the dike with ys = ysprim
                
                if dune_z['seaward_crest'] <= s_hs + dfoot or dune_x['ramp_toe'] < ys_hs: # there is no active dune on top of the dike, OR ramp toe has retreated to/behind the dike seaward toe (post-erosion scarp: ramp_crest==seaward_crest, dike face exposed, recovery needed): # there is no active dune on top of the dike, and everything is exposed
                    vrampmax_hs = ((((s_hs)**2)/(2*betas)))-((((s_hs)**2)/(2*betas_hs))) # volume to fill the front of the dike
                    x_rampfoot_max = substrate_x[3] + (s_hs)/betas
                    
                    v_dike = (substrate_x[4]-substrate_x[3])*(substrate_z[3]-substrate_z[4])/2
                    v_bottom_full = (x_rampfoot_max - substrate_x[3])*(substrate_z[3]-substrate_z[4])/2
                    v_bottom = ((dune_x['ramp_toe'] - dune_x['ramp_crest'])*(dune_z['ramp_crest'] - dune_z['ramp_toe'])/2) - ((substrate_x[4]- dune_x['ramp_crest'])*(dune_z['ramp_crest'] - dune_z['ramp_toe'])/2)
                    
                    if v_bottom < 0:
                        v_bottom = 0
                        
                    v_to_fill = v_bottom_full - v_dike - v_bottom #this is the volume to fill the front of the dike
                    
                    if deltavramp < v_to_fill: # if the volume is not sufficient to fill the whole front of the dike:
                        sramp_new_r = ((2 * (deltavramp+v_bottom)) / ((1 / betas) - (1 / betas_hs))) ** 0.5
                        ysprim_new_r = ys_hs - (sramp_new_r/betas_hs)
                        ys_new_r = ysprim_new_r+(sramp_new_r/betas)
                        
                        # check where to update:
                        if ((dune_z['seaward_crest'] - dune_z['ramp_toe']) > s_hs and dune_x['ramp_toe'] <= substrate_x[4]) or dune_x['seaward_crest'] < dune_x['ramp_crest']: #check if no ramp or detacehd
                           
                           #check if there is ramp on top of the dune or not
                           v_temp = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['seaward_crest'], substrate_x[4])
                           
                           
                           if v_temp > 0 and dune_z['seaward_crest'] > substrate_z[2]: #means there is a ramp on top, not scarp
                               dune_x['ramp_dike_temp'] = dune_x['seaward_crest'] + ((dune_z['seaward_crest'] - substrate_z[3])/betas)
                               dune_z['ramp_dike_temp'] = s_hs + dfoot
                           elif dune_x['ramp_toe_temp'] == substrate_x[3] and dune_x['ramp_crest'] == substrate_x[2]: #condition where there is only dune in the back of the dike due to overwash
                               dune_z['ramp_toe_temp'] = sramp_new_r+dfoot
                           else: #assume a scarp
                               dune_x['ramp_dike_temp'] = dune_x['seaward_crest']
                               dune_x['ramp_dike_temp'] = substrate_x[2]
                               dune_z['ramp_dike_temp'] = s_hs + dfoot
       

                           dune_x['ramp_toe'] = ys_new_r
                           dune_x['ramp_toe_temp'] = ys_new_r
                           dune_z['ramp_toe_temp'] = dfoot
                           dune_z['ramp_crest'] = sramp_new_r+dfoot
                           dune_x['ramp_crest'] = ysprim_new_r

                        else:
                           
                            if dune_z['seaward_crest'] < substrate_z[3]: #check again if there is on top or not
                                dune_z['seaward_crest'] = sramp_new_r+dfoot
                                dune_z['ramp_dike_temp'] = sramp_new_r+dfoot
                                
                            dune_x['ramp_toe'] = ys_new_r
                            dune_x['ramp_toe_temp'] = ys_new_r
                            dune_z['ramp_toe_temp'] = dfoot
                            dune_z['ramp_crest'] = sramp_new_r+dfoot
                            dune_x['ramp_crest'] = ysprim_new_r
                            dune_x['seaward_crest'] = ysprim_new_r
                            dune_x['ramp_dike_temp'] = ysprim_new_r
                           
                        
                    elif v_to_fill < 0: #case where the front is already filled but enters this part because of the remaining pivot crest locations
                        #since there is no crest, just move the ramp forward
                        vextra = deltavramp # extra volume that needs to be accomodated by moving the dune toe and ysprim
                        
                        ys_new_r = (vextra / dune_z['ramp_crest']) + ys # get the new seaward position of the ramp
                        ysprim_new_r = ysprim + (vextra / dune_z['ramp_crest'])  # get the new crest position of the ramp 
                        
                        dune_x['ramp_toe'] = ys_new_r
                        dune_x['ramp_crest'] = ysprim_new_r
                        dune_x['seaward_crest'] = ysprim_new_r
                        dune_x['ramp_dike_temp'] = ysprim_new_r
                        dune_z['seaward_crest'] = dune_z['ramp_crest']
                        dune_z['ramp_dike_temp'] = dune_z['ramp_crest']
                        
                    else:
                        vextra = deltavramp-v_to_fill #amount to be used to redistribute it in front of the dike
                        sramp_new_r = s_hs #fill completely up to the dike height                
                        
                        if dune_x['seaward_crest'] <= substrate_x[2] and dune_z['seaward_crest'] < substrate_z[2]: #case with detached lee side, use the ramp position
                            ysprim_new_r = dune_x['ramp_crest'] + (vextra / sramp_new_r)  # get the new crest position of the ramp 
                            ys_new_r = (sramp_new_r/betas) + ysprim_new_r
                        else:
                            ysprim_new_r = ysprim + (vextra / sramp_new_r)  # get the new crest position of the ramp 
                            ys_new_r = (sramp_new_r/betas) + ysprim_new_r
                        
                        dune_x['ramp_toe'] = ys_new_r
                        dune_z['ramp_crest'] = sramp_new_r+dfoot
                        dune_x['ramp_crest'] = ysprim_new_r
                        dune_x['seaward_crest'] = ysprim_new_r
                        dune_z['seaward_crest'] = sramp_new_r+dfoot
                        dune_x['ramp_dike_temp']= ysprim_new_r #ysprim
                        dune_z['ramp_dike_temp'] = sramp_new_r+dfoot #s+dfoot
                        
                elif ys_temp < ys_hs and dune_z['seaward_crest'] > s_hs + substrate_z[1]: #there is dune on top but the height is not enough to fill the front
                    
                    # check if the volume needed to reconnect the ramp side

                    vrampmax_hs = ((((s_hs)**2)/(2*betas)))-((((s_hs)**2)/(2*betas_hs))) # volume to fill the front of the dike
                    x_rampfoot_max = substrate_x[3] + (s_hs)/betas
                    
                    v_dike = (substrate_x[4]-substrate_x[3])*(substrate_z[3]-substrate_z[4])/2
                    v_bottom_full = (x_rampfoot_max - substrate_x[3])*(substrate_z[3]-substrate_z[4])/2
                    v_bottom = ((dune_x['ramp_toe'] - dune_x['ramp_crest'])*(dune_z['ramp_crest'] - dune_z['ramp_toe'])/2) - ((substrate_x[4]- dune_x['ramp_crest'])*(dune_z['ramp_crest'] - dune_z['ramp_toe'])/2)
                    
                    if v_bottom < 0:
                        v_bottom = 0
                        
                    v_to_fill = v_bottom_full - v_dike - v_bottom #this is the volume to fill the front of the dike
                    
                    if deltavramp < v_to_fill: # if the volume is not sufficient to fill the whole front of the dike:
                       sramp_new_r = ((2 * (deltavramp+v_bottom)) / ((1 / betas) - (1 / betas_hs))) ** 0.5
                       ysprim_new_r = ys_hs - (sramp_new_r/betas_hs)
                       ys_new_r = ysprim_new_r+(sramp_new_r/betas)
                       
                       # check where to update:
                       if ((dune_z['seaward_crest'] - dune_z['ramp_toe']) > s_hs and dune_x['ramp_toe'] <= substrate_x[4]) or dune_x['seaward_crest'] < dune_x['ramp_crest']: #check if no ramp or detacehd
                           
                           #check if there is ramp on top of the dune or not
                           v_temp = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['seaward_crest'], substrate_x[4])
                           
                           if v_temp > 0: #means there is a ramp on top, not scarp
                               dune_x['ramp_dike_temp'] = dune_x['seaward_crest'] + ((dune_z['seaward_crest'] - substrate_z[3])/betas)
                               dune_z['ramp_dike_temp'] = s_hs + dfoot
                           else: #assume a scarp
                               dune_x['ramp_dike_temp'] = dune_x['seaward_crest']
                               dune_x['ramp_dike_temp'] = substrate_x[2]
                               dune_z['ramp_dike_temp'] = s_hs + dfoot
       
                           dune_x['ramp_toe'] = ys_new_r
                           dune_x['ramp_toe_temp'] = ys_new_r
                           dune_z['ramp_toe_temp'] = dfoot
                           dune_z['ramp_crest'] = sramp_new_r+dfoot
                           dune_x['ramp_crest'] = ysprim_new_r

                       else:
                           dune_x['ramp_toe'] = ys_new_r
                           dune_x['ramp_toe_temp'] = ys_new_r
                           dune_z['ramp_toe_temp'] = dfoot
                           dune_z['ramp_crest'] = sramp_new_r+dfoot
                           dune_x['ramp_crest'] = ysprim_new_r
                           dune_x['seaward_crest'] = ysprim_new_r
                           dune_x['ramp_dike_temp'] = ysprim_new_r
                           
                    else:
                        #vol_to_fill_top = ((ysprim_hs - dune_x['seaward_crest'])**2)*betas*0.5 #volume to fill the top of the dike and stop the intersection
                        vol_to_fill_top = (ysprim_hs - (2*(dune_z['seaward_crest']-dune_z['ramp_crest'])/betas))*((dune_z['seaward_crest']-dune_z['ramp_crest'])/2)
                        vol_to_fill_face = ((((s_hs)**2)/(2*betas)))-((ys_hs-ysprim_hs)*(s_hs)*0.5) #volume to fill the face of the dike
                        vol_extra = vrampnew - vol_to_fill_face #extra volume that needs to be accomodated above the dike
                        
                        #check if the front is already filled, so just move all to the top (case 9b)
                        if v_to_fill < 0:
                            vol_extra = deltavramp
                        
                        _v_before_ramp = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])
                        def f_ramp_dike_top(sramp_potential):
                            # same pivot update as below, volume measured as the partial_volume change of the trial profile
                            s_new = sramp_potential + dune_z['ramp_crest']
                            tx, tz = dict(dune_x), dict(dune_z)
                            tx['ramp_dike_temp'] = ysprim + ((dune_z['seaward_crest'] - s_new)/betas); tz['ramp_dike_temp'] = s_new
                            tx['ramp_crest'] = dune_x['ramp_crest'] - ((s_new - dune_z['ramp_crest'])/betas); tz['ramp_crest'] = s_new
                            return partial_volume(tx, tz, substrate_x, substrate_z, tx['lee_foot'], tx['ramp_toe']) - _v_before_ramp - vol_extra
                        
                        vol_to_fill_top = f_ramp_dike_top(dune_z['seaward_crest']-dune_z['ramp_crest']) + vol_extra #room left on top of the dike up to the dune crest
                            
                        if vol_extra < vol_to_fill_top: #thus not enough to fill everything and stop connection with dike
                            
                            # solve for sramp_potential that gives the target volume
                            sramp_new_r = brentq(f_ramp_dike_top, 0, dune_z['seaward_crest']-dune_z['ramp_crest']) + dune_z['ramp_crest'] # find the new ramp height using the root finder padding only the top of the dike
                            dune_x['ramp_dike_temp'] = ysprim + (((dune_z['seaward_crest'])-sramp_new_r)/betas) #pad the previous so that it only updates when fully filled
                            dune_x['ramp_crest'] = dune_x['ramp_crest'] - ((sramp_new_r-dune_z['ramp_crest'])/betas) #foot based on the dike because it only moves once everything is filled
                            dune_z['ramp_crest'] = sramp_new_r
                            #dune_x['ramp_toe'] = dune_x['ramp_crest']+(sramp_new_r/betas)
                            #dune_z['ramp_toe'] = dfoot
                            dune_z['ramp_dike_temp'] = sramp_new_r #get the same height as the ramp until filled
        
                            
                        else: #enough to fill everything and stop connection with dike
                        
                            # relink everything
                            dune_z['ramp_dike_temp'] = dune_z['seaward_crest']
                            dune_z['ramp_crest'] = dune_z['seaward_crest']
                            dune_x['ramp_crest'] = dune_x['ramp_toe'] - ((dune_z['ramp_crest']-dune_z['ramp_toe'])/betas)
                            dune_x['ramp_dike_temp'] =  dune_x['ramp_crest']
                            dune_x['seaward_crest'] =  dune_x['ramp_crest']
                            
                            #find volume extra to be redistributed in the crest (what the relink did not take, measured)
                            vol_extra = vol_extra - (partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe']) - _v_before_ramp)
                            
                            #use the remaining volume to fill the crest
                            qs_crest = qs_crest+vol_extra
                    
                elif vrampnew < vrampmax: # there is some dune on the top or partial front
                    def f_ramp_dike(sramp_potential):
                        return ramp_volume(sramp_potential, dune_z['ramp_crest']-dfoot, dune_x['ramp_crest'], dune_x['ramp_toe'], betas, dfoot, substrate_x, substrate_z) - vrampnew
                    
                    # ## solve for sramp_potential that gives the target volume
                    # sramp_new_r = brentq(f_ramp_dike, dune_z['ramp_crest']-dfoot, dune_z['seaward_crest']-dfoot) # find the new ramp height using the root finder
        
                    # if sramp_new_r < s_hs: #check if the sramp is within the dike face
                    #     ys_new_r = ys_hs + (sramp_new_r/betas) - (sramp_new_r/betas_hs)
                    #     dune_x['ramp_crest'] = ys_new_r - (sramp_new_r/betas)
                    #     dune_x['ramp_dike_temp'] = dune_x['seaward_crest']
                    #     dune_z['ramp_dike_temp'] = sramp_new_r + dfoot
                    
                    
                    # When the ramp height already equals the crest height the brentq
                    # bounds would be equal (no room to grow taller).  In this case the
                    # ramp has reached the crest and any new sand simply extends it
                    # seaward at the same height, identical to the "ramp full" logic.
                    if dune_z['ramp_crest'] >= dune_z['seaward_crest'] - 1e-6:
                        sramp_new_r = s
                        ys_new_r = ys + deltavramp / s
                        ysprim_new_r = ysprim + deltavramp / s
                        dune_x['ramp_toe'] = ys_new_r
                        dune_z['ramp_crest'] = sramp_new_r + dfoot
                        dune_x['ramp_crest'] = ysprim_new_r
                        dune_x['seaward_crest'] = ysprim_new_r
        
                    else: #needs new calculationgs
                    
                        # check if lower and upper ramp exists
                        if dune_z['ramp_crest'] < dune_z['ramp_dike_temp'] and dune_x['ramp_dike_temp']>ysprim_hs and dune_x['ramp_dike_temp'] < ys_hs: # there is a remaining scarp on the top and a smaller rmap being built below
                            # fix the upper scarp position
                            upper_scarp_x = dune_x['ramp_dike_temp']
                            upper_scarp_z = np.interp(upper_scarp_x, substrate_x, substrate_z)
                                                            
                            def f_ramp_dike_lowerramp(sramp_potential):
                                # toe position consistent with slope
                                #yspotential = dune_x['ramp_toe'] + ((sramp_potential) / betas)
                                #ysprim_potential = yspotential - (sramp_potential/betas)
                                
                                # toe position consistent with slope (ramp builds against dike face, anchored at ys_hs)
                                ysprim_potential = ys_hs - (sramp_potential / betas_hs)
                                yspotential = ysprim_potential + (sramp_potential / betas)
                                
                                # ramp line
                                dune_x_line = np.array([ysprim_potential, yspotential])
                                dune_z_line = np.array([sramp_potential + dfoot, dfoot])
                                
                                n_per_segment = 100  # how many points per segment
                                x_dense = np.concatenate([np.linspace(dune_x_line[i], dune_x_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_line)-1)] + [[dune_x_line[-1]]])
                                z_dense = np.concatenate([np.linspace(dune_z_line[i], dune_z_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_line)-1)] + [[dune_z_line[-1]]])
                                
                                # substrate under ramp
                                z_sub_line = np.interp(x_dense, substrate_x, substrate_z)
                                
                                # trapezoidal integration
                                return trapezoid_positive(z_dense - z_sub_line, x_dense) - vrampnew
                                                                
                            # find if there is a small ramp already growing or not
                            sramp_new_r = brentq(f_ramp_dike_lowerramp, 0, upper_scarp_z) # find the new ramp height using the root finder
                            ys_new_r = ys_hs + ((sramp_new_r)/betas) - ((sramp_new_r)/betas_hs)
                            
                            dune_x['ramp_crest'] = ys_new_r - (sramp_new_r/betas)
                            dune_z['ramp_crest'] = sramp_new_r + dfoot
                            dune_x['ramp_toe'] = ys_new_r
                            dune_x['ramp_toe_temp'] = ys_new_r
                            dune_z['ramp_toe_temp'] = dfoot
                            dune_z['ramp_dike_temp'] = upper_scarp_z
                            
                        else:
                            # solve for sramp_potential that gives the target volume
                            sramp_new_r = brentq(f_ramp_dike, dune_z['ramp_crest']-dfoot, dune_z['seaward_crest']-dfoot) # find the new ramp height using the root finder
    
                            if sramp_new_r < s_hs: #check if the sramp is within the dike face
                                #ys_new_r = ys_hs + (sramp_new_r/betas) - (sramp_new_r/betas_hs)
                                if ys_hs <= dune_x['ramp_toe']:
                                    ys_new_r = dune_x['ramp_toe'] + ((sramp_new_r-sramp)/betas) - ((sramp_new_r-sramp)/betas_hs)
                                else:
                                    ys_new_r = ys_hs + ((sramp_new_r-sramp)/betas) - ((sramp_new_r-sramp)/betas_hs)
                                    
                                
                                dune_x['ramp_crest'] = ys_new_r - (sramp_new_r/betas)
                                #dune_x['ramp_crest'] = ys_new_r - ((sramp_new_r-sramp)/betas)
                                dune_x['ramp_dike_temp'] = dune_x['seaward_crest']
                                dune_z['ramp_dike_temp'] = sramp_new_r + dfoot
                                dune_x['ramp_toe'] = ys_new_r
                                dune_z['ramp_crest'] = sramp_new_r + dfoot
                                #dune_z['ramp_crest'] = betas*(ys_new_r-dune_x['ramp_crest'])
                                
                                #test
                                dune_x['ramp_toe_temp'] = ys_new_r
                                dune_z['ramp_toe_temp'] = dfoot


                            else: #needs new calculations
                                vol_to_fill_top = ((ysprim_hs - dune_x['seaward_crest'])**2)*betas*0.5 #volume to fill the top of the dike and stop the intersection
                                vol_to_fill_face = ((((s_hs)**2)/(2*betas)))-((ys_hs-ysprim_hs)*(s_hs)*0.5) #volume to fill the face of the dike
                                vol_extra = vrampnew - vol_to_fill_face #extra volume that needs to be accomodated above the dike
                        
                            
                                if vol_extra < vol_to_fill_top: #thus not enough to fill everything and stop connection with dike
                
                                    def f_ramp_dike_top(sramp_potential):
                                        toebound = ysprim_hs
                                        crestbound = dune_x['seaward_crest']
                                        sramp_prim_x = toebound - (sramp_potential/betas)
                                        dune_x_crest = np.array([crestbound, sramp_prim_x, toebound])
                                        dune_z_crest = np.array([sramp_potential - s_hs, sramp_potential - s_hs, 0])
                
                                        # volume between crest line and substrate
                                        V = np.trapezoid(dune_z_crest, dune_x_crest)
                                
                                        return V - vol_extra
                                    
                                    # solve for sramp_potential that gives the target volume
                                    sramp_new_r = brentq(f_ramp_dike_top, 0, dune_z['seaward_crest']-s_hs) + s_hs # find the new ramp height using the root finder padding only the top of the dike
                                    dune_x['ramp_crest'] = ysprim_hs - (sramp_new_r/betas)
                                    dune_z['ramp_crest'] = sramp_new_r
                                    
                                else: #enough to fill everything and stop connection with dike
                                    ysnew = sramp_new_r / betas + dune_x['seaward_crest']
                                    dune_x['ramp_crest'] = dune_x['seaward_crest']
                                    dune_z['ramp_crest'] = sramp_new_r + dfoot
                                    dune_x['ramp_dike_temp'] = None
                                    dune_z['ramp_dike_temp'] = None
                                    dune_x['ramp_toe'] = ysnew
                                    dune_z['ramp_toe'] = dfoot
        
                else:
                    sramp_new_r = s  # ramp full
                    vextra = vrampnew - vrampmax # extra volume that needs to be accomodated by moving the dune toe and ysprim
                    
                    ys_new_r = (vextra / s) + (ys + ((sramp_new_r - sramp) / betas)) # get the new seaward position of the ramp
                    ysprim_new_r = ysprim + (vextra / s)  # get the new crest position of the ramp 
                    
                    dune_x['ramp_toe'] = ys_new_r
                    dune_z['ramp_crest'] = sramp_new_r+dfoot
                    dune_x['ramp_crest'] = ysprim_new_r
                    dune_x['seaward_crest'] = ysprim_new_r
                    dune_x['ramp_toe_temp'] = ys_new_r #move with the face (otherwise the old toe stays as a pivot and the sand only appears when it is reset)
                    dune_z['ramp_toe_temp'] = dfoot
                    dune_x['ramp_dike_temp'] = ysprim_new_r
                    dune_z['ramp_dike_temp'] = sramp_new_r+dfoot
                    
        
            else: #continue with normal procedure without hard structure interaction
        
                # a small erosion of a full ramp leaves a step at the toe (ramp_toe_temp above ramp_toe). The straight
                # crest-toe line used for vramp misses the sand in that step, so add it (zero when there is no step);
                # otherwise a ramp that is still full looks underfilled and ramp_crest drops below seaward_crest
                toe_step = dune_z['ramp_toe_temp'] > dune_z['ramp_toe'] + 1e-12
                if toe_step:
                    vrampnew = vrampnew + 0.5 * ((dune_x['ramp_toe'] - dune_x['ramp_crest']) * (dune_z['ramp_toe_temp'] - dune_z['ramp_crest'])
                                                 - (dune_x['ramp_toe_temp'] - dune_x['ramp_crest']) * (dune_z['ramp_toe'] - dune_z['ramp_crest']))
                
                # FIX: a ramp that is already full (ramp_crest at seaward_crest) cannot be solved for a
                # new height: the solver bracket [ramp height, crest height] has zero width. Its volume
                # can still come out a hair below vrampmax (toe a fraction of a mm off), so treat it as full.
                # A full-height ramp with a step at the toe (toe_step) keeps its own handling below.
                ramp_partial = (vrampnew < vrampmax) and (toe_step or dune_z['seaward_crest'] - dune_z['ramp_crest'] > 1e-9)
                if ramp_partial: # check if the volume in the front of dune is below the maximum
                
                    # def f_ramp(sramp_potential):
                    #     return ramp_volume(sramp_potential, dune_z['ramp_crest']-dfoot, dune_x['ramp_crest'], dune_x['ramp_toe'], betas, dfoot, substrate_x, substrate_z) - vrampnew

                    s_max = dune_z['seaward_crest'] - dfoot
                    x_foot_max = dune_x['seaward_crest'] + s_max / betas
                    
                    def f_ramp(sramp_potential):
                        # Toe position consistent with the maximum-height geometry
                        ys_potential = x_foot_max - ((s_max - sramp_potential) / betas)
                    
                        # Use the potential toe position as the reference toe
                        return ramp_volume(
                            sramp_potential,
                            sramp_potential,  # makes yspotential equal to ys_potential
                            dune_x['seaward_crest'],
                            ys_potential,
                            betas,
                            dfoot,
                            substrate_x,
                            substrate_z
                        ) - vrampnew
                    
                    
                    # solve for sramp_potential that gives the target volume
                    if dune_z['ramp_crest'] == dune_z['seaward_crest'] and dune_z['ramp_toe_temp'] > dune_z['ramp_toe'] and dune_z['ramp_toe_temp'] < dune_z['ramp_crest']:
                        lo_r = dune_z['ramp_toe_temp']-dfoot
                        if f_ramp(lo_r) > 0: # scarp cut high on the face (above about s/sqrt(2)): what is left is less than a ramp of the cut height, so the root lies below it
                            lo_r = 0.0
                        sramp_new_r = brentq(f_ramp, lo_r, dune_z['seaward_crest']-dfoot) # find the new ramp height using the root finder
                    else:
                        sramp_new_r = brentq(f_ramp, dune_z['ramp_crest']-dfoot, dune_z['seaward_crest']-dfoot) # find the new ramp height using the root finder
                    #ys_new_r = dune_x['ramp_crest'] + (sramp_new_r / betas)
                    #ys_new_r = ys + ((sramp_new_r-sramp) / betas)
                    ys_new_r = x_foot_max - ((s_max - sramp_new_r) / betas)
                    
                else: # if the volume exceeds the maximum, then move the role thing with fixed ramp height and slope, but moving ysprim.
                    sramp_new_r = dune_z['seaward_crest']-dfoot  # ramp full
                    vextra = vrampnew - vrampmax # extra volume that needs to be accomodated by moving the dune toe and ysprim
                    
                    ys_new_r = (vextra / (dune_z['seaward_crest']-dfoot)) + (x_foot_max if toe_step else (ys + ((sramp_new_r - sramp) / betas))) # with a toe step, move the full face; from the eroded toe the step's sand would be lost
                    ysprim_new_r = ysprim + (vextra / s)  # get the new crest position of the ramp 
                
                # update dune array with new ramp and toe position
                if ramp_partial:
                    dune_x['ramp_toe'] = ys_new_r
                    dune_x['ramp_toe_temp'] = ys_new_r
                    dune_z['ramp_toe_temp'] = dfoot
                    dune_z['ramp_crest'] = sramp_new_r+dfoot
                    dune_z['ramp_dike_temp'] = sramp_new_r+dfoot
                else:
                    dune_x['seaward_crest'] = ysprim_new_r
                    dune_x['ramp_crest'] = ysprim_new_r
                    dune_x['ramp_dike_temp'] = ysprim_new_r
                    dune_x['ramp_toe'] = ys_new_r
                    dune_x['ramp_toe_temp'] = ys_new_r
                    dune_z['ramp_toe_temp'] = dfoot
                    dune_z['ramp_crest'] = sramp_new_r+dfoot
                    dune_z['ramp_dike_temp'] = sramp_new_r+dfoot
                    #dune_z['crest_temp'] = sramp_new_r+dfoot
                    #dune_x['crest_temp'] = ysprim_new_r
                
                # calculate total initial volume above the substrate
        total_volume_ramp = total_volume([dune_x[k] for k in list(dune_x.keys())[1:8]], [dune_z[k] for k in list(dune_z.keys())[1:8]], substrate_x, substrate_z)
        vdune_afterramp = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])

        # calculate total initial volume above the substrate
        if dune_x['ramp_dike_temp'] is not None:
            ramp_idx = ['ramp_dike_temp', 'ramp_crest', 'ramp_toe']
        else:
            ramp_idx = ['ramp_crest', 'ramp_toe']
        
        total_volume_ramp_ramp = total_volume([dune_x[k] for k in ramp_idx], [dune_z[k] for k in ramp_idx], substrate_x, substrate_z)
        total_volume_crest_ramp = total_volume([dune_x[k] for k in crest_idx], [dune_z[k] for k in crest_idx], substrate_x, substrate_z)
        total_volume_lee_ramp = total_volume([dune_x[k] for k in lee_idx], [dune_z[k] for k in lee_idx], substrate_x, substrate_z)
        
        ################## Crest ##################
        vlee_lateral = 0
        detach_tag = 0
        # defaults for a step with lee deposition but none on the crest (qs_crest = 0): the lee block then works
        # with the current lee crest height and pivots
        s_new_c = dune_z['lee_crest'] - dfoot
        yl_new_c = dune_x['lee_foot']
        ysprim_new_c = dune_x['seaward_crest']
        
        # ROUNDING GUARD (needed once the dune toe level is not a round number, i.e. with slr_toe/dynamic_toe):
        # pivots that are at the seaward-crest level up to rounding get exactly that level. The branch tests
        # below compare elevations with < and ==, and (z - dfoot) + dfoot is not always exactly z. Without
        # this, a 1-bit difference sends a normal step into the detached-crest branch and the crest deposit
        # of that step is lost. With a round dfoot nothing is changed (results are bit-identical).
        for _k in ('lee_crest', 'crest_temp', 'ramp_dike_temp', 'ramp_crest'):
            if dune_z.get(_k) is not None and dune_z[_k] != dune_z['seaward_crest'] and abs(dune_z[_k] - dune_z['seaward_crest']) <= 1e-9:
                dune_z[_k] = dune_z['seaward_crest']
        if qs_crest > 0:
            # change in the crest
            deltavcrest = qs_crest # how much sand is deposited on the crest
            
            # calculate the substrate under the crest

            if (dune_z['lee_crest']>=substrate_z[2] and dune_z['lee_crest'] < dune_z['ramp_dike_temp'] and dune_z['seaward_crest'] < dune_z['ramp_dike_temp']) or (dune_x['lee_crest'] < substrate_x[2] and dune_z['lee_crest'] < substrate_z[2] and dune_z['seaward_crest'] < dune_z['ramp_dike_temp']):
                
                xtemp = [dune_x['ramp_crest'],dune_x['ramp_toe']]
                ztemp = [dune_z['ramp_crest'],dune_z['ramp_toe']]

                ramp_limit = interp1d(ztemp, xtemp)(substrate_z[2]) #use this instead of substrate because the ramp can grow seaward in between 
                #vcrestnew = partial_volume(dune_x,dune_z,substrate_x,substrate_z,substrate_x[2],ramp_limit) + deltavcrest # new volume of the crest after accretion
                vcrestnew = partial_volume(dune_x,dune_z,substrate_x,substrate_z,substrate_x[2],dune_x['ramp_crest']) + deltavcrest # new volume of the crest after accretion

            elif dune_x['lee_crest'] < substrate_x[2] and dune_z['lee_crest'] < substrate_z[2]:# if detached pad the crest to the dike
                vcrestnew = partial_volume(dune_x,dune_z,substrate_x,substrate_z,substrate_x[2],dune_x['seaward_crest']) + deltavcrest # new volume of the crest after accretion
            
            else:
                vcrestnew = total_volume_crest_ramp + deltavcrest # new volume of the crest after accretion
            
            vcrest_triangular = None

            #slumping lee behind the dike: lee crest on the dike back slope, lee foot on the back base, and the lee volume fits as a wedge leaning on the dike below its crest (V = 0.5*h^2*(1/betal - 1/slope_back))
            slumping_lee = False
            if substrate_x[2] > substrate_x[1] and substrate_z[2] > substrate_z[1] and substrate_x[1] <= dune_x['lee_crest'] < substrate_x[2] and dune_z['lee_crest'] < substrate_z[2] and abs(dune_z['lee_foot'] - substrate_z[1]) < 1e-6:
                slope_back = (substrate_z[2] - substrate_z[1]) / (substrate_x[2] - substrate_x[1])
                vlee_old = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], substrate_x[2])
                h_lee = (2 * vlee_old / (1 / betal - 1 / slope_back)) ** 0.5
                slumping_lee = h_lee < substrate_z[2] - substrate_z[1]
            #check if it is the first time the crest reaches the dike top with a slumping lee behind it (crest_temp of the old dune buried in the dike). If so, rearrange the pivot points:
            #crest_temp to the landward dike crest, lee_crest on the dike back face keeping the lee volume
            if slumping_lee and dune_z['crest_temp'] < np.interp(dune_x['crest_temp'], substrate_x, substrate_z) - 1e-9 and dune_z['seaward_crest'] >= substrate_z[2]:
                dune_x['lee_crest'] = substrate_x[1] + h_lee / slope_back
                dune_z['lee_crest'] = substrate_z[1] + h_lee
                dune_x['lee_foot'] = dune_x['lee_crest'] - h_lee / betal
                dune_x['crest_temp'] = substrate_x[2]
                dune_z['crest_temp'] = substrate_z[2]

            # check if needed to use temp of lee_crest due to detached lee_side
            if dune_x['crest_temp'] > dune_x['lee_crest'] and abs(dune_z['crest_temp'] - dune_z['lee_crest']) < 1e-9 and dune_z['lee_crest'] < dune_z['ramp_dike_temp'] and not slumping_lee: #substrate_z[2]: #detached with flat crest behind
                
                #check if it is the first time entering this block. If so, rearrange the pivot points
                if dune_x['ramp_crest'] == dune_x['seaward_crest'] and dune_x['seaward_crest'] == dune_x['ramp_dike_temp'] and dune_z['seaward_crest'] == substrate_z[2]:
                    dune_x['seaward_crest'] = substrate_x[2]
                    dune_x['ramp_dike_temp'] = substrate_x[2]
            
                s_max_triangular = (betal * betas * (dune_x['ramp_crest'] - dune_x['ramp_dike_temp'])) / (betal + betas)
                vcrest_triangular = 0.5 * (dune_x['ramp_crest'] - dune_x['ramp_dike_temp']) * s_max_triangular #max volume for triangular shape

            elif dune_x['lee_crest'] <= substrate_x[2] and dune_z['lee_crest'] < substrate_z[2]:
                # calculate maximum volume up till the crest becomes triangular (when ysprim=ylprim)
                s_max_triangular = (betal * betas * (dune_x['seaward_crest'] - dune_x['crest_temp'])) / (betal + betas)
                vcrest_triangular = 0.5 * (dune_x['seaward_crest'] - dune_x['crest_temp']) * s_max_triangular #max volume for triangular shape
            
            if vcrest_triangular is None:
                # calculate maximum volume up till the crest becomes triangular (when ysprim=ylprim)
                s_max_triangular = (betal * betas * (dune_x['seaward_crest'] - dune_x['lee_crest'])) / (betal + betas)
                vcrest_triangular = 0.5 * (dune_x['seaward_crest'] - dune_x['lee_crest']) * s_max_triangular #max volume for triangular shape
  

            if deltavcrest <= vcrest_triangular:
                # calculate the pontial new dune height, ysprim and ylprim based on geometry and relation with the substrate
                # Define function for volume as function of s potential (crest height)
                def f_crest_triangular(s_potential):
        
                    ystemp = dune_x['seaward_crest'] # fix it but transform it in the new "foot" so to account for the increase as a trapezoid, not block
                    yltemp = dune_x['lee_crest']
        
                    ysprim_potential = ystemp - ((s_potential-s)/betas)
                    ylprim_potential = yltemp + ((s_potential-s)/betal)
            
                    # linear crest line: from (ylprim_potential, s_potential) to (ysprim_potential, s_potential)
                    dune_x_crest = np.array([yltemp, ylprim_potential, ysprim_potential, ystemp])
                    dune_z_crest = np.array([s + dfoot, s_potential + dfoot, s_potential + dfoot, s + dfoot])
            
                    n_per_segment = 100  # how many points per segment
                    x_dense = np.concatenate([np.linspace(dune_x_crest[i], dune_x_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_crest)-1)] + [[dune_x_crest[-1]]])
                    z_dense = np.concatenate([np.linspace(dune_z_crest[i], dune_z_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_crest)-1)] + [[dune_z_crest[-1]]])
            
                    # substrate under crest
                    z_sub_crest = np.interp(x_dense, substrate_x, substrate_z)
            
                    # volume between crest line and substrate
                    V = trapezoid_positive(z_dense - z_sub_crest, x_dense)
                    
                    if s_potential == s:
                        return -vcrestnew
                    else:
                        return V - vcrestnew
                
                def f_crest_triangular_detach(s_pot):
        
                    tx, tz = dict(dune_x), dict(dune_z)
                    _ys = dune_x['seaward_crest'] - (s_pot - s) / betas
                    tx['crest_temp'] = dune_x['crest_temp'] + (s_pot - s) / betal
                    tz['crest_temp'] = s_pot + dfoot
                    for _k in ('seaward_crest', 'ramp_dike_temp', 'ramp_crest'):
                        tx[_k] = _ys; tz[_k] = s_pot + dfoot
                    return partial_volume(tx, tz, substrate_x, substrate_z, tx['lee_foot'], tx['ramp_toe']) - _v_before - deltavcrest
                    # ystemp = dune_x['seaward_crest'] # fix it but transform it in the new "foot" so to account for the increase as a trapezoid, not block
                    # #yltemp = dune_x['crest_temp']
                    # yltemp = substrate_x[2] # fixed at dike position
        
                    # ysprim_potential = ystemp - ((s_potential-s)/betas)
                    # ylprim_potential = yltemp + ((s_potential-s)/betal)
            
                    # # linear crest line: from (ylprim_potential, s_potential) to (ysprim_potential, s_potential)
                    # dune_x_crest = np.array([yltemp, ylprim_potential, ysprim_potential, ystemp])
                    # dune_z_crest = np.array([s + dfoot, s_potential + dfoot, s_potential + dfoot, s + dfoot])
            
                    # n_per_segment = 100  # how many points per segment
                    # x_dense = np.concatenate([np.linspace(dune_x_crest[i], dune_x_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_crest)-1)] + [[dune_x_crest[-1]]])
                    # z_dense = np.concatenate([np.linspace(dune_z_crest[i], dune_z_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_crest)-1)] + [[dune_z_crest[-1]]])
            
                    # # substrate under crest
                    # z_sub_crest = np.interp(x_dense, substrate_x, substrate_z)
            
                    # # volume between crest line and substrate
                    # V = trapezoid_positive(z_dense - z_sub_crest, x_dense)
            
                    # if s_potential == s:
                    #     return -vcrestnew
                    # else:
                    #     return V - vcrestnew
                    
                def f_crest_triangular_detach_flatcrest(s_potential):
                    # same pivot movement as before, but the volume is measured as the partial_volume change of the
                    # trial profile (the old lens was placed at substrate_z[1] and only counted the part over flat ground)
                    if s_potential<substrate_z[2]-dfoot and dune_z['crest_temp']<substrate_z[2]:
                        ysprim_potential = dune_x['crest_temp'] + ((s_potential-(dune_z['crest_temp']-dfoot))/betal_hs)
                    else:
                        ysprim_potential = dune_x['crest_temp'] + ((s_potential-(dune_z['crest_temp']-dfoot))/betal)
                    ylprim_potential = dune_x['lee_crest'] + ((s_potential-(dune_z['crest_temp']-dfoot))/betal)
                    tx, tz = dict(dune_x), dict(dune_z)
                    tx['lee_crest'] = ylprim_potential; tz['lee_crest'] = s_potential + dfoot
                    tx['crest_temp'] = ysprim_potential; tz['crest_temp'] = s_potential + dfoot
                    if s_potential > dune_z['seaward_crest'] - dfoot: # reattached (as in the update): the lee top meets the crest flank
                        tx['crest_temp'] = tx['seaward_crest'] = dune_x['seaward_crest'] + (s_potential + dfoot - dune_z['seaward_crest']) / betal; tz['seaward_crest'] = s_potential + dfoot
                    return partial_volume(tx, tz, substrate_x, substrate_z, tx['lee_foot'], tx['ramp_toe']) - _v_before_lee - qs_lee
                
                
                def f_crest_triangular_detach_flatlee(s_potential):
        
                    ystemp = dune_x['ramp_crest'] # fix it but transform it in the new "foot" so to account for the increase as a trapezoid, not block. In this case the seaward crest is moved backwards because of the detached
                    yltemp = dune_x['ramp_dike_temp']
                    #yltemp = substrate_x[2] # fixed at dike position
        
                    #ysprim_potential = ystemp - ((s_potential-s)/betas)
                    #ylprim_potential = yltemp + ((s_potential-s)/betal)
                    
                
                    ysprim_potential = ystemp - ((s_potential-(dune_z['ramp_dike_temp']-dfoot))/betas)
                    ylprim_potential = yltemp + ((s_potential-(dune_z['ramp_dike_temp']-dfoot))/betal)
                    
                    # linear crest line: from (ylprim_potential, s_potential) to (ysprim_potential, s_potential)
                    dune_x_crest = np.array([yltemp, ylprim_potential, ysprim_potential, ystemp])
                    #dune_z_crest = np.array([s + dfoot, s_potential + dfoot, s_potential + dfoot, s + dfoot])
                    dune_z_crest = np.array([dune_z['ramp_dike_temp'], s_potential + dfoot, s_potential + dfoot, dune_z['ramp_dike_temp']])

                    n_per_segment = 100  # how many points per segment
                    x_dense = np.concatenate([np.linspace(dune_x_crest[i], dune_x_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_crest)-1)] + [[dune_x_crest[-1]]])
                    z_dense = np.concatenate([np.linspace(dune_z_crest[i], dune_z_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_crest)-1)] + [[dune_z_crest[-1]]])
            
                    # substrate under crest
                    z_sub_crest = np.interp(x_dense, substrate_x, substrate_z)
            
                    # volume between crest line and substrate
                    z_base = dune_z['ramp_dike_temp']
                    #V = trapezoid_positive(z_dense - z_sub_crest, x_dense)
                    V = trapezoid_positive(z_dense - z_base, x_dense)

#                    if s_potential == s:
#                        return -vcrestnew
#                    else:
                    return V - deltavcrest
                
                # check detached lee side
                if dune_x['crest_temp'] > dune_x['lee_crest'] and abs(dune_z['crest_temp'] - dune_z['lee_crest']) < 1e-9 and dune_z['lee_crest'] < dune_z['ramp_dike_temp'] and not slumping_lee: #substrate_z[2]: #detached with flat crest behind and dune_x['lee_crest'] <= substrate_x[2]
                    
                    #check if it is the first time entering this block. If so, rearrange the pivot points
                    if dune_x['ramp_crest'] == dune_x['seaward_crest'] and dune_x['seaward_crest'] == dune_x['ramp_dike_temp'] and dune_z['seaward_crest'] == substrate_z[2]:
                        dune_x['seaward_crest'] = substrate_x[2]
                        dune_x['ramp_dike_temp'] = substrate_x[2]
                        
                    #run first for the crest and after for the lee already
                    
                    # calculate maximum volume up till the crest becomes triangular when padding the substrate (when ysprim=ylprim)
                    s_max_triangular = (betal * betas * (dune_x['ramp_crest'] - dune_x['ramp_dike_temp'])) / (betal + betas)
                    vcrest_triangular = 0.5 * (dune_x['ramp_crest'] - dune_x['ramp_dike_temp']) * s_max_triangular #max volume for triangular shape
            
                    #find the height in the top
                    s_new_c = brentq(f_crest_triangular_detach_flatlee, dune_z['ramp_dike_temp']-dfoot, s_max_triangular+dune_z['ramp_dike_temp']-dfoot)  # adjust 10 if necessary
                    
                    if dune_z['ramp_dike_temp']-dfoot < s_hs:
                        dune_z['ramp_dike_temp'] = substrate_z[2]
                    
                    # Calculate corresponding pivot points
                    ysprim_new_c = dune_x['ramp_crest'] - (s_new_c - (dune_z['ramp_dike_temp']-dfoot)) / betas
                    ylprim_new_c = dune_x['ramp_dike_temp'] + (s_new_c - (dune_z['ramp_dike_temp']-dfoot)) / betal
                    #ylprim_new_c = substrate_x[2] + (s_new_c - s) / betal
                    vlee_lateral = 0.0
                                
                    #calculate the portion of the lee using the detached method
                    vleenew_detached = partial_volume(dune_x,dune_z,substrate_x,substrate_z,dune_x['lee_crest'],dune_x['seaward_crest']) + qs_lee # new volume of the crest after accretion
                    
                    #s_new_clee = brentq(f_crest_triangular_detach_flatcrest, dune_z['lee_crest']-dfoot, dune_z['seaward_crest']-dfoot) # adjust 10 if necessary
                    _v_before_lee = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])
                    s_new_clee = brentq(f_crest_triangular_detach_flatcrest, dune_z['lee_crest']-dfoot, dune_z['ramp_dike_temp']-dfoot) # adjust 10 if necessary
                    qs_lee = 0

                    #vcrestnew = vcrestnew + qs_lee #in this case makes the lee deposit on the top as well
                    #qs_lee = 0
                    #if f_crest_triangular_detach_flatcrest(dune_z['seaward_crest']) < 0 and f_crest_triangular_detach_flatcrest(dune_z['crest_temp']) < 0:
                    #    s_new_c = dune_z['seaward_crest']
                    #    vlee_lateral = f_crest_triangular_detach_flatcrest(dune_z['seaward_crest']) + vcrestnew
                    #else:
                    #    s_new_c = brentq(f_crest_triangular_detach_flatcrest, dune_z['crest_temp'], dune_z['seaward_crest']) # adjust 10 if necessary
                    #    vlee_lateral = 0.0
                        
                    ## Calculate corresponding pivot points
                    if s_new_clee<substrate_z[2]-dfoot and dune_z['crest_temp']<substrate_z[2]:
                        ysprim_new_clee = dune_x['crest_temp'] + (s_new_clee - (dune_z['crest_temp']-dfoot)) / betal_hs
                    else:
                        ysprim_new_clee = dune_x['crest_temp'] + (s_new_clee - (dune_z['crest_temp']-dfoot)) / betal
                        
                    ylprim_new_clee = dune_x['lee_crest'] + (s_new_clee - (dune_z['crest_temp']-dfoot)) / betal
                    ##ylprim_new_c = substrate_x[2] + (s_new_c - s) / betal
                    yl_new_c = dune_x['lee_foot']
                    z_int_c = dune_z['lee_foot']
                    ys_new_c = dune_x['ramp_toe']
                    
                    detach_tag = 2
                
                elif dune_x['lee_crest'] <= substrate_x[2] and dune_z['lee_crest'] < substrate_z[2]: #detached but slumping in the dike
                    
                    _v_before = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])
                
                    #s_new_c = brentq(f_crest_triangular_detach, s_hs, s_max_triangular+s)  # adjust 10 if necessary
                    s_new_c = brentq(f_crest_triangular_detach, s, s_max_triangular + s, xtol=1e-14)
                    
                    # Calculate corresponding pivot points
                    ysprim_new_c = dune_x['seaward_crest'] - (s_new_c - s) / betas
                    ylprim_new_c = dune_x['crest_temp'] + (s_new_c - s) / betal
                    #ylprim_new_c = substrate_x[2] + (s_new_c - s) / betal
                    yl_new_c = dune_x['lee_foot']
                    z_int_c = dune_z['lee_foot']
                    ys_new_c = dune_x['ramp_toe']
                    vlee_lateral = 0.0
                
                    #check volume
                    h = s_new_c - s
                    b_back = dune_x['seaward_crest'] - dune_x['lee_crest']
                    b_front = ysprim_new_c - ylprim_new_c
                    V_check = 0.5 * (b_back + b_front) * h
                    
                    detach_tag = 1
                
                else:
                # Solve for s_potential that gives the target volume
                    s_new_c = brentq(f_crest_triangular, s, s_max_triangular+s)  # adjust 10 if necessary
            
                    # Calculate corresponding pivot points
                    ysprim_new_c = dune_x['seaward_crest'] - (s_new_c - s) / betas
                    ylprim_new_c = dune_x['lee_crest'] + (s_new_c - s) / betal
                    yl_new_c = dune_x['lee_foot']
                    z_int_c = dune_z['lee_foot']
                    ys_new_c = dune_x['ramp_toe']
                    vlee_lateral = 0.0
                
                    #check volume
                    h = s_new_c - s
                    b_back = dune_x['seaward_crest'] - dune_x['lee_crest']
                    b_front = ysprim_new_c - ylprim_new_c
                    V_check = 0.5 * (b_back + b_front) * h
                    
                    detach_tag = 0
                
            else:
                # volume that cannot fit into trapezoid (triangular crest)
                vcrest_lateral = deltavcrest - vcrest_triangular
            
                # assume half goes to ramp side, half goes to lee side
                vramp_lateral = vcrest_lateral / 2
                vlee_lateral = vlee_lateral + (vcrest_lateral / 2)
            
                # add condition for detached case
                if dune_x['crest_temp'] > dune_x['lee_crest'] and abs(dune_z['crest_temp'] - dune_z['lee_crest']) < 1e-9 and dune_z['lee_crest'] < dune_z['ramp_dike_temp'] and not slumping_lee: #substrate_z[2]: #detached with flat crest behind
                    s_new_c = s_max_triangular + (dune_z['ramp_dike_temp'] - dfoot)
                    
                    # pivot points for trapezoid (before lateral redistribution) those two should be the same because it it a triangle
                    ysprim_tri = dune_x['ramp_crest'] - (s_max_triangular / betas)
                    ylprim_tri = dune_x['ramp_dike_temp'] + (s_max_triangular / betal)
                    
                    # --- lateral overflow mapping ---
                    # triangular cross-section: area = 0.5 * base * height -> base = 2 * area / height
                    delta_ys = vramp_lateral / s_new_c
                
                    # update positions
                    ys_new_c = dune_x['ramp_toe'] + delta_ys            # seaward dune foot
                    ysprim_new_c = ysprim_tri + delta_ys      # seaward pivot
                    ylprim_new_c = ylprim_tri # does not change until filling the lee detached side

                    # update the lee side here already
                    qs_lee = qs_lee + vlee_lateral
                    vlee_lateral = 0
                    
                    def f_crest_triangular_detach_flatcrest_tri(s_potential):
                        # same pivot movement as before, but the volume is measured as the partial_volume change of the
                        # trial profile (the old lens sat at substrate_z[1] / was a rectangle, not the written geometry)
                        if s_potential<substrate_z[2]-dfoot and dune_z['crest_temp']<substrate_z[2]:
                            ysprim_potential = dune_x['crest_temp'] + ((s_potential-(dune_z['crest_temp']-dfoot))/betal_hs)
                        else:
                            ysprim_potential = dune_x['crest_temp'] + ((s_potential-(dune_z['crest_temp']-dfoot))/betal)
                        ylprim_potential = dune_x['lee_crest'] + ((s_potential-(dune_z['crest_temp']-dfoot))/betal)
                        tx, tz = dict(dune_x), dict(dune_z)
                        tx['lee_crest'] = ylprim_potential; tz['lee_crest'] = s_potential + dfoot
                        tx['crest_temp'] = ysprim_potential; tz['crest_temp'] = s_potential + dfoot
                        if s_potential > dune_z['seaward_crest'] - dfoot: # reattached (as in the update): the lee top meets the crest flank
                            tx['crest_temp'] = tx['seaward_crest'] = dune_x['seaward_crest'] + (s_potential + dfoot - dune_z['seaward_crest']) / betal; tz['seaward_crest'] = s_potential + dfoot
                        return partial_volume(tx, tz, substrate_x, substrate_z, tx['lee_foot'], tx['ramp_toe']) - _v_before_lee - qs_lee
                    
                    maxV = ((dune_z['ramp_dike_temp']-dfoot)-(dune_z['crest_temp']-dfoot))*(dune_x['crest_temp']-dune_x['lee_crest'])
                    
                    if maxV >=qs_lee:
                        _v_before_lee = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])
                        s_new_clee = brentq(f_crest_triangular_detach_flatcrest_tri, dune_z['lee_crest']-dfoot, dune_z['ramp_dike_temp']-dfoot) # adjust 10 if necessary
                        qs_lee = 0
                    else:
                        s_new_clee = s_new_c # dune_z['ramp_dike_temp']-dfoot
                        qs_lee = qs_lee - maxV
                        
                    ## Calculate corresponding pivot points
                    if s_new_clee<substrate_z[2]-dfoot:
                        ysprim_new_clee = dune_x['crest_temp'] + ((s_new_clee - (dune_z['crest_temp']-dfoot)) / betal_hs)
                    else:
                        ysprim_new_clee = dune_x['crest_temp'] + ((s_new_clee - (dune_z['crest_temp']-dfoot)) / betal)
                        
                    ylprim_new_clee = dune_x['lee_crest'] + (s_new_clee - (dune_z['crest_temp']-dfoot)) / betal
                    ##ylprim_new_c = substrate_x[2] + (s_new_c - s) / betal
                    yl_new_c = dune_x['lee_foot']
                    z_int_c = dune_z['lee_foot']
                    
                    detach_tag = 2
                    
                else:
                    # height of filled triangular crest
                    s_new_c = s + s_max_triangular
                
                    # pivot points for trapezoid (before lateral redistribution) those two should be the same because it it a triangle
                    ysprim_tri = dune_x['seaward_crest'] - (s_max_triangular / betas)
                    ylprim_tri = dune_x['lee_crest'] + (s_max_triangular / betal)
            
            
                    # --- lateral overflow mapping ---
                    # triangular cross-section: area = 0.5 * base * height -> base = 2 * area / height
                    delta_ys = vramp_lateral / s_new_c   # parallelogram shift: area = delta_ys * height
                
                    # update positions
                    ys_new_c = dune_x['ramp_toe'] + delta_ys            # seaward dune foot
                    ysprim_new_c = ysprim_tri + delta_ys      # seaward pivot
                    
                    # lee pivots stay put here; vlee_lateral is handed to the lee block below, which already
                    # handles a dune lower than the dike (trough filling / spreading over the crest / overflow)
                    yl_new_c = dune_x['lee_foot']
                    ylprim_new_c = ylprim_tri
                
                    # bottom of dune remains at dfoot
                    z_int_c = dune_z['lee_foot']
            
            # Update dune profile
            
            if detach_tag == 1: 
                dune_x['crest_temp'] = ylprim_new_c
                dune_z['crest_temp'] = s_new_c + dfoot
                dune_x['seaward_crest'] = ysprim_new_c
                dune_z['seaward_crest'] = s_new_c + dfoot
                dune_z['ramp_dike_temp'] = s_new_c + dfoot
                dune_x['ramp_dike_temp'] = ysprim_new_c
                dune_x['ramp_crest'] = ysprim_new_c
                dune_z['ramp_crest'] = s_new_c + dfoot
                
            elif detach_tag ==2:
                
                #cap the size of the detached when reaching close to the top of the dune (betas different than betal, so size may change slightly)
                if ysprim_new_clee > ysprim_new_c:
                    ysprim_new_clee = ysprim_new_c
                    
                #check if the detached side reattached of not to the detached crest
                if s_new_clee > dune_z['seaward_crest'] - dfoot:
                    x_flank = dune_x['seaward_crest'] + (s_new_clee + dfoot - dune_z['seaward_crest']) / betal # where the new lee top meets the crest flank (slope betal from seaward_crest)
                    dune_x['lee_crest'] = ylprim_new_clee
                    dune_z['lee_crest'] = s_new_clee + dfoot
                    dune_z['crest_temp'] = s_new_clee + dfoot
                    dune_x['crest_temp'] = x_flank
                    dune_x['ramp_dike_temp'] = ylprim_new_c
                    dune_z['ramp_dike_temp'] = s_new_c + dfoot
                    dune_z['seaward_crest'] = s_new_clee + dfoot
                    dune_x['seaward_crest'] = x_flank
                    dune_x['ramp_crest'] = ysprim_new_c
                    dune_z['ramp_crest'] = s_new_c + dfoot
                    
                else:
                    dune_x['lee_crest'] = ylprim_new_clee
                    dune_z['lee_crest'] = s_new_clee + dfoot
                    dune_z['crest_temp'] = s_new_clee + dfoot
                    dune_x['crest_temp'] = ysprim_new_clee
                    dune_x['ramp_dike_temp'] = ylprim_new_c
                    dune_z['ramp_dike_temp'] = s_new_c + dfoot
                    dune_x['ramp_crest'] = ysprim_new_c
                    dune_z['ramp_crest'] = s_new_c + dfoot
                    
                # check if detachement condition still holds
                if s_new_c == s_new_clee:
                    #if so, move seaward crest back to standard position
                    dune_x['seaward_crest'] = ysprim_new_c
                    dune_x['crest_temp'] = ylprim_new_clee
                    
            else:
                dune_x['lee_foot'] = yl_new_c
                dune_z['lee_foot'] = z_int_c
                dune_x['lee_crest'] = ylprim_new_c
                dune_z['lee_crest'] = s_new_c + dfoot
                dune_x['crest_temp'] = ylprim_new_c
                dune_z['crest_temp'] = s_new_c + dfoot
                dune_x['seaward_crest'] = ysprim_new_c
                dune_z['seaward_crest'] = s_new_c + dfoot
                dune_z['ramp_dike_temp'] = s_new_c + dfoot
                dune_x['ramp_dike_temp'] = ysprim_new_c
                dune_x['ramp_crest'] = ysprim_new_c
                dune_z['ramp_crest'] = s_new_c + dfoot
            
            if dune_z['ramp_toe_temp'] > dune_z['ramp_toe']: #check if scarp is sitting on the front dike
                dune_x['ramp_toe'] = ys_new_c
                dune_z['ramp_toe'] = dfoot
            else:
                dune_x['ramp_toe'] = ys_new_c
                dune_z['ramp_toe'] = dfoot
                dune_x['ramp_toe_temp'] = ys_new_c #TEST
                dune_z['ramp_toe_temp'] = dfoot #TEST

            vdune_aftercrest = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])

        ################## update lee ##################
        if qs_lee + vlee_lateral > 0:
            
            deltavlee = qs_lee + vlee_lateral # how much sand is deposited on the lee side
            deltavlee_temp = None
            
            vlee_c      = lee_volume(dune_x['lee_crest'], dune_x, dune_z, betal, substrate_x, substrate_z)
            vlee_target = vlee_c + deltavlee
            
            if s_new_c < s_hs and dune_x['lee_crest'] > substrate_x[3]: #check if there is space to grow behind the dune
            
                # find yl assuming no dike
                yl_bare = dune_x['lee_crest'] - s_new_c / betal
                                    
                # use shapely to find intersection between new lee line and potential hard structure
                substrate_line = LineString(zip(substrate_x, substrate_z))
                # lee line: from lee crest (ylprim, s_new) to theoretical flat toe (yl_flat, dfoot)
                lee_line = LineString([(dune_x['lee_crest'], s_new_c+dfoot), (yl_bare, dfoot)])
                # crest line: cres intersection
                crest_line = LineString([(dune_x['lee_crest'], s_new_c+dfoot), (ysprim_hs, s_new_c+dfoot)]) #only until ysprim because is the potential crossing when there is space behind
                # find intersection(s)
                intersection = substrate_line.intersection(lee_line)
                intersection_crest = substrate_line.intersection(crest_line)
        
                if not intersection.is_empty:
                    if intersection.geom_type == "Point":
                        yl_intersect, z_intersect = intersection.x, intersection.y
                    else:  # multiple intersections, take the shallowest one (max x)
                        points = [pt for pt in intersection.geoms if pt.geom_type == "Point"]
                        yl_intersect, z_intersect = max(points, key=lambda p: p.x).x, max(points, key=lambda p: p.x).y
               
                if not intersection_crest.is_empty:
                    if intersection_crest.geom_type == "Point":
                        yl_intersectcrest, z_intersectcrest = intersection_crest.x, intersection_crest.y
                    else:  # multiple intersections, take the shallowest one (max x)
                        points = [pt for pt in intersection_crest.geoms if pt.geom_type == "Point"]
                        yl_intersectcrest, z_intersectcrest = max(points, key=lambda p: p.x).x, max(points, key=lambda p: p.x).y
                        
                        
        
                # calculate the volume under the curve between ylprim and intersection point
                if dune_x['lee_crest'] > (ys_hs - (s_new_c+dfoot)/betas_hs): #check if there is space here
                    vol_to_fill_lee = (z_intersectcrest-z_intersect)*(dune_x['lee_crest']-yl_intersectcrest)*0.5
                else:
                    vol_to_fill_lee = 0
                    yl_intersectcrest = ys_hs - (s_new_c+dfoot)/betas_hs
                    z_intersectcrest = s_new_c+dfoot
                    
                if vol_to_fill_lee > deltavlee: # if the volume deltavlee is smaller than this, proceed normally
                
                    def f_lee(ylprim_potential):
                        return lee_volume(ylprim_potential, dune_x, dune_z, betal, substrate_x, substrate_z) - vlee_target
                    
                    
                    # solve for ylprim_potential that gives the target volume
                    ylprim_new_l = brentq(f_lee, dune_x['lee_crest'] - 200, dune_x['lee_crest']) # find the new lee height using the root finder
                    yl_flat = ylprim_new_l - (dune_z['seaward_crest']-dfoot) / betal # get the new lee foot position assuming no hard structure
                    
                    # use shapely to find intersection between new lee line and potential hard structure
                    substrate_line = LineString(zip(substrate_x, substrate_z))
                    # lee line: from lee crest (ylprim, s_new) to theoretical flat toe (yl_flat, dfoot)
                    lee_line = LineString([(ylprim_new_l, dune_z['seaward_crest']), (yl_flat, dfoot)])
                    
                    # find intersection(s)
                    intersection = substrate_line.intersection(lee_line)
                    
                    if not intersection.is_empty:
                        if intersection.geom_type == "Point":
                            yl_new_l, z_int_l = intersection.x, intersection.y
                        else:  # multiple intersections, take the shallowest one (max x)
                            points = [pt for pt in intersection.geoms if pt.geom_type == "Point"]
                            yl_new_l, z_int_l = max(points, key=lambda p: p.x).x, max(points, key=lambda p: p.x).y
                    
                    else:
                        # no intersection with hard substrate → use flat geometry
                        yl_new_l = yl_flat
                        z_int_l = dfoot
                    
                    # Update dune profile
                    dune_x['lee_foot'] = yl_new_l
                    dune_z['lee_foot'] = z_int_l
                    dune_x['lee_crest'] = ylprim_new_l
                    dune_z['lee_crest'] = s_new_c + dfoot
                    
                    # x test added (same condition as at the end of the lee update): with a rising toe level
                    # back_ref could otherwise be left seaward of the lee foot, creating a notch in partial_volume
                    if dune_x['back_ref'] > dune_x['lee_foot'] or dune_z['lee_foot'] > dune_z['back_ref']:
                        dune_x['back_ref'] = yl_new_l #change the reference to the dunefoot to avoid calculating extra volume from the link between ref and dunefoot above reference
                        dune_z['back_ref'] = z_int_l
                    
                else: # otherwise, fill this space and spread the remaining volume in the crest only
                
                    #adjust the points of intersection here for the volume calculations.
                    dune_x['lee_crest'] = yl_intersectcrest #adjust ylprim
                    dune_z['lee_crest'] = z_intersectcrest

                    dune_x['crest_temp'] = yl_intersectcrest #adjust ylprim
                    dune_z['crest_temp'] = z_intersectcrest
                            
                    dune_x['lee_foot'] = yl_intersectcrest
                    dune_z['lee_foot'] = dfoot
                
                    # calculate the substrate under the crest
                    leecrest_idx = ['lee_foot', 'lee_crest', 'seaward_crest']
                    vcrestlee = total_volume([dune_x[k] for k in leecrest_idx], [dune_z[k] for k in leecrest_idx], substrate_x, substrate_z)
                    vcrestleenew = vcrestlee + deltavlee - vol_to_fill_lee# new volume of the crest after accretion
                    
                    vtocrest = deltavlee - vol_to_fill_lee #volume to be spread over the crest
                    ylprim_int_i = yl_intersectcrest #point of contact of the crest after filling
        
                    def f_crest_nolee(ylprim_int_potential):
                        ystemp = dune_x['seaward_crest'] # fix it but transform it in the new "foot" so to account for the increase as a trapezoid, not block
                        s_potential = s_new_c + betas_hs*(yl_intersectcrest-ylprim_int_potential)
                        
                        ysprim_potential = ystemp - ((s_potential-s_new_c)/betas)
                
                        # linear crest line: from (ylprim_potential, s_potential) to (ysprim_potential, s_potential)
                        dune_x_crest = np.array([ylprim_int_potential, ysprim_potential, ystemp])
                        dune_z_crest = np.array([s_potential + dfoot, s_potential + dfoot, s_new_c + dfoot])
                
                        n_per_segment = 100  # how many points per segment
                        x_dense = np.concatenate([np.linspace(dune_x_crest[i], dune_x_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_crest)-1)] + [[dune_x_crest[-1]]])
                        z_dense = np.concatenate([np.linspace(dune_z_crest[i], dune_z_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_crest)-1)] + [[dune_z_crest[-1]]])
                
                        # substrate under crest
                        z_sub_crest = np.interp(x_dense, substrate_x, substrate_z)
                
                        # volume between crest line and substrate
                        V = trapezoid_positive(z_dense - z_sub_crest, x_dense)
                
                        return V - vcrestleenew 
                    
                    
                    if f_crest_nolee(ysprim_hs) > 0: # check if the volume overflows the dike or not or not
                        ylprim_int_new = brentq(f_crest_nolee, ysprim_hs, yl_intersectcrest) # find the new lee height using the root finder
                        s_new_lee = s_new_c + betas_hs*(yl_intersectcrest-ylprim_int_new)
                        ysprim_new_c = dune_x['seaward_crest'] - ((s_new_lee-s_new_c)/betas)
                        
                        #update the profile 
                        dune_x['back_ref'] = yl_new_c
                        #dune_z['back_ref'] = s_hs+dfoot
                        dune_z['back_ref'] = s_new_lee+dfoot
                        dune_x['lee_foot'] = ylprim_int_new
                        dune_z['lee_foot'] = s_new_lee + dfoot
                        # dune_x['back_ref'] = yl_new_c
                        # dune_z['back_ref'] = s_hs+dfoot
                        # dune_x['lee_foot'] = yl_new_c
                        # dune_z['lee_foot'] = s_hs + dfoot
                        dune_x['lee_crest'] = ylprim_int_new
                        dune_z['lee_crest'] = s_new_lee + dfoot
                        dune_z['crest_temp'] = s_new_lee + dfoot
                        dune_x['crest_temp'] = ylprim_int_new
                        dune_x['seaward_crest'] = ysprim_new_c
                        dune_z['seaward_crest'] = s_new_lee + dfoot
                        dune_x['ramp_crest'] = ysprim_new_c
                        dune_z['ramp_crest'] = s_new_lee + dfoot
                        
                    else:
                        v_overflow = -f_crest_nolee(ysprim_hs) #volume to be redistributed on top of the dune and dike
                        
                        #use the code for when volume is bigger than the dike
                        
                        def f_crest_overdike_overflow(s_potential):
                        
                            ystemp = dune_x['seaward_crest']
                            yltemp = ylprim_hs
                        
                            ysprim_potential = ysprim_new_c - ((s_potential - s_hs) / betas)
                            ylprim_potential = yltemp + ((s_potential - s_hs) / betal)
                        
                            dune_x_crest = np.array([
                                yltemp,
                                ylprim_potential,
                                ysprim_potential,
                                ystemp
                            ])
                        
                            dune_z_crest = np.array([
                                s_hs + dfoot,
                                s_potential + dfoot,
                                s_potential + dfoot,
                                s_hs + dfoot
                            ])
                        
                            n_per_segment = 100
                            x_dense = np.concatenate([
                                np.linspace(dune_x_crest[i], dune_x_crest[i+1],
                                            n_per_segment, endpoint=False)
                                for i in range(len(dune_x_crest) - 1)
                            ] + [[dune_x_crest[-1]]])
                        
                            z_dense = np.concatenate([
                                np.linspace(dune_z_crest[i], dune_z_crest[i+1],
                                            n_per_segment, endpoint=False)
                                for i in range(len(dune_z_crest) - 1)
                            ] + [[dune_z_crest[-1]]])
                        
                            #z_sub_crest = np.interp(x_dense, substrate_x, substrate_z)
                        
                            V = trapezoid_positive(z_dense - (s_hs+dfoot), x_dense) #use s_hs because it is assumes filling up to that position
                        
                            return V - v_overflow

                        # Solve for s_potential that gives the target volume
                        s_new_lee = brentq(f_crest_overdike_overflow, s_hs, s_hs+5)  # adjust 10 if necessary
                        
                        # Calculate corresponding pivot points
                        ysprim_new_c = dune_x['seaward_crest'] - (s_new_lee - s_new_c) / betas
                        ylprim_int_new = ylprim_hs + (s_new_lee - (s_hs)) / betal
                        yl_new_c = ylprim_hs
                        
                        # # Update dune profile

                        dune_x['back_ref'] = 0
                        dune_z['back_ref'] = substrate_z[0]
                        dune_x['lee_foot'] = substrate_x[1]
                        dune_z['lee_foot'] = substrate_z[1] #as it filled everything, change the location to the back base of the dike.
                        dune_x['lee_crest'] = substrate_x[2]
                        dune_z['lee_crest'] = substrate_z[2]
                        dune_z['crest_temp'] = s_new_lee + dfoot
                        dune_x['crest_temp'] = ylprim_int_new
                        dune_x['seaward_crest'] = ysprim_new_c
                        dune_z['seaward_crest'] = s_new_lee + dfoot
                        dune_x['ramp_dike_temp'] = ysprim_new_c
                        dune_z['ramp_dike_temp'] = s_new_lee + dfoot
                        dune_x['ramp_crest'] = ysprim_new_c
                        dune_z['ramp_crest'] = s_new_lee + dfoot
                        
                    # # Update dune profile
                    # dune_x['back_ref'] = yl_new_c
                    # dune_z['back_ref'] = s_hs
                    # dune_x['lee_foot'] = ylprim_int_new
                    # dune_z['lee_foot'] = s_new_lee + dfoot
                    # dune_x['lee_crest'] = ylprim_int_new
                    # dune_z['lee_crest'] = s_new_lee + dfoot
                    # dune_z['crest_temp'] = s_new_lee + dfoot
                    # dune_x['crest_temp'] = ysprim_new_c
                    # dune_x['seaward_crest'] = ysprim_new_c
                    # dune_z['seaward_crest'] = s_new_lee + dfoot
                    # dune_x['ramp_crest'] = ysprim_new_c
                    # dune_z['ramp_crest'] = s_new_lee + dfoot
                        
                        
                    # if s_new_lee+dfoot > s_hs+dfoot: #check if the volume is bigger than the dike, then redistribuite the overflow.
                    
                    #     #v_overflow = trapezoid_positive(np.array([s_new_lee+dfoot, s_new_lee+dfoot, dfoot])-s_hs+dfoot, [ylprim_int_new, ysprim_new_c, dune_x['ramp_toe']]) #calculate the volume above the dike crest
                    #     def f_crest_overdike(s_potential):

                    #         ystemp = dune_x['seaward_crest'] # fix it but transform it in the new "foot" so to account for the increase as a trapezoid, not block
                    #         yltemp = ylprim_hs
                            
                    #         ysprim_potential = ysprim_new_c - ((s_potential-(s_new_c+dfoot))/betas)
                    #         ylprim_potential = yltemp + ((s_potential-(s_new_c+dfoot))/betal)
                    
                    #         # linear crest line: from (ylprim_potential, s_potential) to (ysprim_potential, s_potential)
                    #         dune_x_crest = np.array([yltemp, ylprim_potential, ysprim_potential, ystemp])
                    #         dune_z_crest = np.array([s_hs, s_potential, s_potential, s_new_c+dfoot])
                    
                    #         n_per_segment = 100  # how many points per segment
                    #         x_dense = np.concatenate([np.linspace(dune_x_crest[i], dune_x_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_crest)-1)] + [[dune_x_crest[-1]]])
                    #         z_dense = np.concatenate([np.linspace(dune_z_crest[i], dune_z_crest[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_crest)-1)] + [[dune_z_crest[-1]]])
                    
                    #         # substrate under crest
                    #         z_sub_crest = np.interp(x_dense, substrate_x, substrate_z)
                    
                    #         # volume between crest line and substrate
                    #         V = trapezoid_positive(z_dense - z_sub_crest, x_dense)
                    
                    #         return V - vcrestleenew
                    
                    #     # Solve for s_potential that gives the target volume
                    #     s_new_lee = brentq(f_crest_overdike, s_hs, s_hs+5) - dfoot  # adjust 10 if necessary
                        
                    #     # Calculate corresponding pivot points
                    #     ysprim_new_c = dune_x['seaward_crest'] - (s_new_lee - s_new_c) / betas
                    #     ylprim_int_new = ylprim_hs + (s_new_lee - (s_hs-dfoot)) / betal
                    #     yl_new_c = ylprim_hs
                        
                    # Update dune profile


            else:
                
                # if dune moving on top of the dike, find the volume with the current height until reaching the back of the dike
                if dune_x['lee_foot'] > substrate_x[2] and dune_x['lee_foot'] < substrate_x[3]: # top of the dike
                    v_to_fill = (dune_x['lee_foot'] - substrate_x[2])*(dune_z['lee_crest']-substrate_z[2])
                    
                    #check if amount of volume is larger than needed:
                    if v_to_fill <= deltavlee:
                        #reduce the amount and use the overflow moving forward                       
                        deltavlee_temp = deltavlee.copy() #copy to change later to make sure we save the correct amount for conservation check
                        deltavlee = deltavlee - v_to_fill
                        
                        # update the parameters
                        dune_x['lee_foot'] = substrate_x[1]
                        dune_z['lee_foot'] = substrate_z[1]
                        dune_x['lee_crest'] = substrate_x[2]
                        dune_z['lee_crest'] = substrate_z[2]
                        dune_x['crest_temp'] = dune_x['lee_crest'] + ((dune_z['crest_temp']-dune_z['lee_crest'])/betal)
                        dune_x['back_ref'] = 0 #change the reference to the dunefoot to avoid calculating extra volume from the link between ref and dunefoot above reference
                        dune_z['back_ref'] = substrate_z[0]
                                 
                # Check the need to start a new lee portion behind the dike structure
                if (dune_x['lee_foot'] <= substrate_x[1] and dune_z['lee_foot'] == substrate_z[1]) and dune_z['lee_crest']<=substrate_z[2]:
                    
                    # check if the volume input exceed the needed to reconnect the lee side
                    x_leefoot_max = substrate_x[2] - (substrate_z[2]-substrate_z[1])/betal
                    
                    v_top = (dune_x['crest_temp']-substrate_x[2])*(dune_z['crest_temp']-substrate_z[2])/2
                    v_bottom_full = (substrate_x[2]-x_leefoot_max)*(substrate_z[2]-substrate_z[1])/2
                    v_dike = (substrate_x[2]-substrate_x[1])*(substrate_z[2]-substrate_z[1])/2
                    v_bottom = ((dune_x['lee_crest']-dune_x['lee_foot'])*(dune_z['lee_crest']-dune_z['lee_foot'])/2) - ((dune_x['lee_crest']-substrate_x[1])*(dune_z['lee_crest']-substrate_z[1])/2)
                    
                    v_to_fill = v_bottom_full - v_dike - v_bottom # v_top (crest flank above the dike) is already sand: once the lee line reaches the dike crest it is collinear with the flank
                    
                    #check if the incoming sand fills the back of not
                    
                    if v_to_fill > deltavlee:
                    
                        #calculate the lee volume that is already there
                        
                        
                        def f_lee_behinddike(ylprim_potential):
                             
                            z_potential = (betal_hs*(ylprim_potential-substrate_x[1])) + substrate_z[1]
                            #z_potential = (betal_hs*(ylprim_potential-dune_x['lee_crest'])) + dune_z['lee_crest']
                            ylpotential = ylprim_potential - ((z_potential -dune_z['lee_foot']) / betal) 
    
                            # lee line
                            #dune_x_line = np.array([ylpotential, ylprim_potential, dune_x['crest_temp']]) #to calculate, keep the initial ylprim always otherwise u will have the same lee always!
                            #dune_z_line = np.array([dune_z['lee_foot'], z_potential, dune_z['crest_temp']]) # new dune height
    
                            dune_x_line = np.array([ylpotential, ylprim_potential, substrate_x[2]]) # use the pads from the substrate at the end otherwise will create fake volume due to the crest increase
                            dune_z_line = np.array([dune_z['lee_foot'], z_potential, substrate_z[2]]) # new dune height
    
                            n_per_segment = 100  # how many points per segment
                            x_dense = np.concatenate([np.linspace(dune_x_line[i], dune_x_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_x_line)-1)] + [[dune_x_line[-1]]])
                            z_dense = np.concatenate([np.linspace(dune_z_line[i], dune_z_line[i+1], n_per_segment, endpoint=False) for i in range(len(dune_z_line)-1)] + [[dune_z_line[-1]]])
                           
                            # substrate under lee side
                            z_sub_line = np.interp(x_dense, substrate_x, substrate_z)
    
                            # trapezoidal integration
                            return trapezoid_positive(z_dense - z_sub_line, x_dense) - deltavlee - v_bottom
                           
         
                        ylprim_new_l = brentq(f_lee_behinddike, dune_x['lee_foot'], substrate_x[2]) # find the new lee height using the root finder
                        z_ylprim = (betal_hs*(ylprim_new_l-substrate_x[1])) + substrate_z[1] #find the elevation at that point
                        yl_new_l = ylprim_new_l - ((z_ylprim - substrate_z[1])/betal)
                        
                        # Update dune profile
                        dune_x['lee_foot'] = yl_new_l
                        dune_z['lee_foot'] = substrate_z[1]
                        dune_x['lee_crest'] = ylprim_new_l
                        dune_z['lee_crest'] = z_ylprim
                    
                    else: #proceed without the influence of the dike anymore
                    
                        #reattach first: the lee line through the crest corner (crest_temp) is collinear with the crest flank, so moving the lee crest there adds only the climb room still left
                        vdune_beforereattach = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])
                        dune_x['lee_crest'] = dune_x['crest_temp']
                        dune_z['lee_crest'] = dune_z['crest_temp']
                        dune_x['lee_foot'] = dune_x['crest_temp'] - (dune_z['crest_temp'] - dune_z['lee_foot']) / betal
                        deltavlee = deltavlee - (partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe']) - vdune_beforereattach)
                        vlee_target = lee_volume(dune_x['lee_crest'], dune_x, dune_z, betal, substrate_x, substrate_z) + deltavlee
                    
                        def f_lee(ylprim_potential):
                            return lee_volume(ylprim_potential, dune_x, dune_z, betal, substrate_x, substrate_z) - vlee_target
       
                        # solve for ylprim_potential that gives the target volume
                        ylprim_new_l = brentq(f_lee, dune_x['crest_temp'] - 200, dune_x['crest_temp']) # find the new lee height using the root finder
                        yl_flat = ylprim_new_l - (dune_z['crest_temp']-dune_z['lee_foot']) / betal # get the new lee foot position assuming no hard structure
      
                        # Update dune profile
                        dune_x['lee_foot'] = yl_flat
                        dune_x['lee_crest'] = ylprim_new_l
                        dune_z['lee_crest'] = dune_z['crest_temp'] #reatach the temp with the normal
                        dune_x['crest_temp'] = ylprim_new_l
                        
                        if dune_x['back_ref'] > dune_x['lee_foot']:
                            dune_x['back_ref'] = dune_x['lee_foot']
                            dune_z['back_ref'] = dune_z['lee_foot']
                        
                else:    
                
                    def f_lee(ylprim_potential):
                        return lee_volume(ylprim_potential, dune_x, dune_z, betal, substrate_x, substrate_z) - vlee_target
                    
                    # solve for ylprim_potential that gives the target volume
                    ylprim_new_l = brentq(f_lee, dune_x['lee_crest'] - 200, dune_x['lee_crest']) # find the new lee height using the root finder
                    yl_flat = ylprim_new_l - (dune_z['seaward_crest']-dune_z['lee_foot']) / betal # get the new lee foot position assuming no hard structure
                    
                    # use shapely to find intersection between new lee line and potential hard structure
                    substrate_line = LineString(zip(substrate_x, substrate_z))
                    # lee line: from lee crest (ylprim, s_new) to theoretical flat toe (yl_flat, dfoot)
                    lee_line = LineString([(ylprim_new_l, dune_z['seaward_crest']), (yl_flat, dune_z['lee_foot'])])
                    
                    # find intersection(s)
                    intersection = substrate_line.intersection(lee_line)
                    
                    if not intersection.is_empty:
                        if intersection.geom_type == "Point":
                            yl_new_l, z_int_l = intersection.x, intersection.y
                        else:  # multiple intersections, take the shallowest one (max x)
                            points = [pt for pt in intersection.geoms if pt.geom_type == "Point"]
                            yl_new_l, z_int_l = max(points, key=lambda p: p.x).x, max(points, key=lambda p: p.x).y
                    
                    else:
                        # no intersection with hard substrate → use flat geometry
                        yl_new_l = yl_flat
                        if dune_z['lee_foot'] == substrate_z[3]: #check if it is moving on top of the dike
                            z_int_l = substrate_z[1]
                        else:
                            z_int_l = dune_z['lee_foot']
                    
                    
                    ### ADD CONDITION WHERE WHEN CREST IS FILLED AND THE LEE IS PADDED TO THE DIKE, START FILLING THE LEE SIDE FROM BEHIND THE DIKE 
                    # Update dune profile
                    dune_x['lee_foot'] = yl_new_l
                    dune_z['lee_foot'] = z_int_l
                    dune_x['lee_crest'] = ylprim_new_l
                    dune_z['lee_crest'] = s_new_c + dfoot
                    dune_x['crest_temp'] = ylprim_new_l
                    dune_z['crest_temp'] = s_new_c + dfoot
                    
                    if dune_x['back_ref'] > dune_x['lee_foot'] or dune_z['lee_foot'] > dune_z['back_ref']: #also when the lee foot sits above the reference (e.g. on the dike), to avoid a link from back_ref to the dune foot above the ground
                        dune_x['back_ref'] = yl_new_l
                        dune_z['back_ref'] = z_int_l

            if deltavlee_temp is not None:
                deltavlee = deltavlee_temp
                deltavlee_temp = None
                    
            vdune_afterlee = partial_volume(dune_x, dune_z, substrate_x, substrate_z, dune_x['lee_foot'], dune_x['ramp_toe'])

    return dune_x, dune_z, deltavramp, erod_overwash, deltavramp_ero, deltavall

def subaq(DT, VOLBAR, HO, T, WFALL, SLR, BARNOUR, CB, BACTIVE):
    # Empirical coefficients
    ACOEFF = 1.333
    BCOEFF = 1.0
    DCOEFF = 0.56e-6
    MCOEFF = -0.5

    # Dean parameter
    DEAN = HO / (WFALL * T)

    # Deepwater wave steepness
    LO = 1.56 * T**2
    STP = HO / LO

    # Equilibrium bar volume
    VOLBAREQ = CB * DEAN**ACOEFF * STP**BCOEFF * LO**2

    # Response coefficient for bar volume
    LAMBDA2 = DCOEFF * DEAN**MCOEFF

    if VOLBAREQ - VOLBAR > 0:
        LAMBDA = LAMBDA2
    else:
        LAMBDA = 0.30 * LAMBDA2  # Adjust as needed

    # Calculate bar volume change
    DVOL = (VOLBAREQ - VOLBAR) * (1.0 - np.exp(-LAMBDA * DT))

    # Transport to (from) bar
    QBAR = DVOL / DT

    # Transport onshore from shoreface nourishment
    NOURCOEFF = 0.1
    DVOLNOUR = BARNOUR * (1.0 - np.exp(-NOURCOEFF * LAMBDA * DT))
    QNOUR = DVOLNOUR / DT

    # Bruun rule transport due to sea level rise
    QSLR = SLR * BACTIVE

    return QBAR, QNOUR, QSLR, DVOL



def bar(volbar, qbar, dt, vnourbar, barnour, qnour):
    volbar_new = volbar + qbar * dt
    barnour_new = barnour + vnourbar - qnour * dt

    volbar = volbar_new
    barnour = barnour_new

    if volbar < 0:
        print('BAR VOLUME EXCEEDED')

    return volbar, barnour


def FALVEL(TEMP, D50):
    SRATIO = 2.65
    NYVAL = np.zeros(9)
    TETA = np.zeros(9)
    NYVAL[0] = 1.79
    NYVAL[1] = 1.51
    NYVAL[2] = 1.31
    NYVAL[3] = 1.14
    NYVAL[4] = 1.00
    NYVAL[5] = 0.894
    NYVAL[6] = 0.799
    NYVAL[7] = 0.724
    NYVAL[8] = 0.658
    NYVAL = NYVAL * 1E-6

    for I in range(9):
        TETA[I] = (I + 1) * 5.0

    if (TEMP < TETA[0]) or (TEMP > TETA[8]):
        print('TEMPERATURE FOR VISCOSITY CALCULATION IS OUT OF RANGE')
        print(f'{TEMP}°C')

    # Linear interpolation
    NY = np.interp(TEMP, TETA, NYVAL)
    B = (SRATIO - 1) * 9.81 * D50 ** 3 / NY ** 2

    if B < 39:
        WFALL = (SRATIO - 1) * 9.81 * D50 ** 2 / 18 / NY
    elif 39 <= B < 1E4:
        WFALL = ((SRATIO - 1) * 9.81) ** 0.7 * D50 ** 1.1 / 6 / NY ** 0.4
    else:
        WFALL = ((SRATIO - 1) * 9.81 * D50 / 0.91) ** 0.5

    return WFALL



def nour(i, iv, volat, volad, volab, volrb, maxnour):
    vnourd = 0.0
    vnourb = 0.0
    vnourbar = 0.0

    if i == int(volat[int(iv) - 1]):
        vnourd = volad[int(iv) - 1]
        vnourb = volab[int(iv) - 1]
        vnourbar = volrb[int(iv) - 1]
        print(f'beach nourishment {vnourb:.2f}')
        print(f'bar nourishment {vnourbar:.2f}')
        
        if iv < maxnour:
            iv += 1

    return vnourd, vnourb, vnourbar, iv


# ---------------------------------------------------------------------------
# MOVING DUNE TOE LEVEL: helpers for sea-level rise (slr_toe) and the berm
# option (dynamic_toe). Called from main.py right after morpho_update; they are
# not used when both options are off. See CHANGES_slr_dynamic_toe.md.
#
# Concept: morpho_update works on a flat "base plane" at the dune toe level
# (substrate points 4 and 5, with substrate_z[4] == dune_z['ramp_toe']). These
# helpers move that plane to a new level and re-anchor the pivots resting on
# it, so morpho_update keeps all its geometric assumptions.
#   block_volume      bookkeeping volume of the sand below the plane under the dune
#   _reanchor_pivots  geometry of the plane shift (no volumes)
#   shift_base_plane  plane shift + dune volume relabelled by it
#   beach_base_level  elevation of the beach base profile (flat + beach slope)
#   find_toe_level    plane level for which the toe lies on that profile
# ---------------------------------------------------------------------------
def block_volume(x_toe, z_plane, z_bot, x3, z3, m_face):
    """
    Bookkeeping volume of the sand below the base plane, landward of the dune
    toe and seaward of the seaward dike face (taken as a straight line through
    the seaward dike crest), down to z_bot. Signed and exact:
        d/dx_toe = z_plane - z_bot ;  d/dz_plane = x_toe - x4(z_plane)
    Only differences taken with the same z_bot are meaningful.
    """
    z_mid = 0.5 * (z_plane + z_bot)
    return (z_plane - z_bot) * (x_toe - (x3 + (z3 - z_mid) / m_face))


def _reanchor_pivots(dune_x, dune_z, substrate_x, substrate_z, z_new, m_face, tol_z=1e-9, tol_x=1e-9):
    """
    Geometry of the base-plane shift (no volumes): substrate points 4 and 5 go
    to z_new (point 4 slides along the seaward dike face) and the dune pivots
    resting on the seaward plane are re-anchored. Returns new dune_x, dune_z,
    substrate_x, substrate_z and info. Raises ValueError if the plane would
    bury the dune front or the lee crest.
    """
    z_old = float(substrate_z[4])
    z_new = float(z_new)
    info = {'case': 'none', 'lee': 'none'}
    dx, dz = dict(dune_x), dict(dune_z)
    sx, sz = [float(v) for v in substrate_x], [float(v) for v in substrate_z]
    if z_new == z_old:
        return dx, dz, sx, sz, info
    x3, z3 = sx[3], sz[3]
    x4_old = sx[4]
    if z_new >= z3 - 0.05:
        raise ValueError(f"base plane ({z_new:.3f} m) reaches the dike crest ({z3:.3f} m): not supported")
    x4_new = x3 + (z3 - z_new) / m_face
    sx[4], sz[4], sz[5] = x4_new, z_new, z_new
    sx[5] = max(sx[5], x4_new + 1.0)

    def on_plane(k):
        return (dx.get(k) is not None and dz.get(k) is not None
                and abs(dz[k] - z_old) <= tol_z and dx[k] >= x4_old - tol_x)

    # ---------------- seaward pivots ----------------
    walk = [k for k in ('ramp_toe', 'ramp_toe_temp', 'ramp_crest', 'ramp_dike_temp', 'seaward_crest')
            if dx.get(k) is not None and dz.get(k) is not None]   # seaward -> landward
    toe_level = (dx.get('ramp_toe') is not None and abs(dz['ramp_toe'] - z_old) <= tol_z)
    if toe_level and dx['ramp_toe'] < x4_old - tol_x:
        # toe drawn at plane level under the dike face (scarp landward of the dike toe): it keeps its
        # position and only follows the level; partial_volume clips it against the dike
        info['case'] = 'under_face'
        for k in walk:
            if abs(dz[k] - z_old) <= tol_z and dx[k] < x4_old + tol_x:
                dz[k] = z_new
    elif on_plane('ramp_toe'):
        xt = dx['ramp_toe']
        if abs(xt - x4_old) <= tol_x:
            # toe at the dike toe: follows point 4
            info['case'] = 'dike_toe'
            for k in walk:
                coincident = abs(dx[k] - x4_old) <= tol_x and abs(dz[k] - z_old) <= tol_z
                buried = (z_new > z_old and dz[k] < z_new and x3 - tol_x <= dx[k] <= x4_old + tol_x)
                if coincident or buried:
                    dx[k], dz[k] = x4_new, z_new
        elif z_new > z_old:
            info['case'] = 'rise'
            a = next((i for i, k in enumerate(walk) if dz[k] > z_new + tol_z), None)
            if a is None or a == 0:
                raise ValueError("base plane rose above the dune front: dune buried (not handled)")
            ka, kp = walk[a], walk[a - 1]
            if abs(dx[ka] - dx[kp]) <= tol_x:
                xc = dx[kp]
            else:
                xc = dx[kp] + (z_new - dz[kp]) * (dx[ka] - dx[kp]) / (dz[ka] - dz[kp])
            xc = max(xc, x4_new)
            for k in walk[:a]:
                dx[k], dz[k] = xc, z_new
        else:
            info['case'] = 'drop'
            group = [k for k in walk if abs(dx[k] - xt) <= tol_x and abs(dz[k] - z_old) <= tol_z]
            q = next((k for k in walk if k not in group), None)
            xc = xt
            if q is not None and (xt - dx[q]) > tol_x and (dz[q] - z_old) > tol_z:
                xc = xt + (z_old - z_new) * (xt - dx[q]) / (dz[q] - z_old)
            for k in walk:
                if k in group:
                    dx[k], dz[k] = xc, z_new
                elif on_plane(k):
                    dz[k] = z_new
    # ---------------- lee foot resting on the seaward plane ----------------
    if on_plane('lee_foot'):
        xl, xlc, zlc = dx['lee_foot'], dx['lee_crest'], dz['lee_crest']
        follow_ref = dx['back_ref'] >= x4_old - tol_x     # back_ref also sits on the seaward plane
        if (xlc - xl) > tol_x and (zlc - z_old) > tol_z:
            sl = (zlc - z_old) / (xlc - xl)
            xn, zn = xl + (z_new - z_old) / sl, z_new
            info['lee'] = 'slide'
            if xn < x4_new:      # lee line meets the dike face before the plane
                xn = (z3 + m_face * x3 - zlc + sl * xlc) / (sl + m_face)
                zn = z3 - m_face * (xn - x3)
                info['lee'] = 'on_face'
            if zn >= zlc - tol_z:
                raise ValueError("base plane rose above the lee crest: dune buried (not handled)")
        else:
            xn, zn = max(xl, x4_new), z_new
            info['lee'] = 'vertical'
        dx['lee_foot'], dz['lee_foot'] = xn, zn
        if follow_ref:
            dx['back_ref'], dz['back_ref'] = xn, zn
    return dx, dz, sx, sz, info


def shift_base_plane(dune_x, dune_z, substrate_x, substrate_z, z_new, m_face,
                     tol_z=1e-9, tol_x=1e-9):
    """
    Move the seaward base plane (substrate points 4 and 5 = dune toe level) to
    z_new and re-anchor the dune pivots that rest on it. The dike itself does
    not move: point 4 slides along the seaward dike face.

    Returns dune_x, dune_z, substrate_x, substrate_z (new objects), tau, info
    tau > 0: dune volume relabelled to below-plane (beach side) sand.
    """
    if float(z_new) == float(substrate_z[4]):
        return dune_x, dune_z, substrate_x, substrate_z, 0.0, {'case': 'none', 'lee': 'none'}
    v_before = partial_volume(dune_x, dune_z, substrate_x, substrate_z,
                              dune_x['lee_foot'], dune_x['ramp_toe'])
    dx, dz, sx, sz, info = _reanchor_pivots(dune_x, dune_z, substrate_x, substrate_z, z_new, m_face, tol_z, tol_x)
    v_after = partial_volume(dx, dz, sx, sz, dx['lee_foot'], dx['ramp_toe'])
    return dx, dz, sx, sz, v_before - v_after, info


def beach_base_level(x, x_berm, z_max, x_toe0, z_toe0, x_shore, z_msl, z_floor, slope_min=0.0):
    """
    Elevation of the beach base profile at x: flat at z_max landward of the berm
    point, then the line berm -> previous toe (if that toe was seaward of the
    berm and below z_max) -> shoreline. Not lower than z_floor, and not flatter
    than slope_min measured from the shoreline.
    """
    if x <= x_berm:
        return z_max
    xs, zs = [x_berm], [z_max]
    if x_toe0 > x_berm + 1e-9 and z_toe0 < z_max - 1e-12 and x_toe0 < x_shore - 1e-9:
        xs.append(x_toe0); zs.append(z_toe0)
    xs.append(max(x_shore, xs[-1] + 1e-6)); zs.append(z_msl)
    zb = max(float(np.interp(x, xs, zs)), z_floor)
    if slope_min > 0:   # the beach in front of a low toe is not flatter than slope_min: it builds up instead
        zb = max(zb, min(z_max, z_msl + slope_min * (x_shore - x)))
    return zb


def find_toe_level(dune_x, dune_z, substrate_x, substrate_z, m_face, base_level, z_floor, z_max):
    """
    Level of the base plane for which the dune toe lies on the beach base
    profile (base_level(x)). z_max if the toe is on the flat part; between
    z_floor and z_max if the dune front stands on the beach slope.
    """
    def g(z):
        try:
            dx = _reanchor_pivots(dune_x, dune_z, substrate_x, substrate_z, z, m_face)[0]
        except ValueError:
            return 1.0          # plane above the dune front: the toe must be lower
        return z - base_level(dx['ramp_toe'])
    if g(z_max) <= 1e-12:
        return z_max
    if g(z_floor) >= 0.0:
        return z_floor
    return float(brentq(g, z_floor, z_max, xtol=1e-12, rtol=1e-14))
